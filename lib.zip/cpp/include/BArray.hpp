/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BARRAY_HPP
#define BARRAY_HPP

#include "Byps.h"

namespace byps {


	

}

#endif // BARRAY_HPP
