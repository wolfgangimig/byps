/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BARRAY_HPP
#define BARRAY_HPP

#include "Byps.h"

namespace byps {


	

}

#endif // BARRAY_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BASYNCRESULT_HPP
#define BASYNCRESULT_HPP

#include "BAsyncResult.h"

namespace byps {

//BINLINE BAsyncResultReceiveMethod::BAsyncResultReceiveMethod(PAsyncResult innerResult)
//        : innerResult(innerResult) {
//}
//
//BINLINE void BAsyncResultReceiveMethod::setAsyncResult(const BVariant& varMethod) {
//    if (varMethod.isException()) {
//        innerResult->setAsyncResult(BVariant(varMethod.getException()));
//    }
//    else {
//		PSerializable sobj;
//		varMethod.get(sobj);
//        PMethodResult methodResult = byps_ptr_cast<BMethodResult>(sobj);
//
//        innerResult->setAsyncResult(methodResult->result);
//    }
//}

}

#endif // BASYNCRESULT_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BBUFFER_HPP_
#define BBUFFER_HPP_

#include "BBuffer.h"

namespace byps {

#define BCOMPRESS_INTEGER true
#define BBUFFER_GROW (10*1000)

using namespace ::std;

BINLINE BBuffer::BBuffer(const BBinaryModel& bmodel, BByteOrder byteOrder) :
    bmodel(bmodel),
    isWrite(true), byteOrder(byteOrder),
    pos(0), limit(0), capacity(0), grow(BBUFFER_GROW), compressInteger(BCOMPRESS_INTEGER) {
}

BINLINE BBuffer::BBuffer(const BBinaryModel& bmodel, const PBytes& pBytes, BByteOrder byteOrder) :
    bmodel(bmodel),
    isWrite(false), byteOrder(byteOrder),
    pBytes(pBytes), pos(0), limit((int32_t)pBytes->length), capacity((int32_t)pBytes->length), grow(0), compressInteger(BCOMPRESS_INTEGER) {
}

BINLINE const PBytes& BBuffer::getBytes() const {
    pBytes->length = (size_t)pos;
    return pBytes;
}

BINLINE void BBuffer::clear() {
	pos = 0;
	limit = 0;
}

BINLINE BByteOrder BBuffer::getByteOrder() const {
    return byteOrder;
}

BINLINE void BBuffer::setByteOrder(BByteOrder byteOrder) {
    this->byteOrder = byteOrder;
}

BINLINE bool BBuffer::isCompressInteger() const {
	return this->compressInteger;
}

BINLINE bool BBuffer::setCompressInteger(bool v) {
	bool ret = this->compressInteger;
	this->compressInteger = v;
	return ret;
}


BINLINE void BBuffer::serialize(PBytes& v) {
	BLENGTH n = (BLENGTH)(isWrite ? v->length : 0);
	
	ensureRemaining(n + sizeof(BLENGTH));

	serializeLength(n);

	{
        int8_t* buf = pBytes->data;
        if (isWrite) {
			memcpy(buf + pos, v->data, n);
        }
        else {
			v = BBytes::create(n);
			memcpy(v->data, buf + pos, n);
        }
        pos += n;
	}
}

BINLINE void BBuffer::serialize(int8_t& v) {
	ensureRemaining(1);

	{
		if (isWrite) {
			pBytes->data[pos] = v;
		}
		else {
			v = pBytes->data[pos];
		}
		pos++;
	}
}

BINLINE void BBuffer::serialize(int16_t& v) {
	serializeIntegerUnaligned(v);
}

BINLINE void BBuffer::serialize(int32_t& v) {
	if (compressInteger) {
		serializeIntegerCompressed(v);
	}
	else {
		serializeIntegerUnaligned(v);
	}
}

BINLINE void BBuffer::serialize(int64_t& v) {
	if (compressInteger) {
		serializeIntegerCompressed(v);
	}
	else {
		serializeIntegerUnaligned(v);
	}
}

BINLINE void BBuffer::serialize(bool& b) {
	if (isWrite) {
		int8_t v = b ? 1 : 0;
		serialize(v);
	}
	else {
		int8_t v = 0;
		serialize(v);
		b = v != 0;
	}
}

BINLINE void BBuffer::serialize(wchar_t& c) {
	if (isWrite) {
		int16_t v = (int16_t)c;
		serialize(v);
	}
	else {
		int16_t v = 0;
		serialize(v);
		c = (int16_t)v;
	}
}

BINLINE void BBuffer::serialize (float& v) {
    if (isWrite) {
		int32_t IEEE = floatToIEEE(v);
        serializeIntegerUnaligned(IEEE);
	}
	else {
		int32_t IEEE = 0;
        serializeIntegerUnaligned(IEEE);
		v = floatFromIEEE(IEEE);
	}
}

BINLINE void BBuffer::serialize (double& v) {
    if (isWrite) {
		int64_t IEEE = doubleToIEEE(v);
        serializeIntegerUnaligned(IEEE);
	}
	else {
		int64_t IEEE = 0;
        serializeIntegerUnaligned(IEEE);
		v = doubleFromIEEE(IEEE);
	}
}

BINLINE void BBuffer::serialize(BDateTime& v) {
	if (isWrite) {

		int16_t _mmdd = (int16_t)((v.month << 8) | v.day);
		int16_t _hhmm = (int16_t)((v.hour << 8) | v.minute);
		int16_t _ssuu = (int16_t)((v.second << 10) | (v.millisecond));

		serialize(v.year);
		serialize(_mmdd);
		serialize(_hhmm);
		serialize(_ssuu);

	}
	else {

		int16_t _mmdd = 0;
		int16_t _hhmm = 0;
		int16_t _ssuu = 0;
		serialize(v.year);
		serialize(_mmdd);
		serialize(_hhmm);
		serialize(_ssuu);

		v.month = (_mmdd >> 8) & 0xFF;
		v.day = _mmdd & 0xFF;
		v.hour = (_hhmm >> 8) & 0xFF;
		v.minute = _hhmm & 0xFF;
		v.second = (_ssuu >> 10) & 0x3F;
		v.millisecond = _ssuu & 0x3FF;

	}
}

BINLINE void BBuffer::serializePointer(BPOINTER& p) {
    int32_t v = p;
	serialize(v);
	if (!isWrite) p = v;
}

BINLINE void BBuffer::serializeTypeId(BTYPEID& p) {
    int32_t v = p;
	serialize(v);
	if (!isWrite) p = v;
}

BINLINE void BBuffer::serializeLength(BLENGTH& p) {
    int32_t v = p;
	serialize(v);
	if (!isWrite) p = v;
}

BINLINE int32_t BBuffer::getStringLengthUtf8(const ::std::wstring& str) {

	int32_t p = 0;

    for (wstring::const_iterator it = str.begin(); it != str.end(); it++) {

		wchar_t c = (*it);

		if (c <= 0x7F) {
			p++;
		}
		else if (c >= 0x80 && c <= 0x07FF) {
			p += 2;
		}
		else { // if (c >= 0x800 && c <= 0xFFFF) {
			p += 3;
		}
	}

	return p;
}

BINLINE void BBuffer::serialize(wstring& str) {
    if (isWrite) {

        int32_t n = 0;

		if (compressInteger) {
			n = getStringLengthUtf8(str);
		}
		else {
			n = (int32_t)(3 * str.size());
		}
		
		ensureRemaining(4 + n + 1);

        serialize(n);
		int32_t lengthPos = pos - 4;

		if (str.size() != 0) {
			
			int8_t* buf = pBytes->data;
			int8_t* p = buf + pos;

            for (wstring::iterator it = str.begin(); it != str.end(); it++) {

				wchar_t c = (*it);

				if (c <= 0x7F) {
					*p++ = (int8_t)c;
				}
				else if (c >= 0x80 && c <= 0x07FF) {
					*p++ = (int8_t)(((c >> 6) & 0x1F) | 0xC0);
					*p++ = (int8_t)((c & 0x3F) | 0x80);
				}
				else { // if (c >= 0x800 && c <= 0xFFFF) {
					*p++ = (int8_t)(((c >> 12) & 0xF) | 0xE0);
					*p++ = (int8_t)(((c >> 6) & 0x3F) | 0x80);
					*p++ = (int8_t)((c & 0x3F) | 0x80);
				}
			}

			// correct length
			if (!compressInteger) {
				n = (int32_t)(p - buf) - pos;
				pos = lengthPos;
				serialize(n);
			}

	       *p++ = 0;
			pos = (int32_t)(p - buf);
			assert(pos <= capacity);
		}
		else {
			pBytes->data[pos++] = 0;
		}

    }
    else {
        int32_t blen = 0;
        serialize(blen);

        str.reserve((size_t)blen);

        int8_t* buf = pBytes->data;
        int8_t* p = buf + pos;
		int8_t* pend = p + blen;

        while (p < pend) {
            wchar_t c = (wchar_t)(*p);
            p++;
            int16_t u4bits = (c & 0xF0);
            if (u4bits == 0xC0) {
                c &= 0x1F;
                c <<= 6;
                c |= (wchar_t)((*p++ & 0x3F));
            }
            else if (u4bits == 0xE0) {
                c &= 0xF;
                c <<= 6;
                c |= (wchar_t)((*p++ & 0x3F));
                c <<= 6;
                c |= (wchar_t)((*p++ & 0x3F));
            }

            str += c;
        }

        char _0 = *p++;
        if (_0 != 0) throw new BException(EX_CORRUPT);

        pos = (int32_t)(p - buf);
    }

}

BINLINE void BBuffer::serialize(string& str) {
    if (isWrite) {
        int32_t n = (int32_t)str.size();
        serialize(n);

        int32_t blen = n+1;
        ensureRemaining(blen);

        int8_t* buf = pBytes->data;
        int8_t* p = buf + pos;
        memcpy(p, str.c_str(), blen);

        pos += blen;

    }
    else {
        int32_t n = 0;
        serialize(n);

        int8_t* buf = pBytes->data;
        int8_t* p = buf + pos;
        str = string((char*)p, (size_t)n);

        char _0 = *(p + n);
        if (_0 != 0) throw new BException(EX_CORRUPT);

        pos += n + 1;
    }
}

BINLINE bool BBuffer::isEmpty() {
    return pos == 0;
}

BINLINE BBuffer::~BBuffer() {
}

BINLINE void BBuffer::growForRemaining(int32_t size) {
	const int32_t requiredCapacity = pos + size;
    if (isWrite) {
        int32_t growNow = requiredCapacity - capacity;
        growNow = ((growNow / grow) + 1) * grow;
        int32_t newCap = capacity + growNow;
        pBytes = BBytes::create(pBytes, newCap);
		if (!pBytes) throw BException(EX_INTERNAL, L"Out of memory.");
        capacity = newCap;
        limit = capacity;
	}
	else {
		throw BException(EX_CORRUPT, L"Cannot enlarge read buffer.");
	}
}


} /* namespace byps */
#endif 
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BBYTES_HPP_
#define BBYTES_HPP_

#include "BBytes.h"
#include <cstdarg>
#include <assert.h>

namespace byps {

const int64_t DEBUG_END_MARKER = 0x0102030405060708LL;

BINLINE BBytes* BBytes::myalloc(size_t length) {
	size_t n =  length + sizeof(size_t) + sizeof(int64_t);
	int8_t* mem = new int8_t[n];
	int64_t endm = DEBUG_END_MARKER;
	memcpy(mem + n - sizeof(DEBUG_END_MARKER), &endm, sizeof(int64_t));
	BBytes* p = (BBytes*)(mem);
	p->length = length;
	return p;
}

BINLINE void BBytes::check() {
	int8_t* mem = (int8_t*)this;
	int8_t* pcheck = mem + sizeof(size_t) + this->length;
	int64_t endm = DEBUG_END_MARKER;
	int cmp = memcmp(pcheck, &endm, sizeof(int64_t));
    assert(cmp == 0);
}

BINLINE PBytes BBytes::create(size_t length) {
	return PBytes(myalloc(length));
}

BINLINE PBytes BBytes::create(size_t length, int v0, ...) {
	BBytes* p = myalloc(length);
	va_list args;
	va_start(args, v0);
	p->data[0] = (int8_t)(v0 & 0xFF);
	for (size_t i = 1; i < length; i++) {
        p->data[i] = (int8_t)(va_arg(args, int) & 0xFF);
	}
	va_end(args);
	return PBytes(p);
}

BINLINE PBytes BBytes::create(const PBytes& p, size_t length) {
	if (length == 0) length = p->length;
	PBytes q = create(length);
	if (p) {
		size_t n = (p->length < length) ? p->length : length;
		memcpy(q->data, p->data, n);
	}
	return q;
}

BINLINE PBytes BBytes::create(const void* p, size_t length) {
	PBytes q = create(length);
	if (p) {
		memcpy(q->data, p, length);
	}
	return q;
}


}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BCLIENT_HPP
#define BCLIENT_HPP

#include "BClient.h"

namespace byps {

BINLINE BClient::BClient(PTransport transport, PServerR serverR)
    : transport(transport), serverR(serverR) {
}

BINLINE BClient::~BClient() {

}

BINLINE PTransport BClient::getTransport() {
	return transport;
}

BINLINE void BClient::done() {

    if (serverR) {
        serverR->done();
    }

	// Close the wire connection.
	// In HWireClient it will call internalCancelAllRequests which cancels 
	// all messages - inclusive long polls from serverR - for this session.
	getTransport()->wire->done();

	getTransport()->setAuthentication(PAuthentication(), false);
}

#ifdef CPP11_LAMBDA

class BClientStart_BAsyncResultT : public BAsyncResultT<bool> {
	function<void (const bool, BException ex)> innerResult;
public:
	BClientStart_BAsyncResultT(function<void (const bool, BException ex)> innerResult) 
		: innerResult(innerResult) {
	}
	virtual void setAsyncResult(bool result, BException ex) {
		innerResult(result, ex);
		delete this;
	}
};

BINLINE void BClient::start(function<void (bool, BException)> asyncResult) {
	PAsyncResult outerResult = new BClientStart_BAsyncResultT(asyncResult);
	internalStart(outerResult);
}

#else

BINLINE void BClient::start(PClient client, byps_ptr<BAsyncResultT<bool> > asyncResult) {
	client->internalStart(client, asyncResult);
}

#endif

BINLINE void BClient::start() {
	BSyncResultT<PClient> syncResult;
	internalStart(&syncResult);
	syncResult.getResult();
}

class  BClient_MyNegoAsyncResult : public BAsyncResult {
    PClient client;
    PAsyncResult innerResult;
public:

    BClient_MyNegoAsyncResult(PClient client, PAsyncResult innerResult)
        : client(client), innerResult(innerResult) {
    }

	virtual ~BClient_MyNegoAsyncResult() {
		client.reset();
	}

	void internalSetAsyncResult(const BVariant& result) {
		innerResult->setAsyncResult(result);
	}

	virtual void setAsyncResult(const BVariant& result) {
        try {
            if (result.isException()) {
                internalSetAsyncResult(result);
            }
            else {
                if (client->serverR) {
                    client->serverR->start();
                }
                internalSetAsyncResult(result);
            }
        }
        catch (const exception& e) {
            internalSetAsyncResult(BVariant(e));
        }
		delete this;
    }
};


BINLINE void BClient::internalStart(PAsyncResult asyncResult) {
	setAuthentication(PAuthentication());
    getTransport()->negotiateProtocolClient(asyncResult);
}

class BClient_ClientAuthentication : public BAuthentication
{
	byps_weak_ptr<BClient> client;
    PAuthentication innerAuth;

public:
	BClient_ClientAuthentication(PClient client, PAuthentication innerAuth)
		: client(client)
		, innerAuth(innerAuth)
    {
    }

	PAuthentication getInnerAuthentication() {
		return innerAuth;
	}
            
	virtual void authenticate(PClient , PAsyncResult asyncResult) {
		PClient client = this->client.lock();
		if (client) {

			PAsyncResult startClientResult(new BClient_MyNegoAsyncResult(client, asyncResult));
			if (innerAuth) {
				innerAuth->authenticate(client, startClientResult);
			}
			else {
				startClientResult->setAsyncResult(BVariant());
			}
		}
		else {
			asyncResult->setAsyncResult(BVariant(BException(EX_CANCELLED)));
		}
    }

    virtual bool isReloginException(PClient , BException ex, BTYPEID typeId) 
    {
        bool ret = false;

		PClient client = this->client.lock();
		if (client) {

			if (innerAuth)
			{
				ret = innerAuth->isReloginException(client, ex, typeId);
			}
			else
			{
				ret = client->getTransport()->isReloginException(ex, typeId);
			}
		}

        return ret;
    }

    virtual void getSession(PClient , BTYPEID typeId, PAsyncResult asyncResult)
    {
        if (innerAuth) {
            innerAuth->getSession(this->client.lock(), typeId, asyncResult);
        }
		else {
			asyncResult->setAsyncResult(BVariant());
		}
    }

#ifdef CPP11_LAMBDA
	virtual void authenticate(PClient , function<void (bool, BException)> ) {
	}

	virtual void getSession(PClient , BTYPEID , function<void (PSerializable, BException)> ) {
	}
#endif

};

BINLINE void BClient::setAuthentication(PAuthentication innerAuth) {
	getTransport()->setAuthentication(
		PAuthentication(new BClient_ClientAuthentication(shared_from_this(), innerAuth)),
		innerAuth == NULL); // onlyIfNull
}

BINLINE PAuthentication BClient::getAuthentication() {
	PAuthentication auth = getTransport()->authentication;
	if (auth) {
		BClient_ClientAuthentication* clientAuth = dynamic_cast<BClient_ClientAuthentication*>(auth.get());
		if (clientAuth) {
			auth = clientAuth->getInnerAuthentication();
		}
	}
	return auth;
}

BINLINE void BClient::setLostReverseConnectionHandler(function<void (BException ex)> lostConnectionHandler) {
	PLostConnectionHandler handler(new BLostConnectionHandlerL(lostConnectionHandler));
	setLostReverseConnectionHandler(handler);
}

BINLINE void BClient::setLostReverseConnectionHandler(PLostConnectionHandler lostConnectionHandler) {
	if (serverR) {
		serverR->setLostConnectionHandler(lostConnectionHandler);
	}
}

}

#endif // BCLIENT_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BCONTENTSTREAM_HPP_
#define BCONTENTSTREAM_HPP_

#include "BContentStream.h"

namespace byps {

using namespace ::std;

BINLINE BContentStreamImpl::BContentStreamImpl(const wstring& contentType, int64_t contentLength, PStream stream) 
	: contentType(contentType), contentLength(contentLength), stream(stream) {
}

BINLINE BContentStreamImpl::BContentStreamImpl(PStream stream) 
	: contentLength(-1), stream(stream) {
}

BINLINE BContentStreamImpl::BContentStreamImpl() 
	: contentLength(-1) {
}

BINLINE const wstring& BContentStreamImpl::getContentType() const {
	return contentType;
}

BINLINE int64_t BContentStreamImpl::getContentLength() const {
	return contentLength;
}

BINLINE int32_t BContentStreamImpl::read(char* buf, int32_t offs, int32_t len) {
	if (len < 0) return -1;
	if (stream->eof()) return -1;
	stream->read(buf + offs, (size_t)len);
	return (int32_t)stream->gcount();
}

#ifdef BFSTREAM_WCHAR
BINLINE BContentStreamFile::BContentStreamFile(const wstring& fname) {
    ifstream* fstrm = new ifstream(fname.c_str(), ios_base::binary|ios_base::in);
    init(fstrm);
}
BINLINE BContentStreamFile::BContentStreamFile(const wstring& fname, const wstring& contentType, int64_t contentLength) {
    ifstream* fstrm = new ifstream(fname.c_str(), ios_base::binary|ios_base::in);
    this->stream = PStream(fstrm);
	this->contentType = contentType;
	this->contentLength = contentLength;
}
#endif

BINLINE BContentStreamFile::BContentStreamFile(const string& fname) {
    ifstream* fstrm = new ifstream(fname.c_str(), ios_base::binary|ios_base::in);
    init(fstrm);
}
BINLINE BContentStreamFile::BContentStreamFile(const string& fname, const string& contentType, int64_t contentLength) {
    ifstream* fstrm = new ifstream(fname.c_str(), ios_base::binary|ios_base::in);
    this->stream = PStream(fstrm);
	this->contentType = BToStdWString(contentType);
	this->contentLength = contentLength;
}

BINLINE void BContentStreamFile::init(ifstream* fstrm) {
    fstrm->seekg(0, ios_base::end);
    streampos flen = fstrm->tellg();
    fstrm->seekg(0, ios_base::beg);
    contentLength = (int64_t)flen;
    contentType = L"application/octet-stream";
    stream = PStream(fstrm);
}

BINLINE BContentStreamFile::~BContentStreamFile() {
	ifstream* fstrm = static_cast<ifstream*>(stream.get());
	fstrm->close();
}

BINLINE void BContentStream::serialize(BIO& bio, POBJECT& , PSerializable& pObjS, void* ) {

	if (bio.is_loading) {
		if (!pObjS) {
			int64_t streamId = 0;
			bio & streamId;
			pObjS = bio.transport->getWire()->getStream(bio.header.messageId, streamId);
		}
	}
	else {
		PContentStream strm = byps_ptr_cast<BContentStream>(pObjS);
		PStreamRequest streamRequest = bio.createStreamRequest(strm);
		int64_t streamId = streamRequest->streamId;
		bio & streamId;
	}

}

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BDATETIME_HPP_
#define BDATETIME_HPP_

#include "BDateTime.h"

namespace byps {

BINLINE BDateTime::BDateTime() {
	year = 1970;
	month = 01;
	day = 01;
	hour = minute = second = millisecond = _reserved = 0;
}

BINLINE BDateTime::BDateTime(const BDateTime& rhs) {
	year = rhs.year;
	month = rhs.month;
	day = rhs.day;
	hour = rhs.hour;
	minute = rhs.minute;
	second = rhs.second;
	millisecond = rhs.millisecond;
	_reserved = rhs._reserved;
}

BINLINE BDateTime::BDateTime(int16_t year, int16_t month, int16_t day, int16_t hour, int16_t minute, int16_t second, int16_t millisecond) {
	this->year = year;
	this->month = month;
	this->day = day;
	this->hour = hour;
	this->minute = minute;
	this->second = second;
	this->millisecond = millisecond;
	this->_reserved = 0;
}

BINLINE BDateTime BDateTime::fromString(const std::wstring& iso) {
	if (iso.length()) {
		std::wstringstream wss;
		for (std::wstring::const_iterator it = iso.begin(); it != iso.end(); it++) {
			wchar_t c = (*it);
			if (c >= L'0' && c <= L'9') {
				wss << c;
			}
			else {
				wss << L' ';
			}
		}
	
		BDateTime ret;
		wss >> ret.year 
			>> ret.month
			>> ret.day
			>> ret.hour
			>> ret.minute
			>> ret.second
			>> ret.millisecond;

		return ret;

	}
	else {
		// Java Date value initialized with 0.
		return BDateTime(1970, 01, 01, 00, 00, 00, 000);
	}
}

BINLINE bool BDateTime:: operator == (const BDateTime rhs) const { 
	return diff(rhs) == 0;
}

BINLINE bool BDateTime:: operator != (const BDateTime rhs) const {
	return diff(rhs) != 0;
}

BINLINE int16_t BDateTime::diff(const BDateTime& rhs) const {
	int16_t d = year - rhs.year;
	if (d == 0) {
		d = month - rhs.month;
		if (d == 0) {
			d = day - rhs.day;
			if (d == 0) {
				d = hour - rhs.hour;
				if (d == 0) {
					d = minute - rhs.minute;
					if (d == 0) {
						d = second - rhs.second;
						if (d == 0) {
							d = millisecond - rhs.millisecond;
						}
					}
				}
			}
		}
	}
	return d;
}

BINLINE bool BDateTime:: operator < (const BDateTime rhs) const { 
	return diff(rhs) < 0;
}

BINLINE bool BDateTime:: operator > (const BDateTime rhs) const {
	return diff(rhs) > 0;
}


//BINLINE std::time_t BDateTime::mktime_utc(const struct tm& tm) {
//	static long localToUtcDiffSecondsInWinter = 0;
//
//	// _get_timezone(&tz); // Windows: always returns 28800, other platforms: maybe we can use extern int _timezone;
//	if (localToUtcDiffSecondsInWinter == 0) {
//
//		// Compute timezone offset at 1970-01-01 12:00:00
//		// Of course, this is a winter time. And it is not in the range when the 
//		// time is switched.
//
//		time_t now = 12 * 3600;
//
//		struct tm gm; 
//		gmtime_s(&gm, &now);
//		time_t gmt = mktime(&gm);
//
//		struct tm loc;
//		localtime_s(&loc, &now);
//		time_t local = mktime(&loc);
//
//		localToUtcDiffSecondsInWinter = (long) difftime(local, gmt);
//	}
//
//	struct tm tm1 = tm;
//	std::time_t localT = mktime(&tm1);
//	std::time_t utcT = localT + localToUtcDiffSecondsInWinter;
//	if (tm1.tm_isdst) utcT += localToUtcDiffSecondsInWinter;
//	return utcT;
//}


BINLINE BDateTime BDateTime::fromStruct(const struct tm& tm) {
	return BDateTime((int16_t)(tm.tm_year + 1900), (int16_t)(tm.tm_mon + 1), (int16_t)tm.tm_mday, (int16_t)tm.tm_hour, (int16_t)tm.tm_min, (int16_t)tm.tm_sec, 0);
}

BINLINE void BDateTime::toStruct(struct tm& tm) const {
	tm.tm_year = year - 1900;
	tm.tm_mon = month - 1;
	tm.tm_mday = day;
	tm.tm_hour = hour;
	tm.tm_min = minute;
	tm.tm_sec = second;
}


BINLINE std::wstring BDateTime::toString() const {
	std::wstringstream wss;
	wss << (*this);
	return wss.str();
}


}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BEXCEPTION_HPP_
#define BEXCEPTION_HPP_

#include "BException.h"

namespace byps {

BINLINE BException::BException(int32_t code, const wstring& msg) throw() {
	init(code, msg, L"", "");
}

BINLINE BException::BException(int32_t code, const wstring& msg, const wstring& details) throw() {
	init(code, msg, details, "");
}

BINLINE BException::BException(int32_t code) throw() {
	init(code, L"", L"", "");
}

BINLINE BException::BException(const BException& rhs) throw() {
	this->data = rhs.data;
}

BINLINE BException::BException(const exception& ex) throw() {
	const BException* bex = dynamic_cast<const BException*>(&ex);
	if (bex) {
		data = bex->data;
	}
	else {
		init(EX_INTERNAL, L"", L"", ex.what());
	}
}

BINLINE BException::BException() {
}

BINLINE BException::~BException() throw() {
}

BINLINE BException::operator bool() const {
	return !!data;
}

BINLINE bool BException::operator !() const {
    return !data;
}

BINLINE int32_t BException::getCode() const {
    return data ? data->code : 0;
}

BINLINE wstring BException::getMsg() const {
    return data ? data->msg : L"";
}

BINLINE wstring BException::getDetails() const {
    return data ? data->details : L"";
}

BINLINE wstring BException::toString() const {
	wstringstream ss;
	if (data) {
		ss << L"[BYPS:" << data->code << L"][" << data->msg << L"][" << data->details << L"]";
	}
	else {
		ss << L"[BYPS:0]";
	}
	return ss.str();
}

BINLINE const char* BException::what() const throw() {
	if (!data) return "";

	if (data->swhat.size() == 0) {
		wstring str = toString();
		stringstream ss;
		for (unsigned i = 0; i < str.size(); i++) {
			ss << (char)(str[i]);
		}
		const_cast<BException*>(this)->data->swhat = ss.str();
	}
		
	return data->swhat.c_str();
}

BINLINE void BException::init(int32_t code, const wstring& msg, const wstring& details, const string& swhat) {
	BExceptionData* p = new BExceptionData();
	p->code = code;
	p->msg = msg;
	p->details = details;
	p->swhat = swhat;
	data = byps_ptr<BExceptionData>(p);
}

BINLINE void BException::serialize(BIO& bio, const BVERSION ) {

	int32_t code = data ? data->code : 0;
	std::wstring msg = data ? data->msg : L"";
	std::wstring details = data ? data->details : L"";

	bio & code;
	bio & msg;
	bio & details;

	if (bio.is_loading) {
		init(code, msg, details, "");
	}
}

}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BIO_HPP
#define BIO_HPP

#include "BIO.h"

namespace byps {

BINLINE BIO::BIO(PTransport transport, const BBinaryModel& bmodel, BVERSION negotiatedVersion, BByteOrder negotiatedByteOrder)
    : transport(transport)
    , registry(transport->getApiDesc()->getRegistry(bmodel))
    , is_loading(false)
    , header(BMAGIC_BINARY_STREAM, negotiatedVersion, negotiatedByteOrder, transport->getWire()->makeMessageId())
    , bbuf(bmodel, negotiatedByteOrder) {

}

BINLINE BIO::BIO(PTransport transport, const BBinaryModel& bmodel, PBytes& pBytes, BMessageHeader header)
    : transport(transport)
    , registry(transport->getApiDesc()->getRegistry(bmodel))
    , is_loading(true)
    , header(header)
    , bbuf(bmodel, pBytes, header.byteOrder) {

}

BINLINE BIO::~BIO() {

}

BINLINE void BIO::operator&(int8_t& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::operator&(int16_t& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::operator&(int32_t& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::operator&(int64_t& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::operator&(bool& v) {
	bbuf.serialize(v);
}
BINLINE void BIO::operator&(wchar_t& v) {
	bbuf.serialize(v);
}
BINLINE void BIO::operator&(float& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::operator&(double& v) {
    bbuf.serialize(v);
}
BINLINE void BIO::serialize(PBytes& v) {
	bbuf.serialize(v);
}

BINLINE void BIO::operator&(BVariant& obj) {
    obj.serialize(*this, header.version);
}

BINLINE void BIO::operator&(BTargetId& obj) {
    obj.serialize(bbuf);
}

BINLINE void BIO::operator&(BDateTime& obj) {
    bbuf.serialize(obj);
}

BINLINE void BIO::operator&(PBytes& ptr) {
	POBJECT pObj = ptr;
	serializeObj(pObj, ptr && !is_loading ? &typeid(*ptr.get()) : NULL);
	if (is_loading) ptr = byps_static_ptr_cast<BBytes>(pObj);
}
 
BINLINE PStreamRequest BIO::createStreamRequest(PContentStream ) {
	return PStreamRequest();
}

BINLINE void BIO::serializeObjS(PSerializable& pObjS) {
    if (is_loading) {
		internalLoadObjS(pObjS);
    }
    else {
		BTYPEID typeId = 0;
		BSERIALIZER ser = NULL;

		if (pObjS) {
			typeId = pObjS->BSerializable_getTypeId();
			ser = registry->getSerializer(typeId);
			internalStoreObjS(pObjS, false, ser, typeId);
		}
		else {
			internalStoreObjS(PSerializable(), false, NULL, 0);
		}
    }
}

BINLINE void BIO::serializeObj(POBJECT& pObj, const type_info* tinfo) {
    if (is_loading) {
		internalLoadObj(pObj);
    }
    else {
		BTYPEID typeId = 0;
		BSERIALIZER ser = NULL;

		if (pObj) {
			ser = registry->getSerializer(*tinfo, typeId);
		}

		internalStoreObj(pObj, false, ser, typeId);
    }
}

}


#endif // BIO_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BINPUT_HPP
#define BINPUT_HPP

#include "Byps.h"

namespace byps {


BINLINE BInput::BInput(PTransport transport, const BMessageHeader &header, PBytes& pBytes)
    : BIO(transport, BBinaryModel::MEDIUM(), pBytes, header)
    , currentId(0) {
}

BINLINE BInput::~BInput() {
}

BINLINE PSerializable BInput::load() {

    PSerializable ptr;

	if (header.messageId == 0) {
        header.read(bbuf);
    }

	if (header.error != 0) {
		BTYPEID typeId = 0;
		BPOINTER id = 0;
		bbuf.serializePointer(id);
		bbuf.serializeTypeId(typeId);

		BException ex;
		*this & ex;

		throw ex;
	}
	else {

		(*this) & ptr;
	}

    return ptr;
}

BINLINE void BInput::internalLoadObj(POBJECT& pObj) {

    BPOINTER id = 0;
    bbuf.serializePointer(id);
    if (id > 0) {
        PSerializable NULLS;

        // Read type and size from stream
        BTYPEID typeId = 0;
        bbuf.serializeTypeId(typeId);
        if (typeId < 0) throw BException(EX_CORRUPT);

        BSERIALIZER ser = registry->getSerializer(typeId);

        // Create
        currentId = id;
        ser(*this, pObj, NULLS, NULL);
 
        idMap.insert(IDMAP::value_type(id, pObj));
       
		// Read
        ser(*this, pObj, NULLS, NULL);

    }
    else if (id < 0) {
        IDMAP::iterator it = idMap.find(-id);
        if (it == idMap.end()) throw BException(EX_CORRUPT);
        pObj = (*it).second;
    }
    else {
        // NULL reference
    }

}

BINLINE void BInput::internalLoadObjS(PSerializable& pObjS) {

    BPOINTER id = 0;
    bbuf.serializePointer(id);
    if (id > 0) {
        POBJECT NULLO;

        // Read type and size from stream
        BTYPEID typeId = 0;
        bbuf.serializeTypeId(typeId);
        if (typeId < 0) throw BException(EX_CORRUPT);

        BSERIALIZER ser = registry->getSerializer(typeId);

        // Create
        currentId = id;
        ser(*this, NULLO, pObjS, NULL);
 
        idMap.insert(IDMAP::value_type(id, pObjS));
       
		// Read
        ser(*this, NULLO, pObjS, NULL);

    }
    else if (id < 0) {
        IDMAP::iterator it = idMap.find(-id);
        if (it == idMap.end()) throw BException(EX_CORRUPT);
		pObjS = byps_static_ptr_cast<BSerializable>((*it).second);
    }
    else {
        // NULL reference
    }

}

}

#endif // BINPUT_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BLOGGER_HPP_
#define BLOGGER_HPP_

#include <thread>
#include <iostream>
#include <iomanip>
#include <ctime>
#include "BLogger.h"

namespace byps {

BINLINE void BLogFile::println(BLogLevel msglevel, const wstring& msg) {
	
	if (level > msglevel) return;
	
	time_t t = time(nullptr);
    struct tm now;
    byps_localtime(&now, &t);

	std::wstringstream wss;

    wss << setfill(L'0')
            << setw(4) << 1900 + now.tm_year << L"-"
            << setw(2) << now.tm_mon+1 << L"-"
            << setw(2) << now.tm_mday << L" "
            << setw(2) << now.tm_hour << L":"
            << setw(2) << now.tm_min << L":"
            << setw(2) << now.tm_sec << L" ";

    wss << std::hex << this_thread::get_id() << L" " << std::dec;

    switch (msglevel) {
    case Nothing: break;
    case Debug: wss << L"DEBUG"; break;
    case Info: wss << L"INFO"; break;
    case Warn: wss << L"WARN"; break;
    case Error: wss << L"ERROR"; break;
    }
    wss << L" ";

    wss << msg;

    {
        byps_unique_lock lock(mutex);
		strm << wss.str() << endl;
        //strm.flush();
    }
}

BINLINE BLogFile::BLogFile() : level(BLogLevel::Nothing) {
}

#ifdef BFSTREAM_WCHAR
BINLINE void BLogFile::open(const wstring& fname, BLogLevel level, bool append) {
    ios_base::openmode om = ios_base::out;
    if (append) om |= ios_base::app;
    strm.open(fname, om);
    this->level = level;
}
#endif

BINLINE void BLogFile::open(const string& fname, BLogLevel level, bool append) {
    ios_base::openmode om = ios_base::out;
    if (append) om |= ios_base::app;
    strm.open(fname, om);
    this->level = level;
}

BINLINE void BLogFile::close() {
	strm.close();
}

#ifdef BFSTREAM_WCHAR
BINLINE void BLogger::init(const wstring& fname, BLogLevel level, bool append) {
    logFile.open(fname, level, append);
}
#endif

BINLINE void BLogger::init(const string& fname, BLogLevel level, bool append) {
    logFile.open(fname, level, append);
}

BINLINE void BLogger::done() {
	logFile.close();
}

BINLINE BLogStream BLogger::debug(int line) const {
	return BLogStream(BLogLevel::Debug, className, line);
}

BINLINE BLogStream BLogger::info(int line) const {
	return BLogStream(BLogLevel::Info, className, line);
}

BINLINE BLogStream BLogger::warn(int line) const {
	return BLogStream(BLogLevel::Warn, className, line);
}

BINLINE BLogStream BLogger::error(int line) const {
	return BLogStream(BLogLevel::Error, className, line);
}

BINLINE bool BLogger::isDebugEnabled() const {
	return logFile.level <= BLogLevel::Debug;
}

BINLINE bool BLogger::isInfoEnabled() const {
	return logFile.level <= BLogLevel::Info;
}

BINLINE bool BLogger::isWarnEnabled() const {
	return logFile.level <= BLogLevel::Warn;
}

BINLINE bool BLogger::isErrorEnabled() const {
	return logFile.level <= BLogLevel::Error;
}

BINLINE BLogStream::BLogStream(BLogLevel level, const char* className, int line) : print(true), level(level) {
	(*this) << className;
	if (line) {
		ss  << L":" << line;
	}
	ss << L" ";
}

BINLINE BLogStream::BLogStream(const BLogStream& rhs) : print(true), level(rhs.level) {
	ss << rhs.ss.str();
}

BINLINE BLogStream::~BLogStream() {
	if (!print) return;
	BLogger::logFile.println(level, ss.str());
}

BINLINE basic_ostream<wchar_t>& BLogStream::operator << (const char* msg) {
	return ss << msg;
}

BINLINE basic_ostream<wchar_t>& BLogStream::operator << (const wstring& msg) {
	return ss << msg;
}

BINLINE basic_ostream<wchar_t>& BLogStream::operator << (const string& msg) {
	return ss << msg;
}

BINLINE BLogger::BLogger(const char* className) : className(className) {
}

BINLINE basic_ostream<wchar_t>& operator << (basic_ostream<wchar_t>& ss, const char* msg) {
	const char* p = msg;
	while (*p) {
		ss << (wchar_t)(*p);
		p++;
	}
	return ss;
}

BINLINE basic_ostream<wchar_t>& operator << (basic_ostream<wchar_t>& ss, const string& msg) {
	return ss << msg.c_str();
}

BINLINE basic_ostream<wchar_t>& operator << (basic_ostream<wchar_t>& ss, const exception& ex) {
	string msg = ex.what();
	return ss << msg;
}

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BLOSTCONNECTIONHANDLER_HPP_
#define BLOSTCONNECTIONHANDLER_HPP_

#include "BLostConnectionHandler.h"

namespace byps {
	
#ifdef CPP11_LAMBDA

BINLINE BLostConnectionHandlerL::BLostConnectionHandlerL(std::function<void (BException ex)> lambdaFunction)
	: lambdaFunction(lambdaFunction) {
}

BINLINE void BLostConnectionHandlerL::onLostConnection(BException ex) {
	lambdaFunction(ex);
};

#endif

}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BMESSAGE_HPP
#define BMESSAGE_HPP

#include "BMessage.h"
#include "BBuffer.h"

namespace byps {

BINLINE BMessage::BMessage(const BMessageHeader& header, PBytes buf, const vector<PStreamRequest>& streams)
    : header(header), buf(buf), streams(streams) {
}

BINLINE bool BMessage::isEmpty() const {
  return (buf == NULL || buf->length == 0);
}

}

#endif // BMESSAGE_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BMESSAGEHEADER_HPP_
#define BMESSAGEHEADER_HPP_

#include "BMessageHeader.h"

namespace byps {

BINLINE BMessageHeader::BMessageHeader(int32_t nMagic, BVERSION nNegotiatedVersion, BByteOrder negotiatedByteOrder, int64_t messageId)
    : magic(nMagic),
        error(0),
        flags(0),
        version(nNegotiatedVersion),
        byteOrder(negotiatedByteOrder),
        messageId(messageId) {
}

BINLINE BMessageHeader::BMessageHeader()
    : magic(0),
    error(0),
    flags(0),
    version(0),
    byteOrder(BBIG_ENDIAN),
    messageId(0) {
}

BINLINE BMessageHeader::BMessageHeader(const BMessageHeader& rhs)
    : magic(rhs.magic)
    , error(rhs.error)
    , flags(rhs.flags)
    , version(rhs.version)
    , byteOrder(rhs.byteOrder)
    , messageId(rhs.messageId)
    , targetId(rhs.targetId){
}

BINLINE void BMessageHeader::write(BBuffer& bbuf) {
	bool cmpr = bbuf.setCompressInteger(false);
    bbuf.setByteOrder(byteOrder);
    bbuf.serialize(magic);
    bbuf.serialize(error);
    bbuf.serialize(flags);
    bbuf.serialize(version);
	targetId.serialize(bbuf);
    bbuf.serialize(messageId);
	bbuf.setCompressInteger(cmpr);
}

BINLINE void BMessageHeader::read(BBuffer& bbuf) {
    bbuf.setByteOrder(BBIG_ENDIAN);
	bool cmpr = bbuf.setCompressInteger(false);

    bbuf.serialize(magic);

    switch(magic) {
	case BMAGIC_BINARY_STREAM:
		break;
	case BMAGIC_BINARY_STREAM_LE:
		magic = BMAGIC_BINARY_STREAM;
        bbuf.setByteOrder(BLITTLE_ENDIAN);
		break;
	default:
		throw BException(EX_CORRUPT, L"Stream must start with BYPS, BYPC, SPYB, CPYB");
	}

    bbuf.serialize(error);
	bbuf.serialize(flags);
	bbuf.serialize(version);
 	targetId.serialize(bbuf);
    bbuf.serialize(messageId);

	bbuf.setCompressInteger(cmpr);
}

}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef METHODREQUEST_HPP_
#define METHODREQUEST_HPP_

#include "BMethodRequest.h"

namespace byps {

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BMETHODRESULT_HPP_
#define BMETHODRESULT_HPP_

#include "BMethodResult.h"

namespace byps {

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BNEGOTIATE_HPP_
#define BNEGOTIATE_HPP_

#include "BNegotiate.h"
#include "BBytes.h"
#include "BByteOrder.h"
#include <algorithm>
#include <string.h>

// If Windows.h is included, min is defined as a macro. 
// This causes a compiler error at min.
#undef min


namespace byps {

BINLINE BNegotiate::BNegotiate(PApiDescriptor apiDesc) {
    version = 0;
	protocols = apiDesc->getProtocolIds();
}

BINLINE BNegotiate::BNegotiate() {
    version = 0;
}

BINLINE void BNegotiate::write(const PBytes& bytes) {
	stringstream ss;
    ss	<< NEGOTIATE_MAGIC_DOUBLE_QUOTES << ",\""
		<< protocols << "\","
        << "\"" << BVersioning::longToString<char>(version) << "\",\""
        << ((BByteOrder::getMyEndian() == BLITTLE_ENDIAN) ? "L" : "B")
		<< "\", \"\"]";

	string str = ss.str();
	size_t len = min(str.size(), bytes->length);
	memcpy(bytes->data, str.c_str(), len);
	bytes->length = len;
}

BINLINE void BNegotiate::read(const PBytes& bytes) {
	char* p = (char*)bytes->data;
	size_t idx = 0;

	// Magic ["N"

	size_t len = min((size_t)4, bytes->length);
    if (strncmp(p, NEGOTIATE_MAGIC_DOUBLE_QUOTES, len) != 0) throw BException(EX_CORRUPT);

	idx += len;
	if (idx >= bytes->length) throw BException(EX_CORRUPT);

	if (p[idx] != ',') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	// Protokolle

	if (p[idx] != '\"') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	for (; idx < bytes->length && p[idx] != '\"'; idx++) {
        protocols += p[idx];
	}

	if (++idx >= bytes->length) throw BException(EX_CORRUPT);
	if (p[idx] != ',') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	// Version

	if (p[idx] != '\"') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	std::stringstream ssversion;
	for (; idx < bytes->length && p[idx] != '\"'; idx++) {
        ssversion << p[idx];
	}
	version = BVersioning::stringToLong(ssversion.str());

	if (++idx >= bytes->length) throw BException(EX_CORRUPT);
	if (p[idx] != ',') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	// Byteorder

	if (p[idx] != '\"') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	byteOrder = p[idx] == 'B' ? BBIG_ENDIAN : BLITTLE_ENDIAN;

	if (++idx >= bytes->length) throw BException(EX_CORRUPT);
	if (p[idx] != '\"') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);
	if (p[idx] != ',') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	// Target-ID

	if (p[idx] != '\"') throw BException(EX_CORRUPT);
	if (++idx >= bytes->length) throw BException(EX_CORRUPT);

	size_t idxTargetIdBegin = idx;
	for (; idx < bytes->length && p[idx] != '\"'; idx++) {}

	targetId = BTargetId::parseString(std::string(p + idxTargetIdBegin, idx - idxTargetIdBegin));

}

BINLINE bool BNegotiate::isNegotiateMessage(PBytes bytes) {
	char* p = (char*)bytes->data;
	size_t len = min((size_t)4, bytes->length);
    if (len < 4) return false;
    return strncmp(p, NEGOTIATE_MAGIC_DOUBLE_QUOTES, len) == 0 ;
}

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BOUTPUT_HPP
#define BOUTPUT_HPP

#include "Byps.h"

namespace byps {

BINLINE BOutput::BOutput(PTransport transport, BVERSION negotiatedVersion, BByteOrder negotiatedByteOrder)
    : BIO(transport, BBinaryModel::MEDIUM(), negotiatedVersion, negotiatedByteOrder)
    , nextPointer(0)
{
    header.targetId = transport->targetId;
}

BINLINE BOutput::BOutput(PTransport transport, const BMessageHeader &responseHeader)
    : BIO(transport, BBinaryModel::MEDIUM(), responseHeader.version, responseHeader.byteOrder)
    , nextPointer(0)
{
	header = responseHeader;
    header.targetId = transport->targetId;
}


BINLINE BOutput::~BOutput() {
}

BINLINE void BOutput::store(PSerializable ptr) {
    header.write(bbuf);
    (*this) & ptr;
}

BINLINE void BOutput::internalStoreObj(POBJECT pObj, bool, BSERIALIZER ser, BTYPEID typeId) {

    if (pObj != NULL) {

        OBJMAP::iterator it = objMap.find(pObj.get());
        if (it != objMap.end()) {
            BPOINTER id = - (*it).second;
            bbuf.serializePointer(id);
        }
        else {
            BPOINTER id = ++nextPointer;

            objMap.insert( OBJMAP::value_type(pObj.get(), id));

            bbuf.serializePointer(id);

            bbuf.serializeTypeId(typeId);

            PSerializable NULLS;
            ser(*this, pObj, NULLS, NULL);
        }

    }
    else {
        // NULL-Reference
        BPOINTER id = 0;
        bbuf.serializePointer(id);
    }
}

BINLINE void BOutput::internalStoreObjS(PSerializable pObjS, bool, BSERIALIZER ser, BTYPEID typeId) {

    if (pObjS != NULL) {

        OBJMAP::iterator it = objMap.find(pObjS.get());
        if (it != objMap.end()) {
            BPOINTER id = - (*it).second;
            bbuf.serializePointer(id);
        }
        else {
            BPOINTER id = ++nextPointer;

            objMap.insert( OBJMAP::value_type(pObjS.get(), id));

            bbuf.serializePointer(id);

            bbuf.serializeTypeId(typeId);

            POBJECT NULLO;
            ser(*this, NULLO, pObjS, NULL);
        }

    }
    else {
        // NULL-Reference
        BPOINTER id = 0;
        bbuf.serializePointer(id);
    }
}

BINLINE PStreamRequest BOutput::createStreamRequest(PContentStream inputStream) {
    PStreamRequest stream(new BStreamRequest());
    stream->messageId = header.messageId;
    stream->streamId = transport->wire->makeMessageId();
    stream->strm = inputStream;
    streams.push_back(stream);
    return stream;
}

BINLINE PMessage BOutput::toMessage() {
    PMessage msg(new BMessage(header, bbuf.getBytes(), streams));
    return msg;
}


BINLINE void BOutput::setException(const BException& bex) {

	bbuf.clear();

	header.error = bex.getCode();
	header.write(bbuf);

	BTYPEID typeId = BTYPEID_EXCEPTION;
	BPOINTER id = ++nextPointer;
	bbuf.serializePointer(id);
	bbuf.serializeTypeId(typeId);

	BException& ex2 = const_cast<BException&>(bex);
	*this & ex2;
}

}

#endif // BOUTPUT_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BPROTOCOL_HPP_
#define BPROTOCOL_HPP_

#include "BProtocol.h"
#include "BOutput.h"
#include "BInput.h"

namespace byps {

BINLINE BProtocol::BProtocol(PApiDescriptor apiDesc, BVERSION negotiatedVersion, BByteOrder negotiatedByteOrder)
: apiDesc(apiDesc), m_nNegotiatedVersion(negotiatedVersion), m_negotiatedByteOrder(negotiatedByteOrder) {
}

BINLINE POutput BProtocol::getOutput(PTransport transport, const BMessageHeader& responseHeader) {
    if (responseHeader.magic != 0) {
        return POutput(new BOutput(transport, responseHeader));
    }
    else {
        return POutput(new BOutput(transport, m_nNegotiatedVersion, m_negotiatedByteOrder));
    }
}
BINLINE PInput BProtocol::getInput(PTransport transport, const BMessageHeader &header, PBytes& pBytes) {
    return PInput(new BInput(transport, header, pBytes));
}

BINLINE PRegistry BProtocol::getRegistry() {
	return apiDesc->getRegistry(BBinaryModel::MEDIUM());
}

}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
/*
 * BRegistry.h
 *
 *  Created on: 29.07.2012
 *      Author: Wolfgang
 */

#ifndef BREGISTRY_HPP_
#define BREGISTRY_HPP_

#include "BRegistry.h"

namespace byps {


BINLINE void BSerializer_12(BIO& bio, POBJECT& pObj, PSerializable& , void* ){
	void* p = pObj.get();
	if (p) { 
		vector< PSerializable >& r = * reinterpret_cast<vector< PSerializable >*>(p);
		bio & r;
	} else {
		pObj = POBJECT(new vector< PSerializable >());
	}
}

BINLINE void BSerializer_14(BIO& bio, POBJECT& pObj, PSerializable& , void* ){
	void* p = pObj.get();
	if (p) { 
		set< PSerializable >& r = * reinterpret_cast<set< PSerializable >*>(p);
		bio & r;
	} else {
		pObj = POBJECT(new set< PSerializable >());
	}
}


BINLINE BRegistry::BRegistry() {
	registerClass(typeid(BContentStream), BContentStream::serialize, BTYPEID_STREAM);
	registerClass(typeid(vector<PSerializable>), BSerializer_12, BTYPEID_LIST);
	registerClass(typeid(set<PSerializable>), BSerializer_14, BTYPEID_SET);
}

BINLINE BRegistry::~BRegistry() {
}

BINLINE void BRegistry::registerClass(const type_info& tinfo, BSERIALIZER ser, BTYPEID typeId) {
    mapSerializer[typeId] = ser;
    size_t hc = tinfo.hash_code();
    mapTypeIds[hc] = typeId;
}


BINLINE BSERIALIZER BRegistry::getSerializer(const type_info& tinfo, BTYPEID &typeId) {
    BSERIALIZER ser = NULL;
    size_t hc = tinfo.hash_code();
    typeId = mapTypeIds[hc];
    if (typeId != 0) {
        ser = mapSerializer[typeId];
    }
    if (!ser) {
        wstringstream ss; ss << L"Missing serializer for " << BToStdWString(tinfo.name());
        throw BException(EX_CORRUPT, ss.str());
    }
    return ser;
}

BINLINE BSERIALIZER BRegistry::getSerializer(BTYPEID typeId) {
    BSERIALIZER ser = mapSerializer[typeId];
    if (!ser) {
        wstringstream ss; ss << L"Missing serializer for typeId=" << typeId;
        throw BException(EX_CORRUPT, ss.str());
    }
    return ser;
}

}

#endif /* BREGISTRY_H_ */
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSERIALIZABLE_HPP_
#define BSERIALIZABLE_HPP_

#include "Byps.h"

namespace byps {

}

#endif /* BSERIALIZABLE_H_ */
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSERIALIZER_HPP
#define BSERIALIZER_HPP

#include "BSerializer.h"

namespace byps {


BINLINE BSerializer::BSerializer(BTYPEID typeId)
    : typeId(typeId) {
}


}

#endif // BSERIALIZER_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSERVER_HPP
#define BSERVER_HPP

#include "Byps.h"

namespace byps {


BINLINE BServer::BServer(PTransport transport, PClient clientR)
    : transport(transport), clientR(clientR) {
}

BINLINE BServer::~BServer() {
}

BINLINE void BServer::addRemote(BTYPEID typeId, PSkeleton remote) {
	if (remote) {
		remotes[typeId] = remote;
		remote->BSkeleton_setTargetId(transport->getTargetId());
	}
	else {
		auto it = remotes.find(typeId);
		if (it != remotes.end()) {
			remotes.erase(it);
		}
	}
}


BINLINE PProtocol BServer::negotiate(const BTargetId& targetId, PBytes& buf, PAsyncResult &asyncResult) {
    return transport->negotiateProtocolServer(targetId, buf, asyncResult);
}

BINLINE void BServer::recv(const BTargetId& clientTargetId, PSerializable methodObj, PAsyncResult methodResult) {

    try {
        PMethodRequest method = byps_ptr_cast<BMethodRequest>(methodObj);
        if (!method) {
            throw BException(EX_CORRUPT, L"Message is not a method");
        }

        PRemote remote;
        const BTYPEID remoteId = method->remoteId;
        const BTargetId serverTargetId = this->transport->getTargetId();

        if (clientTargetId == serverTargetId) {
            remote = remotes[remoteId];
        }
        else if (transport->getRemoteRegistry()) {
            remote = transport->getRemoteRegistry()->getRemote(clientTargetId, remoteId);
        }

        if (!remote) {
            wstringstream ss;
            ss << L"Service not implemented: remoteId=" << remoteId;
            throw BException(EX_SERVICE_NOT_IMPLEMENTED, ss.str());
        }

        method->execute(remote, methodResult);
    }
    catch (const BException& ex) {
        methodResult->setAsyncResult(BVariant(ex));
    }
    catch (...) {
        BException ex(EX_CORRUPT);
        methodResult->setAsyncResult(BVariant(ex));
    }
}



BINLINE BServerR::BServerR(PTransport transport, PServer server)
    : transport(transport), server(server) {
}

BINLINE BServerR::~BServerR() {
}

BINLINE void BServerR::start() {
}

BINLINE void BServerR::done() {
}


}

#endif // BSERVER_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSKELETON_HPP
#define BSKELETON_HPP

#include "BSkeleton.h"

namespace byps {

BINLINE BSkeleton::~BSkeleton() {
}

BINLINE BTargetId BSkeleton::BRemote_getTargetId() {
    return targetId;
}

BINLINE void BSkeleton::BSkeleton_setTargetId(BTargetId targetId) {
    this->targetId = targetId;
}

}
#endif // BSKELETON_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSTREAMREQUEST_HPP
#define BSTREAMREQUEST_HPP


namespace byps {

BINLINE BStreamRequest::BStreamRequest()
    : streamId(0), messageId(0) {
}

BINLINE BStreamRequest::BStreamRequest(const BStreamRequest& rhs)
    : streamId(rhs.streamId)
    , messageId(rhs.messageId)
    , strm(rhs.strm) {
}

}


#endif // BSTREAMREQUEST_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BSTUB_HPP
#define BSTUB_HPP

#include "BStub.h"

namespace byps {

BINLINE BStub::BStub(PTransport transport)
    : transport(transport) {
}

BINLINE BStub::~BStub() {
}

BINLINE BTargetId BStub::BRemote_getTargetId() {
    return transport->getTargetId();
}


}

#endif // BSTUB_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BTARGETID_HPP
#define BTARGETID_HPP

#include "BTargetId.h"
#include "BBuffer.h"

namespace byps {

BINLINE BTargetId::BTargetId() : serverId(0), v1(0), v2(0) {
}

BINLINE BTargetId::BTargetId(int32_t serverId, int64_t v1, int64_t v2) 
	: serverId(serverId), v1(v1), v2(v2) {
}

BINLINE bool BTargetId::isZero() {
    return serverId == 0 && v1 == 0 && v2 == 0;
}

BINLINE bool BTargetId::operator==(const BTargetId& rhs) const {
    return serverId == rhs.serverId && v1 == rhs.v1 && v2 == rhs.v2;
}

BINLINE std::wstring BTargetId::toString() const {
	std::wstringstream ss;
	ss << (*this);
	return ss.str();
}

BINLINE BTargetId BTargetId::parseString(const string& s) {
	int32_t serverId = 0;
	int64_t v1 = 0, v2 = 0;

	stringstream ss;
	for (string::const_iterator it = s.begin(); it != s.end(); it++) {
		ss << ((*it == '.') ? ' ' : *it);
	}

	ss >> serverId >> v1 >> v2;

	return BTargetId(serverId, v1, v2);
}

BINLINE void BTargetId::serialize(BBuffer& bbuf) {
	bool cmpr = bbuf.setCompressInteger(false);
	bbuf.serialize(serverId);
	bbuf.serialize(v1);
	bbuf.serialize(v2);
	bbuf.setCompressInteger(cmpr);
}



}

#endif // BTARGETID_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BTHREADPOOL_HPP_
#define BTHREADPOOL_HPP_

#ifndef BTHREADPOOL
#define BTHREADPOOL

#include "Byps.h"

#include <thread>

namespace byps { 

class BThreadPoolImpl;
typedef byps_ptr<BThreadPoolImpl> PThreadPoolImpl;

class BThreadPoolImpl : public BThreadPool, public byps_enable_shared_from_this<BThreadPoolImpl> {
	byps_mutex mutex;
	byps_condition_variable queueItemAdded;
	byps_condition_variable queueItemRemoved;
	vector<PRunnable> queue;
	int maxThreads;
	int fullLimit;
	byps_atomic<bool> isDone;

	typedef byps_ptr<thread> PThread;
	map<thread::id, PThread> allThreads;
	map<thread::id, bool> runningThreads;

	PRunnable nextRunnableUnsync(byps_unique_lock& lock) {

		chrono::duration<int,milli> timeout(100 * 1000);

		bool succ = queueItemAdded.wait_for(lock, timeout, [this](){ 
			return this->isDone || this->queue.size() != 0; 
		});

		PRunnable r;
		if (succ && !isDone) {
			r = queue.front();
			queue.erase(queue.begin());
			queueItemRemoved.notify_all();
		}

		return r;
	}
	
	static void threadFunction(PThreadPoolImpl tpool) {
		thread::id tid = this_thread::get_id();

		while (true) {
			PRunnable r;

			{
				byps_unique_lock lock(tpool->mutex);
				r = tpool->nextRunnableUnsync(lock);
				if (!r) {
					break;
				}
			}

			try {
				r->run();
			}
			catch (...) {
			}

		}

		{
			byps_unique_lock lock(tpool->mutex);
			tpool->runningThreads[tid] = false;
		}
	}

	void removeStoppedThreadsUnsync(vector<PThread>& stoppedThreads) {
		vector<thread::id> killIds;
		killIds.reserve(runningThreads.size());
		for (map<thread::id, bool>::iterator it = runningThreads.begin(); it != runningThreads.end(); it++) {
			if ((*it).second) continue;
			killIds.push_back((*it).first);
		}
		for (unsigned i = 0; i < killIds.size(); i++) {
			PThread t = allThreads[killIds[i]];
			stoppedThreads.push_back(t);
			allThreads.erase(killIds[i]);
			runningThreads.erase(killIds[i]);
		}
	}

	void killStoppedThreads(vector<PThread>& stoppedThreads) {
		for (unsigned i = 0; i < stoppedThreads.size(); i++) {
			PThread t = stoppedThreads[i];
			if (t && t->joinable()) {
				t->join();
			}
			stoppedThreads[i] = PThread();
		}
	}

public:
	BThreadPoolImpl(int maxThreads) 
		: maxThreads(maxThreads)
		, fullLimit(maxThreads * 2)
		, isDone(false) {
	}

    virtual ~BThreadPoolImpl() {
    }

    virtual void done() {

		bool expectedDone = false;
		if (isDone.compare_exchange_strong(expectedDone, true)) {

			queueItemAdded.notify_all();
			queueItemRemoved.notify_all();

			vector<PThread> stoppedThreads;
			{
				byps_unique_lock lock(mutex);

				for (map<thread::id, bool>::iterator it = runningThreads.begin(); it != runningThreads.end(); it++) {
					(*it).second = false;
				}
				removeStoppedThreadsUnsync(stoppedThreads);
			}
			killStoppedThreads(stoppedThreads);
		}
	}

	virtual bool execute(PRunnable r) {
		
		vector<PThread> stoppedThreads;

		{
			byps_unique_lock lock(this->mutex);
		
			this->queueItemRemoved.wait(lock, [this](){ 
				return this->isDone || this->queue.size() < (size_t)fullLimit || !shared_from_this(); 
			});

			PThreadPoolImpl pThis = shared_from_this();
			if (pThis && !isDone) {

				removeStoppedThreadsUnsync(stoppedThreads);

				// Start new thread, if all threads busy
				if (queue.size() >= runningThreads.size()) {
					if (runningThreads.size() < (size_t)maxThreads) {
						PThread t(new thread(threadFunction, pThis));
						runningThreads[t->get_id()] = true;
						allThreads[t->get_id()] = t;
					}
				}

				this->queue.push_back(r);
			}

			this->queueItemAdded.notify_all();
		}
		
		killStoppedThreads(stoppedThreads);

		return !isDone;
	}



	static PThreadPool createInstance();
};

BINLINE PThreadPool BThreadPool::create(void* app, int maxThreads) {
	PThreadPoolImpl tpool(new BThreadPoolImpl(maxThreads));
	return tpool;
}



}

#endif // BTHREADPOOL

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BTRANSPORT_HPP_
#define BTRANSPORT_HPP_

#include "BTransport.h"

namespace byps {

using namespace std::chrono;

BINLINE BTransport::BTransport(PApiDescriptor apiDesc, const PWire& wire, const PRemoteRegistry &remoteRegistry)
    : wire(wire)
	, remoteRegistry(remoteRegistry)
	, apiDesc(apiDesc)
	, protocol(PProtocol())
{
}

BINLINE BTransport::BTransport(const BTransport &rhs, const BTargetId &targetId)
    : wire(rhs.wire)
	, remoteRegistry(rhs.remoteRegistry)
	, apiDesc(rhs.apiDesc)
	, protocol(rhs.protocol)
	, targetId(targetId)
{
}

BINLINE BTransport::~BTransport() {
}

BINLINE POutput BTransport::getOutput() {

	PTransport pthis = shared_from_this();
	if (!pthis) throw BException(EX_CANCELLED);

    return getProtocol()->getOutput(pthis, BMessageHeader());
}

BINLINE POutput BTransport::getResponse(BMessageHeader& requestHeader) {

	PTransport pthis = shared_from_this();
	if (!pthis) throw BException(EX_CANCELLED);

	BMessageHeader responseHeader(requestHeader);
	responseHeader.flags |= BHEADER_FLAG_RESPONSE;
    return getProtocol()->getOutput(pthis, responseHeader);
}

BINLINE PInput BTransport::getInput(BMessageHeader& header, PBytes& buf) {
    return getProtocol()->getInput(shared_from_this(), header, buf);
}

BINLINE BTargetId BTransport::getTargetId() {
    byps_unique_lock lock(mtx);
    return targetId;
}

BINLINE void BTransport::setTargetId(BTargetId targetId) {
    byps_unique_lock lock(mtx);
    targetId = targetId;
}

BINLINE PProtocol BTransport::getProtocol() {
    byps_unique_lock lock(mtx);
    return protocol;
}

BINLINE PWire BTransport::getWire() {
	return wire;
}

BINLINE PRemoteRegistry BTransport::getRemoteRegistry() {
	return remoteRegistry;
}

BINLINE PApiDescriptor BTransport::getApiDesc() {
	return apiDesc;
}

class BTransport_ReloginAndRetrySend;
typedef BTransport_ReloginAndRetrySend* PTransport_BAsyncOuterResult;

class BTransport_ReloginAndRetrySend : public BAsyncResult {
	PTransport transport;
	PSerializable requestObject; 
	PAsyncResult innerResult;
public:
	BTransport_ReloginAndRetrySend(PTransport transport, PSerializable requestObject, PAsyncResult innerResult) 
		: transport(transport)
		, requestObject(requestObject)
		, innerResult(innerResult)
	{
	}

    virtual void setAsyncResult(const BVariant& result) {
		try {
            if (result.isException()) {
                innerResult->setAsyncResult(BVariant(result.getException()));
            }
            else {
				transport->assignSessionThenSendMethod(requestObject, innerResult);
            }
		}
        catch (const exception& ex) {
            innerResult->setAsyncResult(BVariant(ex));
		}
		delete this;
	}

};

class BTransport_MyNegoAsyncResult : public BAsyncResult {
public:
	PTransport transport;
    PAsyncResult innerResult;

    BTransport_MyNegoAsyncResult(PTransport transport, const PAsyncResult& innerResult)
		: transport(transport), innerResult(innerResult) {
	}
	virtual ~BTransport_MyNegoAsyncResult() {
	}

    virtual void setAsyncResult(const BVariant& result) {
		try {
            if (result.isException()) {
                innerResult->setAsyncResult(result);
            }
            else {
				POBJECT obj;
				result.get(obj);
                PMessage msg = byps_static_ptr_cast<BMessage>(obj);

                BNegotiate nego;
                nego.read(msg->buf);
                {
                    byps_unique_lock lock(transport->mtx);
                    transport->protocol = transport->createNegotiatedProtocol(nego);
                    transport->targetId = nego.targetId;
                }

				transport->internalAuthenticate(innerResult);
            }
		}
        catch (const exception& ex) {
            innerResult->setAsyncResult(BVariant(ex));
		}
		delete this;
	}

};

class BTransport_DeserlializeMethodResultMaybeRelogin : public BAsyncResult {
	PTransport transport;
	PSerializable requestObject; 
	PAsyncResult innerResult;
public:
	BTransport_DeserlializeMethodResultMaybeRelogin(PTransport transport, PSerializable requestObject, PAsyncResult innerResult) 
		: transport(transport)
		, requestObject(requestObject)
		, innerResult(innerResult)
	{
	}

	virtual ~BTransport_DeserlializeMethodResultMaybeRelogin() {}

    virtual void setAsyncResult(const BVariant& result) { 
		bool relogin = false;

		try {
            if (result.isException()) {
				relogin = internalIsReloginException(result.getException());
				if (!relogin) {
					innerResult->setAsyncResult(BVariant(result.getException()));
				}
            }
            else {
				try {
					POBJECT obj;
					result.get(obj);
                    if (obj) {
                        PMessage msg = byps_static_ptr_cast<BMessage>(obj);

                        PInput inp = transport->getInput(msg->header, msg->buf);
                        PSerializable sobj = inp->load();
                        innerResult->setAsyncResult(BVariant(sobj));
                    }
                    else {
                        BException ex(EX_CORRUPT, L"Missing message object in result.");
                        innerResult->setAsyncResult(BVariant(ex));
                    }
				}
				catch (const BException& e) {
					relogin = internalIsReloginException(e);
					if (!relogin) {
						innerResult->setAsyncResult(BVariant(e));
					}
				}
            }

			if (relogin) {
				transport->loginAndRetrySend(requestObject, innerResult);
 			}
		}
        catch (const exception& ex) {
            innerResult->setAsyncResult(BVariant(ex));
		}

		delete this;
	}

private:
	bool internalIsReloginException(BException e) {
		BTYPEID typeId = requestObject->BSerializable_getTypeId();
        return transport->internalIsReloginException(e, typeId);
    }

};

BINLINE void BTransport::loginAndRetrySend(PSerializable requestObject, PAsyncResult asyncResult) {
	// Cancel long-polls.
	// They will be restarted over negotiateProtocolClient and BClient::authentication.
	wire->cancelAllRequests();

	PAsyncResult loginResult(new BTransport_ReloginAndRetrySend(shared_from_this(), requestObject, asyncResult));

    negotiateProtocolClient(loginResult);
}


BINLINE void BTransport::negotiateProtocolClient(PAsyncResult asyncResult) {
	PTransport pthis = shared_from_this();
	if (!pthis) return;

	PBytes bytes = BBytes::create(NEGOTIATE_MAX_SIZE);
	BNegotiate nego(apiDesc);
    nego.version = apiDesc->version;
    nego.write(bytes);

    PAsyncResult outerResult = new BTransport_MyNegoAsyncResult(pthis, asyncResult);

    BMessageHeader header;
    header.messageId = wire->makeMessageId();
    vector<PStreamRequest> streams;
    PMessage msg(new BMessage(header, bytes, streams));

    wire->send(msg, outerResult);
}

BINLINE PProtocol BTransport::negotiateProtocolServer(const BTargetId& targetId, PBytes& buf, PAsyncResult asyncResult) {
	try {
        bool succ = BNegotiate::isNegotiateMessage(buf);
		if (succ) {
			BNegotiate nego;
            nego.read(buf);

            {
                byps_unique_lock lock(mtx);
                protocol = createNegotiatedProtocol(nego);
                this->targetId = targetId;
            }

			PBytes bytes = BBytes::create(NEGOTIATE_MAX_SIZE);
            nego.targetId = targetId;
            nego.write(bytes);

            asyncResult->setAsyncResult(BVariant(bytes));
		}
	}
    catch (const exception& ex) {
        asyncResult->setAsyncResult(BVariant(ex));
	}
    return protocol;
}

BINLINE PProtocol BTransport::createNegotiatedProtocol(BNegotiate& nego) {
	PProtocol protocol;

    if (nego.protocols.size() == 0) {
		throw BException(EX_CORRUPT, L"Protocol negotiation failed. Cannot detect protocol.");
	}

    if (nego.protocols.find(BBinaryModel::MEDIUM().getProtocolId()) != string::npos) {
        BVERSION negotiatedVersion = min(nego.version, apiDesc->version);
        protocol = PProtocol(new BProtocol(apiDesc, negotiatedVersion, nego.byteOrder));
        nego.protocols = BBinaryModel::MEDIUM().getProtocolId();
        nego.version = negotiatedVersion;
	}
	else {
		throw BException(EX_CORRUPT, L"Protocol negotiation failed. Cannot detect protocol.");
	}
	return protocol;
}

BINLINE PProtocol BTransport::detectProtocolFromInputBuffer(const PBytes&) {
    return PProtocol();
}

BINLINE void BTransport::sendMethod(const PMethodRequest& methodRequest, PAsyncResult asyncResult) {
	assignSessionThenSendMethod(methodRequest, asyncResult);
}

BINLINE void BTransport::send(const PSerializable& obj, PAsyncResult asyncResult) {

	PTransport pthis = shared_from_this();
	if (!pthis) throw BException(EX_CANCELLED);

	try {
        POutput outp = getOutput();
		outp->store(obj);

        PAsyncResult outerResult = new BTransport_DeserlializeMethodResultMaybeRelogin(pthis, obj, asyncResult);

        PMessage msg = outp->toMessage();
        
		wire->send(msg, outerResult);

	}
    catch (const exception& ex) {
        asyncResult->setAsyncResult(BVariant(ex));
	}
}

class BTransport_AssingSessionThenSendMethod : public BAsyncResult {
	PTransport pTransport;
	PSerializable requestObject;
	PAsyncResult asyncResult;
public:
	BTransport_AssingSessionThenSendMethod(PTransport pTransport, PSerializable requestObject, PAsyncResult asyncResult) 
		: pTransport(pTransport), requestObject(requestObject), asyncResult(asyncResult) {
	}
	virtual void setAsyncResult(const BVariant& result) {
		if (result.isException()) {
			asyncResult->setAsyncResult(result);
		}
		else {
			PMethodRequest methodRequest = byps_ptr_cast<BMethodRequest>(requestObject);
			if (methodRequest) {
				PSerializable session;
				result.get(session);
				methodRequest->setSession(session);
			}
			pTransport->send(methodRequest, asyncResult);
		}
		delete this;
	}
};

BINLINE void BTransport::assignSessionThenSendMethod(PSerializable requestObject, PAsyncResult asyncResult) {
	if (this->authentication) {
		try {
			BTYPEID typeId = getObjectTypeId(requestObject);
			PAsyncResult sessionResult(new BTransport_AssingSessionThenSendMethod(shared_from_this(), requestObject, asyncResult));
			this->authentication->getSession(PClient(), typeId, sessionResult);
		}
		catch (const BException& ex) {
			asyncResult->setAsyncResult(BVariant(ex));
		}
	}
	else {
		this->send(requestObject, asyncResult);
	}
}

BINLINE BTYPEID BTransport::getObjectTypeId(PSerializable ser)
{
	BTYPEID typeId = 0;
	getProtocol()->getRegistry()->getSerializer(typeid(*ser.get()), typeId);
	return typeId;
}

class BTransport_MethodResult : public BAsyncResult {
	POutput outp;
    PAsyncResult innerResult;
public:
	BTransport_MethodResult(POutput outp, PAsyncResult innerResult)
		: outp(outp), innerResult(innerResult) {
	}
	virtual void setAsyncResult(const BVariant& var) {
		try {
			if (var.isException()) {
				outp->setException(var.getException());
			}
			else {
				PSerializable obj;
				var.get(obj);
				outp->store(obj);
			}
			PMessage msg = outp->toMessage();

			innerResult->setAsyncResult(BVariant(msg));
		}
		catch (const exception& ex) {
			innerResult->setAsyncResult(BVariant(ex));
		}
		delete this;
	}
};

BINLINE void BTransport::recv(PServer server, PMessage message, PAsyncResult asyncResult) {

	PInput bin = getInput(message->header, message->buf);
	PSerializable methodObject = bin->load();

	POutput bout = getResponse(bin->header);
	PAsyncResult methodResult(new BTransport_MethodResult(bout, asyncResult));

	BTargetId clientTargetId = bin->header.targetId;
	server->recv(clientTargetId, methodObject, methodResult);

}

BINLINE bool BTransport::internalIsReloginException(BException ex, BTYPEID typeId) {
	bool ret = false;

	if (authentication && ex) {
		ret = authentication->isReloginException(PClient(), ex, typeId);
	}

	return ret;
}

BINLINE bool BTransport::isReloginException(BException ex, int ) {
    bool ret = false;
    
    // Check exception
    if (ex) 
    {
        ret = ex.getCode() == EX_UNAUTHORIZED;
    }
      
    return ret;
}


class BTransport_InternalAuthenticate_BAsyncResult : public BAsyncResult
{
public:
	BTransport_InternalAuthenticate_BAsyncResult(PTransport transport)
		: transport(transport)
    {
    }

    virtual void setAsyncResult(const BVariant& result) {

		BException ex = result.getException();
		std::vector<PAsyncResult> copyResults;

		{
			byps_unique_lock lock(transport->mtx);
            copyResults = transport->asyncResultsWaitingForAuthentication;
            transport->asyncResultsWaitingForAuthentication.clear();
            transport->lastAuthenticationTime = system_clock::now();
			transport->lastAuthenticationException = ex;
        }

        for (size_t i = 0; i < copyResults.size(); i++)
        {
            copyResults[i]->setAsyncResult(result);
        }

		delete this;
    }

private:
	PTransport transport;
};


const unsigned RETRY_AUTHENTICATION_AFTER_MILLIS = 1 * 1000;

BINLINE void BTransport::internalAuthenticate(PAsyncResult innerResult) {

	if (authentication) {
		
		bool first = false;
		bool assumeAuthenticationIsValid = false;

		{
			byps_unique_lock lock(mtx);

			system_clock::time_point now = system_clock::now();
			milliseconds diff = duration_cast<milliseconds>(now - lastAuthenticationTime);
			assumeAuthenticationIsValid = RETRY_AUTHENTICATION_AFTER_MILLIS >= diff.count();

			if (!assumeAuthenticationIsValid)
			{
				first = asyncResultsWaitingForAuthentication.size() == 0;
				asyncResultsWaitingForAuthentication.push_back(innerResult);
			}
		}

		if (first) {
			
			PAsyncResult authResult(new BTransport_InternalAuthenticate_BAsyncResult(shared_from_this()));
			authentication->authenticate(PClient(), authResult);

		}
		else if (assumeAuthenticationIsValid) {
			innerResult->setAsyncResult(BVariant(lastAuthenticationException));
		}
		else {
            // innerResult has been added to asyncResultsWaitingForAuthentication 
            // and will be called in InternalAuthenticate_BAsyncResult
		}

	}
	else {
		innerResult->setAsyncResult(BVariant(true));
	}
}

BINLINE void BTransport::setAuthentication(PAuthentication auth, bool onlyIfNull) {
	byps_unique_lock lock(mtx);
	if (onlyIfNull && authentication) return;
	authentication = auth;
	lastAuthenticationException = BException();
	lastAuthenticationTime = system_clock::time_point();
	asyncResultsWaitingForAuthentication.clear();
}


}



#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BUTILS_HPP_
#define BUTILS_HPP_

#include "BUtils.h"

namespace byps {

BINLINE wstring BToStdWString(const string& str) {
	return BToStdWString(str.c_str(), str.length());
}

BINLINE wstring BToStdWString(const char* str, size_t len) {
	if (str == NULL || len == 0) return wstring();
	if (len == string::npos) len = strlen(str);
	wstringstream ss;
	for (size_t i = 0; i < len; i++) {
		ss << (wchar_t)str[i];
	}
	return ss.str();
}

}


#endif /* BUTILS_H_ */
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BVALUECLASS_HPP_
#define BVALUECLASS_HPP_

#include "BValueClass.h"

namespace byps {

BINLINE void BValueClass::serialize(BIO& ar, const BVERSION ) {
	ar & changedMembers;
}


}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BVariant_HPP
#define BVariant_HPP

#include "BVariant.h"

namespace byps {

BINLINE void BVariant::clear() {
	u.longVal = 0;
}

BINLINE void BVariant::serialize(BIO& ar, BVERSION) {
    switch(type) {
	case BTYPEID_VOID: break;
    case BTYPEID_BOOL: ar & u.boolVal; break;
    case BTYPEID_WCHAR: ar & u.charVal; break;
    case BTYPEID_INT8: ar & u.byteVal; break;
    case BTYPEID_INT16: ar & u.shortVal; break;
    case BTYPEID_INT32: ar & u.intVal; break;
    case BTYPEID_INT64: ar & u.longVal; break;
    case BTYPEID_FLOAT: ar & u.floatVal; break;
    case BTYPEID_DOUBLE: ar & u.doubleVal; break;
    case BTYPEID_STRING: ar & strVal; break;
    default:
        if (ar.is_loading) {
            PSerializable obj;
            ar & obj;
            sobjVal = obj;
            type = BTYPEID_OBJECT;
        }
        else {
            PSerializable obj = byps_static_ptr_cast<BSerializable>(sobjVal);
            ar & obj;
        }
        break;
    }
}

BINLINE std::wstring BVariant::toString() const {
    std::wstringstream wss;
    switch(type) {
    case BTYPEID_VOID:
        wss << L"(void)";
        break;
    case BTYPEID_BOOL:
        wss << (u.boolVal ? L"true" : L"false");
        break;
    case BTYPEID_WCHAR:
        wss << u.charVal;
        break;
    case BTYPEID_INT8:
        wss << (int)u.byteVal;
        break;
    case BTYPEID_INT16:
        wss << u.shortVal;
        break;
    case BTYPEID_INT32:
        wss << u.intVal;
        break;
    case BTYPEID_INT64:
        wss << u.longVal;
        break;
    case BTYPEID_FLOAT:
        wss << u.floatVal;
        break;
    case BTYPEID_DOUBLE:
        wss << u.doubleVal;
        break;
    case BTYPEID_STRING:
        wss << strVal;
        break;
    case BTYPEID_OBJECT:
        wss << (sobjVal ? (void*)sobjVal.get() : (void*)objVal.get());
        break;
    case BTYPEID_EXCEPTION:
        wss << exVal.toString();
        break;
    default:
        wss << L"(invalid type " << type << L")";
        break;
    }
    return wss.str();
}

}

#endif // BINLINE BVariant::BVariant_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BWIRE_HPP_
#define BWIRE_HPP_

#include "BWire.h"
#include <stdlib.h>

namespace byps {


BINLINE BWire::~BWire() {
}

BINLINE void BWire::send(const PMessage& , PAsyncResult ) {

}

BINLINE void BWire::sendR(const PMessage& , PAsyncResult ) {

}

BINLINE PContentStream BWire::getStream(int64_t , int64_t ) {
	return PContentStream();
}

BINLINE int64_t BWire::makeMessageId() {
    return 1;
}

BINLINE void BWire::done() {
}

BINLINE void BWire::cancelAllRequests() {
}

BINLINE PTestAdapter BWire::getTestAdapter() {
	return PTestAdapter();
}

}
#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BYPS_HPP_
#define BYPS_HPP_

#include "Byps.h"

#include "BArray.hpp"
#include "BAsyncResult.hpp"
#include "BBytes.hpp"
#include "BBuffer.hpp"
#include "BClient.hpp"
#include "BContentStream.hpp"
#include "BException.hpp"
#include "BInput.hpp"
#include "BIO.hpp"
#include "BMessage.hpp"
#include "BMessageHeader.hpp"
#include "BMethodRequest.hpp"
#include "BMethodResult.hpp"
#include "BNegotiate.hpp"
#include "BOutput.hpp"
#include "BProtocol.hpp"
#include "BRegistry.hpp"
#include "BSerializable.hpp"
#include "BSerializer.hpp"
#include "BServer.hpp"
#include "BSkeleton.hpp"
#include "BStreamRequest.hpp"
#include "BStub.hpp"
#include "BTargetId.hpp"
#include "BTransport.hpp"
#include "BUtils.hpp"
#include "BVariant.hpp"
#include "BWire.hpp"
#include "BUtils.hpp"
#include "BLostConnectionHandler.hpp"
#include "BDateTime.hpp"
#include "BValueClass.hpp"

#include "platform/platform.hpp"

#endif /* BYPS_HPP_ */
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BTHREADPOOL_HPP_
#define BTHREADPOOL_HPP_

#ifndef BTHREADPOOL
#define BTHREADPOOL

#include "Byps.h"

#include <thread>

namespace byps { 

class BThreadPoolImpl;
typedef byps_ptr<BThreadPoolImpl> PThreadPoolImpl;

class BThreadPoolImpl : public BThreadPool, public byps_enable_shared_from_this<BThreadPoolImpl> {
	byps_mutex mutex;
	byps_condition_variable queueItemAdded;
	byps_condition_variable queueItemRemoved;
	std::vector<PRunnable> queue;
	int maxThreads;
	int fullLimit;
	byps_atomic<bool> isDone;
	byps_atomic<int> nbOfBusyThreads;

	typedef byps_ptr<std::thread> PThread;
	std::map<std::thread::id, PThread> allThreads;
	std::map<std::thread::id, bool> threadIdToRunning;

	PRunnable nextRunnableUnsync(byps_unique_lock& lock) {

		std::chrono::duration<int,std::milli> timeout(100 * 1000);

		bool succ = queueItemAdded.wait_for(lock, timeout, [this](){ 
			return this->isDone || this->queue.size() != 0; 
		});

		PRunnable r;
		if (succ && !isDone) {
			r = queue.front();
			queue.erase(queue.begin());
			queueItemRemoved.notify_all();
		}

		return r;
	}
	
	static void threadFunction(PThreadPoolImpl tpool) {
		std::thread::id tid = std::this_thread::get_id();

		while (true) {
			PRunnable r;

			{
				byps_unique_lock lock(tpool->mutex);
				r = tpool->nextRunnableUnsync(lock);
				if (!r) {
					break;
				}
			}

			tpool->nbOfBusyThreads++;
			try {
				r->run();
			}
			catch (...) {
			}
			tpool->nbOfBusyThreads--;

		}

		{
			byps_unique_lock lock(tpool->mutex);
			tpool->threadIdToRunning[tid] = false;
		}
	}

	void removeStoppedThreadsUnsync(std::vector<PThread>& stoppedThreads) {
		std::vector<std::thread::id> killIds;
		killIds.reserve(threadIdToRunning.size());
		for (std::map<std::thread::id, bool>::iterator it = threadIdToRunning.begin(); it != threadIdToRunning.end(); it++) {
			if ((*it).second) continue;
			killIds.push_back((*it).first);
		}
		for (unsigned i = 0; i < killIds.size(); i++) {
			PThread t = allThreads[killIds[i]];
			stoppedThreads.push_back(t);
			allThreads.erase(killIds[i]);
			threadIdToRunning.erase(killIds[i]);
		}
	}

	void joinThreads(std::vector<PThread>& stoppedThreads) {
		for (unsigned i = 0; i < stoppedThreads.size(); i++) {
			PThread t = stoppedThreads[i];
			if (t && t->joinable()) {
				t->join();
			}
			stoppedThreads[i] = PThread();
		}
	}

public:
	BThreadPoolImpl(int maxThreads) 
		: maxThreads(maxThreads)
		, fullLimit(maxThreads * 2)
		, isDone(false) {
	}

	virtual ~BThreadPoolImpl() {
    }

	virtual void done() {

		bool expectedDone = false;
		if (isDone.compare_exchange_strong(expectedDone, true)) {

			queueItemAdded.notify_all();
			queueItemRemoved.notify_all();

			std::vector<PThread> stoppedThreads;
			{
				byps_unique_lock lock(mutex);

				for (std::map<std::thread::id, bool>::iterator it = threadIdToRunning.begin(); it != threadIdToRunning.end(); it++) {
					(*it).second = false;
				}
				removeStoppedThreadsUnsync(stoppedThreads);
			}
			joinThreads(stoppedThreads);
		}
	}

	virtual bool execute(PRunnable r) {
		
		std::vector<PThread> stoppedThreads;

		{
			byps_unique_lock lock(this->mutex);
		
			this->queueItemRemoved.wait(lock, [this](){ 
				return this->isDone || this->queue.size() < (size_t)fullLimit || !shared_from_this(); 
			});

			PThreadPoolImpl pThis = shared_from_this();
			if (pThis && !isDone) {

				// Remove stopped threads from threadIdToRunning
				removeStoppedThreadsUnsync(stoppedThreads);

				// add job into queue
				this->queue.push_back(r);

				// Maybe start new thread
				size_t nbOfFreeThreads = threadIdToRunning.size() - (size_t)nbOfBusyThreads;
				if (queue.size() > nbOfFreeThreads) {
					if (threadIdToRunning.size() < (size_t)maxThreads) {
						PThread t(new std::thread(threadFunction, pThis));
						threadIdToRunning[t->get_id()] = true;
						allThreads[t->get_id()] = t;
					}
				}

			}

			this->queueItemAdded.notify_all();
		}
		
		joinThreads(stoppedThreads);

		return !isDone;
	}



	static PThreadPool createInstance();
};

BINLINE PThreadPool BThreadPool::create(void* , int maxThreads) {
	PThreadPoolImpl tpool(new BThreadPoolImpl(maxThreads));
	return tpool;
}



}

#endif // BTHREADPOOL

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef PLATFORM_HPP
#define PLATFORM_HPP

#ifdef QT_VERSION

#include "qt/QTThreadPool.hpp"

#endif

#include "any/BThreadPool.hpp"

#endif // PLATFORM_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef QTTHREADPOOL_HPP_
#define QTTHREADPOOL_HPP_

#ifndef BTHREADPOOL
#define BTHREADPOOL

#include "Byps.h"
#include "QTThreadPool.h"

namespace byps { namespace QT {

using namespace ::std;

class BThreadPoolImpl;
typedef byps_ptr<BThreadPoolImpl> PThreadPoolImpl;



class BThreadPoolImpl : public BThreadPool, public byps_enable_shared_from_this<BThreadPoolImpl> {

    int maxThreads;
    vector<PoolThreadWorker*> allWorkers;
    vector<PoolThreadWorker*> freeWorkers;
    byps_mutex mutex;
    byps_condition_variable waitFreeWorker;
    bool shutdownPhase;

public:

    BThreadPoolImpl(int maxThreads)
        : maxThreads(maxThreads)
        , shutdownPhase(false)
    {

    }

    virtual ~BThreadPoolImpl() {
        byps_unique_lock lock(mutex);
        for (auto it = freeWorkers.begin(); it != freeWorkers.end(); it++) {
            PoolThreadWorker* worker = *it;
            emit worker->thread->quit();
        }
    }

    virtual void done() {
        byps_unique_lock lock(mutex);
        shutdownPhase = true;

        while (freeWorkers.size() != allWorkers.size()) {
            std::chrono::milliseconds timeout(10 * 1000);
            waitFreeWorker.wait_for(lock, timeout);
        }

    }

    class MyRunnable : public QRunnable {
    public:
        PRunnable r;
        virtual void run() {
            r->run();
        }
    };

    virtual bool execute(PRunnable r) {
        PoolThreadWorker* worker = allocWorker();
        if (!worker) return false;

        MyRunnable* mr = new MyRunnable();
        mr->r = r;

        emit worker->thread->signal_execute(mr);

        return true;
    }

    void releaseWorker(PoolThreadWorker* worker) {
        byps_unique_lock lock(mutex);
        freeWorkers.push_back(worker);
        waitFreeWorker.notify_all();
    }

    PoolThreadWorker* allocWorker() {
        byps_unique_lock lock(mutex);
        PoolThreadWorker* ret = NULL;

        if (!shutdownPhase) {

            while (freeWorkers.size() == 0 && allWorkers.size() == (size_t)maxThreads) {
                std::chrono::milliseconds timeout(10 * 1000);
                waitFreeWorker.wait_for(lock, timeout);
            }

            if (freeWorkers.size() != 0) {
                ret = *freeWorkers.rbegin();
                freeWorkers.pop_back();
            }
            else if (allWorkers.size() < (size_t) maxThreads){
                ret = createWorker();
                allWorkers.push_back(ret);
            }

        }

        return ret;
    }

    PoolThreadWorker* createWorker() {
        PoolThread* thread = new PoolThread();
        PoolThreadWorker* worker = new PoolThreadWorker(shared_from_this(), thread);
        worker->moveToThread(thread);
        QObject::connect(thread, SIGNAL(finished()), worker, SLOT(deleteLater()));
        QObject::connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
        QObject::connect(thread, SIGNAL(signal_execute(QRunnable*)), worker, SLOT(slot_execute(QRunnable*)));
        thread->start();
        return worker;
    }
};

PoolThreadWorker::PoolThreadWorker(byps_ptr<BThreadPoolImpl> tpool, PoolThread* thread)
    : tpool(tpool)
    , thread(thread)
{
}

PoolThreadWorker::~PoolThreadWorker() {
}

void PoolThreadWorker::slot_execute(QRunnable* r) {
    r->run();
    delete r;
    byps_ptr<BThreadPoolImpl> tpool = this->tpool.lock();
    if (tpool) {
        tpool->releaseWorker(this);
    }
}

PoolThread::PoolThread() {

}

}}

namespace byps {

BINLINE PThreadPool BThreadPool::create(void* , int maxThreads) {
    byps::QT::PThreadPoolImpl tpool(new byps::QT::BThreadPoolImpl(maxThreads));
    return tpool;
}

}

#endif // BTHREADPOOL

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BYPSHTTP_HPP_
#define BYPSHTTP_HPP_

#include "Bypshttp.h"
#include "HWireClient.hpp"
#include "HServerR.hpp"
#include "HTransportFactoryClient.hpp"
#include "HHttpClient.hpp"

#ifdef _MSC_VER
#include "platform/win/WinHttpClient.hpp"
#endif

#ifdef QT_NETWORK_LIB
#include "platform/qt/QTHttpClient.hpp"
#endif

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HHTTPCLIENT_HPP_
#define HHTTPCLIENT_HPP_

#include "HHttpClient.h"

namespace byps { namespace http {

using namespace byps;




}}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HSERVERR_HPP_
#define HSERVERR_HPP_

#include "HServerR.h"

namespace byps { namespace http {

using namespace byps;

class HServerR_LongPoll;
typedef byps_ptr<HServerR_LongPoll> PServerR_LongPoll;
class HServerR_SendLongPoll;
typedef byps_ptr<HServerR_SendLongPoll> PServerR_SendLongPoll;

class HServerR_SendLongPoll : public byps_enable_shared_from_this<HServerR_SendLongPoll> {

	byps_mutex mutex;
	byps_condition_variable serverFinished;
	bool isDone;
	int32_t sleepMillisBeforeRetry;


	PLostConnectionHandler lostConnectionHandler;
	friend class HServerR;

public:
    byps_atomic<int32_t> nbOfActiveLongPolls;

	HServerR_SendLongPoll() 
		: isDone(false)
		, sleepMillisBeforeRetry(60 * 1000)
        , lostConnectionHandler(NULL)
        , nbOfActiveLongPolls(0) {
    }

	bool waitBeforeRetry() {
		byps_unique_lock lock(mutex);
		if (isDone) return true;
		std::chrono::milliseconds timeout(sleepMillisBeforeRetry);
		return !serverFinished.wait_for(lock, timeout, [this]() { return isDone; });
	}

	void done() {
		byps_unique_lock lock(mutex);
		isDone = true;
		serverFinished.notify_all();
	}

    void send(PTransport transport, PServer server, PMessage methodResult);

	void onLostConnection(const BException& ex, PTransport transport, PServer server);
};

class HServerR_LongPoll {
	PServerR_SendLongPoll sendLongPoll;
	PTransport transport;
	PServer server;
	PMessage methodResult;

	class NextAsyncResult : public BAsyncResult {
		byps_weak_ptr<HServerR_SendLongPoll> sendLongPoll;
		byps_weak_ptr<BTransport> transport;
		byps_weak_ptr<BServer> server;
	public:
		NextAsyncResult(PServerR_SendLongPoll sendLongPoll, PTransport transport, PServer server) 
			: sendLongPoll(sendLongPoll), transport(transport), server(server) {
            sendLongPoll->nbOfActiveLongPolls++;
		}

        virtual ~NextAsyncResult() {
			PServerR_SendLongPoll sendLongPoll = this->sendLongPoll.lock();
			if (sendLongPoll) {
	            sendLongPoll->nbOfActiveLongPolls--;
			}
        }

		virtual void setAsyncResult(const BVariant& varmsg) {
			PServerR_SendLongPoll sendLongPoll = this->sendLongPoll.lock();
			PTransport transport = this->transport.lock();
			PServer server = this->server.lock();
			if (sendLongPoll && transport && server) {

				PMessage msg;
				if (varmsg.isException()) {
					POutput outp = transport->getOutput();
					outp->header.flags = BHEADER_FLAG_RESPONSE;
					outp->setException(varmsg.getException());
					msg = outp->toMessage();
				}
				else {
					POBJECT obj;
					varmsg.get(obj);
					msg = byps_static_ptr_cast<BMessage>(obj);
				}
				sendLongPoll->send(transport, server, msg);
			}

			delete this;
		}
	};

	class NextAsyncMethod : public BAsyncResult {
		byps_weak_ptr<HServerR_SendLongPoll> sendLongPoll;
		byps_weak_ptr<BTransport> transport;
		byps_weak_ptr<BServer> server;
	public:
		NextAsyncMethod(PServerR_SendLongPoll sendLongPoll, PTransport transport, PServer server) 
			: sendLongPoll(sendLongPoll), transport(transport), server(server) {
		}

        virtual ~NextAsyncMethod() {
            sendLongPoll.reset();
            transport.reset();
            server.reset();
        }

		virtual void setAsyncResult(const BVariant& varmsg) {
			PServerR_SendLongPoll sendLongPoll = this->sendLongPoll.lock();
			PTransport transport = this->transport.lock();
			PServer server = this->server.lock();
			if (sendLongPoll && transport && server) {

				bool failed = varmsg.isException();
				if (failed) {

					BException ex = varmsg.getException();
					switch (ex.getCode()) {

					case EX_SESSION_CLOSED: // Session was invalidated.
					case EX_UNAUTHORIZED: // Re-login required
					case EX_CANCELLED:
						// no retry
						break;
                
					case RESEND_LONG_POLL:
						// HWireClientR has released the expried long-poll.
						// Ignore the error and send a new long-poll.
						sendLongPoll->send(transport, server, PMessage());
						break;
                
					default:
						sendLongPoll->onLostConnection(ex, transport, server);
						break;
					}

				}
				else {
					POBJECT obj;
					varmsg.get(obj);
					PMessage msg = byps_static_ptr_cast<BMessage>(obj);
					NextAsyncResult* asyncResult = new NextAsyncResult(sendLongPoll, transport, server);
					transport->recv(server, msg, asyncResult);
				}
			}

			delete this;
		}
	};


public:
	
	HServerR_LongPoll(PServerR_SendLongPoll sendLongPoll, PTransport transport, PServer server, PMessage methodResult) 
		: sendLongPoll(sendLongPoll), transport(transport), server(server), methodResult(methodResult) {
					
		if (!methodResult) {
			POutput outp = transport->getOutput();
			outp->header.flags |= BHEADER_FLAG_RESPONSE;
			outp->store(PSerializable());
			this->methodResult = outp->toMessage();
		}
	}

	virtual ~HServerR_LongPoll() {
		sendLongPoll.reset();
	}

	void run() {

		NextAsyncMethod* nextMethod = new NextAsyncMethod(sendLongPoll, transport, server);
		transport->getWire()->sendR(methodResult, nextMethod);

	}
};

BINLINE HServerR::HServerR(PTransport transport, PServer server, int nbOfConns) 
	: BServerR(transport, server)
	, nbOfConns(nbOfConns)
	, sendLongPoll(new HServerR_SendLongPoll()) {
}

BINLINE HServerR::~HServerR() {
}

BINLINE void HServerR::start() {
	for (int i = 0; i < nbOfConns; i++) {
		sendLongPoll->send(transport, server, PMessage());
	}

}

BINLINE void HServerR::done() {
	sendLongPoll->done();
}

BINLINE void HServerR::setLostConnectionHandler(PLostConnectionHandler lostConnectionHandler) {
	sendLongPoll->lostConnectionHandler = lostConnectionHandler;
}

BINLINE void HServerR_SendLongPoll::send(PTransport transport, PServer server, PMessage methodResult) {
	if (!isDone) {
        HServerR_LongPoll longPoll(shared_from_this(), transport, server, methodResult);
        longPoll.run();
	}
}

//class MyThread {
//public:
//	
//	virtual void run() {
//	}
//
//	static MyThread* start() {
//		byps_unique_lock(mtx);
//
//		for (size_t i = 0; i < stoppedThreads.size(); i++) {
//			delete stoppedThreads[i];
//		}
//		stoppedThreads.clear();
//
//		MyThread* t = new MyThread();
//		t->std_thread = new std::thread(threadFunct, t);
//	}
//
//	void join() {
//	}
//
//private:
//	virtual ~MyThread() {
//	}
//
//	std::thread* std_thread;
//	static byps_mutex mtx;
//	static vector<MyThread*> stoppedThreads;
//
//	static void threadFunct(MyThread* pThread) {
//
//		try {
//			pThread->run();
//		}
//		catch (...) {}
//
//		{
//			byps_unique_lock lock(mtx);
//			stoppedThreads.push_back(pThread);
//		}
//	}
//};

BINLINE void lostConnection(PLostConnectionHandler lostConnectionHandler, BException ex) {
	try {
		lostConnectionHandler->onLostConnection(ex);
	}
	catch (...) {}
}

BINLINE void HServerR_SendLongPoll::onLostConnection(const BException& ex, PTransport transport, PServer server) {
	if (isDone) return;

	if (lostConnectionHandler) {
		std::thread t(lostConnection, lostConnectionHandler, ex);
		t.detach();
	}
	else if (waitBeforeRetry()) { // e.g. Socket error
		send(transport, server, PMessage());
	}
}

}}
#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HTRANSPORTFACTORYCLIENT_HPP_
#define HTRANSPORTFACTORYCLIENT_HPP_

#include "HTransportFactoryClient.h"

namespace byps { namespace http {

using namespace byps;

BINLINE HTransportFactoryClient::HTransportFactoryClient(PApiDescriptor apiDesc, PWire wire, int nbOfServerRConns) 
	: transport(new BTransport(apiDesc, wire, PRemoteRegistry()))
    , nbOfServerRConns(nbOfServerRConns) {
}

BINLINE PTransport HTransportFactoryClient::createClientTransport() {
	return transport;
}

BINLINE PTransport HTransportFactoryClient::createServerTransport() {
	return transport;
}

BINLINE PClient HTransportFactoryClient::createClientR(PClient) {
	return PClient();
}

BINLINE PServerR HTransportFactoryClient::createServerR(PServer server) {
	return nbOfServerRConns ? 
		PServerR( new HServerR(transport, server, nbOfServerRConns) ) : 
		PServerR();
}



}}

#endif
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HWIRECLIENT_HPP_
#define HWIRECLIENT_HPP_

#include "Byps.h"
#include "HWireClient.h"
#include "HWireClientI.h"
#include <thread>

namespace byps { namespace http {

using namespace byps;


BINLINE int64_t HWireClient::makeMessageId() {
    int64_t v = rand();
    return v >= 0 ? v : -v;
}

BINLINE PTestAdapter HWireClient::getTestAdapter() {
	return PTestAdapter(new HWireClient_TestAdapter(shared_from_this()));
}

BINLINE HWireClient_RequestsToCancel::HWireClient_RequestsToCancel() {
}


BINLINE void HWireClient_RequestsToCancel::add(intptr_t id, PHttpRequest r) {
    byps_unique_lock lock(mutex);
    l_debug << L"add(" << id << L")";
	map[id] = r;
}

BINLINE void HWireClient_RequestsToCancel::addCancelMessage(intptr_t id, PHttpRequest r) {
    byps_unique_lock lock(mutex);
	map[id] = r;
}

BINLINE void HWireClient_RequestsToCancel::remove(intptr_t id) {
    byps_unique_lock lock(mutex);
    l_debug << L"remove(" << id;
	std::map<intptr_t, PHttpRequest>::iterator it = map.find(id);
	if (it != map.end()) {
        PHttpRequest r = (*it).second;
        r->close();
		map.erase(it);
	}
    l_debug << L")remove";
}

BINLINE void HWireClient_RequestsToCancel::cancelAllRequests() {
    l_debug << L"cancelAllRequests(";
    std::vector<PHttpRequest> requests;

    {
        byps_unique_lock lock(mutex);
        for (std::map<intptr_t, PHttpRequest>::iterator it = map.begin(); it != map.end(); it++) {
            requests.push_back((*it).second);
        }
        map.clear();
    }

    for (std::vector<PHttpRequest>::iterator it = requests.begin(); it != requests.end(); it++) {
        PHttpRequest req = (*it);
        req->close();
    }

    l_debug << L")cancelAllRequests";
}

BINLINE HWireClient_RequestsToCancel::~HWireClient_RequestsToCancel() {
    l_debug << L"dtor(";
	map.clear();
    l_debug << L")dtor";
}


BINLINE PWire HWireClient::create(void* app, const std::wstring& url, int32_t flags, int32_t timeoutSeconds, PThreadPool tpool) {
    l_debug << L"create(" << url << L", flags=" << flags << L", timeoutSeconds=" << timeoutSeconds;
	HWireClient* pThis = new HWireClient(app, url, flags, timeoutSeconds, tpool);
	pThis->init();
    PWire ret = PWire(pThis);
    l_debug << L")create=" << pThis;
    return ret;
}

BINLINE HWireClient::HWireClient(void* app, const std::wstring& surl, int32_t , int32_t timeoutSeconds, PThreadPool tpool)
	: app(app)
	, url(surl)
	, timeoutSecondsClient(timeoutSeconds)
	, tpool(tpool)
	, isMyThreadPool(!tpool)
    , isDone(false)
{
    l_debug << L"ctor(";
	if (isMyThreadPool) {
        l_debug << L"create thread pool";
        this->tpool = BThreadPool::create(app, 10);
	}

	// seed for random number generator
	int byteCount = 1000; // + (std::time(NULL) % 100);
	// char p[200]; filled with -52 from VS debugging runtime
	char* p = (char*)&byteCount;
	std::seed_seq seed1 (p, p+byteCount);
	rand.seed(seed1);

    l_debug << L")ctor";
}

BINLINE void HWireClient::init() {
    l_debug << L"init(";
	try {
		httpClient = HttpClient_create(app);
		httpClient->init(url);

		requestsToCancel = PWireClient_RequestsToCancel(new HWireClient_RequestsToCancel());
	}
	catch (const BException& ex) {
		lastException = ex;
	}
    l_debug << L")init";
}

BINLINE HWireClient::~HWireClient() {
    l_debug << L"dtor(";
    if (isMyThreadPool && tpool) {
        tpool->done();
    }
	tpool.reset();
	requestsToCancel.reset();
	httpClient.reset();
    l_debug << L")dtor";
}

BINLINE void HWireClient::throwLastException() {
    l_debug<< L"throwLastException(";
    if (lastException) {
        l_debug << L"throw " << lastException.toString();
		throw lastException;
	}
    l_debug << L")throwLastException";
}

BINLINE HWireClient_AsyncResultAfterAllRequests::HWireClient_AsyncResultAfterAllRequests(byps_ptr<HWireClient> wire, PThreadPool tpool, int64_t messageId, PAsyncResult innerResult, size_t nbOfRequests)
    : wire(wire)
	, tpool(tpool)
	, messageId(messageId)
	, innerResult(innerResult)
	, nbOfRequests(nbOfRequests)
	, countRequests(0) {
    l_debug << L"ctor(), messageId=" << messageId << L", nbOfRequests=" << nbOfRequests;
}

BINLINE void HWireClient_AsyncResultAfterAllRequests::setAsyncResult(const BVariant& obj) {
    l_debug << L"setAsyncResult(";
	bool cancelMessage = false;
	bool isLastResult = false;

	{
		byps_unique_lock lock(mutex);

        isLastResult = ++countRequests == nbOfRequests;
        l_debug << L"countRequests=" << countRequests;

		if (obj.isException()) {
			cancelMessage = !result.isException();
			if (cancelMessage) result = obj;
		}
		else if (obj.getType() != BTYPEID_BOOL) {
			result = obj;
		}

	}

    if (isLastResult) {
        l_debug << L"execute result in tpool";
		PRunnable r(new HWireClient_ExecResult(innerResult, result));
		tpool->execute(r);
	}

	if (cancelMessage && !isLastResult) {
		byps_ptr<HWireClient> wire = this->wire.lock();
		if (wire) {
            l_debug << L"sendCancelMessage messageId=" << messageId;
			wire->sendCancelMessage(messageId);
		}
	}

	if (isLastResult) {
        l_debug << L"delete this";
		delete this;
	}

    l_debug << L")setAsyncResult";
}

BINLINE void HWireClient::send(const PMessage& msg, PAsyncResult asyncResult) {
    l_debug << L"send()";
	internalSend(msg, asyncResult, timeoutSecondsClient);
	//internalSendStreamsThenMessage(msg, asyncResult, timeoutSecondsClient);
}

BINLINE void HWireClient::sendR(const PMessage& msg, PAsyncResult asyncResult) {
    l_debug << L"sendR()";
	internalSend(msg, asyncResult, 0); //timeout kontrollieren, behandelt ServerR das richtig?
	//internalSendStreamsThenMessage(msg, asyncResult, 0);
}

class BMessageRequest_SetAsyncResultInBackground : public BRunnable {
    PAsyncResult asyncResult;
    BVariant var;

public:
    BMessageRequest_SetAsyncResultInBackground(PAsyncResult asyncResult, const BVariant& var)
        : asyncResult(asyncResult)
        , var(var) {
    }

    virtual void run() {
        asyncResult->setAsyncResult(var);
    }
};

class BMessageRequest_AsyncResult : public BAsyncResult {
	PWireClient_RequestsToCancel requests;
    PThreadPool tpool;
    byps_atomic<PAsyncResult> innerResult;
	int64_t messageId;
    static BLogger log;

public:
	const intptr_t id;

    BMessageRequest_AsyncResult(PWireClient_RequestsToCancel requests, PThreadPool tpool, PAsyncResult innerResult, int64_t messageId)
		: requests(requests)
        , tpool(tpool)
		, innerResult(innerResult)
		, messageId(messageId)
		, id(reinterpret_cast<intptr_t>(this))
	{
        l_debug << L"ctor(messageId=" << messageId << L")";
	}

	virtual ~BMessageRequest_AsyncResult() {
        l_debug << L"dtor()";
	}

    void internalSetAsyncResult(const BVariant& var) {
        l_debug << L"internalSetAsyncResult(" << var.toString();
        PAsyncResult r = innerResult.exchange(NULL);
        if (r) {
            PRunnable run(new BMessageRequest_SetAsyncResultInBackground(r, var));
            tpool->execute(run);
        }
        l_debug << L")internalSetAsyncResult";
    }

	virtual void setAsyncResult(const BVariant& var) {
        l_debug << L"setAsyncResult(" << var.toString();
        if (var.isException()) {
            l_debug << L"set exception";
            internalSetAsyncResult(var);
		}
		else {
            l_debug << L"process bytes";
			PBytes respBytes;
			var.get(respBytes);

            l_debug << L"respBytes=" << respBytes;
            if (respBytes && respBytes->length) {

				try {
                    l_debug << L"read header";
                    BMessageHeader header;

                    bool nego = BNegotiate::isNegotiateMessage(respBytes);
                    l_debug << L"isNegotiate=" << nego;
                    if (nego) {
                        header.messageId = messageId;
					}
					else {
						BBuffer buf(BBinaryModel::MEDIUM(), respBytes, BBIG_ENDIAN);
						header.read(buf);
                        l_debug << L"messageId=" << header.messageId;
                    }
		
                    l_debug << L"init BMessage";
                    std::vector<PStreamRequest> streams;
					PMessage msg(new BMessage(header, respBytes, streams));

                    internalSetAsyncResult(BVariant(msg));

				} catch (const BException& ex) {
				
                    internalSetAsyncResult(BVariant(ex));
				}
			}
			else {
				BException ex = BException(EX_IOERROR, L"No bytes received.");
                internalSetAsyncResult(BVariant(ex));
			}
		}

        l_debug << L"remove from requests";
        requests->remove(id);

        l_debug << L"delete this";
		delete this;

        l_debug << L")setAsyncResult";
	}
};

class BPutRequest_AsyncResult : public BAsyncResult {
	PWireClient_RequestsToCancel requests;
	PAsyncResult innerResult;
    static BLogger log;

public:
	const intptr_t id;

	BPutRequest_AsyncResult(PWireClient_RequestsToCancel requests, PAsyncResult innerResult) 
		: requests(requests)
		, innerResult(innerResult)
		, id(reinterpret_cast<intptr_t>(this))
	{
        l_debug << L"ctor(id=" << id << L")";
	}

	virtual void setAsyncResult(const BVariant& var) {
        l_debug << L"setAsyncResult(" << var.toString();
		innerResult->setAsyncResult(var);
        l_debug << L"remove from requests";
		requests->remove(id);
        l_debug << L"delete this";
		delete this;
        l_debug << L")setAsyncResult";
	}
};

BINLINE void HWireClient::internalSend(const PMessage& msg, PAsyncResult asyncResult, int32_t timeoutSecondsRequest) {
    l_debug << L"internalSend(";

	// Convert the BMessage into single RequestToCancel objects.
	// One RequestToCancel is created for msg.buf.
	// For each stream in msg.streams further RequestToCancel objects are created.
		
	size_t nbOfRequests = 1 + msg->streams.size();
    l_debug << L"nbOfRequests=" << nbOfRequests;

	if (nbOfRequests > 1) {
		l_debug << L"create outerResult";
		PAsyncResult outerResult(new HWireClient_AsyncResultAfterAllRequests(shared_from_this(), tpool, msg->header.messageId, asyncResult, nbOfRequests));

		l_debug << L"create message result";
        BMessageRequest_AsyncResult* messageResult = new BMessageRequest_AsyncResult(requestsToCancel, tpool, outerResult, msg->header.messageId);

		// Create request for message
		l_debug << L"create post request";
		PHttpPost messageRequest = httpClient->post(url);
		messageRequest->setTimeouts(timeoutSecondsClient, timeoutSecondsRequest);

		l_debug << L"send message buf";
		std::wstring contentType = msg->header.magic == BMAGIC_BINARY_STREAM ? L"application/byps" : L"application/json";
		messageRequest->send(msg->buf, contentType, messageResult);
		
		// Create requests for each stream.
		for (unsigned i = 0; i < msg->streams.size(); i++) {
			PStreamRequest stream = msg->streams[i];

			if (!stream) continue;
			if (!stream->streamId) continue;

			std::wstringstream ssurl;
			ssurl << url << L"?messageid=" << stream->messageId << L"&streamid=" << stream->streamId;

			l_debug << L"put stream url=" << url;
			PHttpPutStream streamRequest = httpClient->putStream(ssurl.str());
			streamRequest->setTimeouts(timeoutSecondsClient, timeoutSecondsRequest);

			l_debug << L"create stream result";
			BPutRequest_AsyncResult* streamResult = new BPutRequest_AsyncResult(requestsToCancel, outerResult);

			l_debug << L"add put request";
			requestsToCancel->add(streamResult->id, streamRequest);

			streamRequest->send(stream->strm, streamResult);
		}
	}
	else {
		internalSendMessageWithoutStreams(msg, asyncResult, timeoutSecondsRequest);
	}

	l_debug << L")internalSend";
}

class HWireClient_SendMessageAfterStreams : public BAsyncResult {
	byps_ptr<HWireClient> wire;
	PMessage msg;
	int32_t timeoutSecondsRequest;
	PAsyncResult innerResult;
    static BLogger log;

public:
	const intptr_t id;

	HWireClient_SendMessageAfterStreams(byps_ptr<HWireClient> wire, PMessage msg, int32_t timeoutSecondsRequest, PAsyncResult innerResult) 
		: wire(wire)
		, msg(msg)
		, timeoutSecondsRequest(timeoutSecondsRequest)
		, innerResult(innerResult)
		, id(reinterpret_cast<intptr_t>(this))
	{
        l_debug << L"ctor(id=" << id << L")";
	}

	virtual void setAsyncResult(const BVariant& var) {
        l_debug << L"setAsyncResult(" << var.toString();
		
		if (var.isException()) {
			innerResult->setAsyncResult(var);
		}
		else {

			// Create request for message
			l_debug << L"create post request";
			PHttpPost messageRequest = wire->httpClient->post(wire->url);
			messageRequest->setTimeouts(wire->timeoutSecondsClient, timeoutSecondsRequest);

			l_debug << L"create message result";
			BMessageRequest_AsyncResult* messageResult = new BMessageRequest_AsyncResult(
                wire->requestsToCancel, wire->tpool, innerResult, msg->header.messageId);

			wire->requestsToCancel->add(messageResult->id, messageRequest);
			l_debug << L"send message buf";
			std::wstring contentType = msg->header.magic == BMAGIC_BINARY_STREAM ? L"application/byps" : L"application/json";
			messageRequest->send(msg->buf, contentType, messageResult);
		}

        l_debug << L"delete this";
		delete this;
        l_debug << L")setAsyncResult";
	}
};

BINLINE void HWireClient::internalSendStreamsThenMessage(const PMessage& msg, PAsyncResult asyncResult, int32_t timeoutSecondsRequest) {
    l_debug << L"internalSendStreamsThenMessage(";

	// Convert the BMessage into single RequestToCancel objects.
	// One RequestToCancel is created for msg.buf.
	// For each stream in msg.streams further RequestToCancel objects are created.
		
	size_t nbOfStreams = msg->streams.size();
    l_debug << L"nbOfStreams=" << nbOfStreams;

	if (nbOfStreams) {

		// Send the streams first and then send the message.
		// If the message is sent before the streams, 
		// a timeout happens for the message if it takes 
		// more than timeoutMillisRequest to send the streams.
			
		// Create an BAsyncResult that sends the message on setAsyncResult
		PAsyncResult asyncSendMessage = new HWireClient_SendMessageAfterStreams(shared_from_this(), msg, timeoutSecondsRequest, asyncResult);

		// Create BAsyncResult that calls asyncSendMessage if all streams have been sent.
		PAsyncResult outerResult(new HWireClient_AsyncResultAfterAllRequests(shared_from_this(), tpool, msg->header.messageId, asyncSendMessage, nbOfStreams));

		// Create requests for each stream.
		for (unsigned i = 0; i < msg->streams.size(); i++) {
			PStreamRequest stream = msg->streams[i];

			if (!stream) continue;
			if (!stream->streamId) continue;

			std::wstringstream ssurl;
			ssurl << url << L"?messageid=" << stream->messageId << L"&streamid=" << stream->streamId;

            l_debug << L"put stream url=" << url;
			PHttpPutStream streamRequest = httpClient->putStream(ssurl.str());
			streamRequest->setTimeouts(timeoutSecondsClient, timeoutSecondsRequest);

            l_debug << L"create stream result";
			BPutRequest_AsyncResult* streamResult = new BPutRequest_AsyncResult(requestsToCancel, outerResult);

            l_debug << L"add put request";
            requestsToCancel->add(streamResult->id, streamRequest);
			streamRequest->send(stream->strm, streamResult);

		}
	}
	else {
		internalSendMessageWithoutStreams(msg, asyncResult, timeoutSecondsRequest);
	}

    l_debug << L")internalSendStreamsThenMessage";
}

BINLINE void HWireClient::internalSendMessageWithoutStreams(const PMessage& msg, PAsyncResult asyncResult, int32_t timeoutSecondsRequest) {
	
	bool isNegotiate = BNegotiate::isNegotiateMessage(msg->buf);
	bool isReverse = (msg->header.flags & BHEADER_FLAG_RESPONSE) != 0;
	if (isNegotiate) {
		l_debug << L"create negotiate request";

		std::string negoStr((char*)msg->buf->data, msg->buf->length);
		std::wstring negoWStr = BToStdWString(negoStr);
		negoWStr = escapeUrl(negoWStr);

		std::wstring servletPath = getServletPathForNegotiationAndAuthentication();
		std::vector<std::wstring> params;
		params.push_back(L"negotiate");
		params.push_back(negoWStr);
		std::wstring destUrl = makeUrl(servletPath, params);
		l_debug << L"url=" << destUrl;

		PHttpGet messageRequest = httpClient->get(destUrl);
		messageRequest->setTimeouts(timeoutSecondsClient, timeoutSecondsRequest);

		l_debug << L"create message result";
        BMessageRequest_AsyncResult* messageResult = new BMessageRequest_AsyncResult(
                    requestsToCancel, tpool, asyncResult, msg->header.messageId);

		requestsToCancel->add(messageResult->id, messageRequest);

		l_debug << L"send message buf";
		messageRequest->send(messageResult);
	}
	else {
		// Create request for message
		l_debug << L"create post request";

		std::wstring destUrl = url;
		if (isReverse) {
			destUrl = makeUrl(getServletPathForNegotiationAndAuthentication(), std::vector<std::wstring>());
		}

		PHttpPost messageRequest = httpClient->post(destUrl);
		messageRequest->setTimeouts(timeoutSecondsClient, isReverse ? 0 : timeoutSecondsRequest);

		l_debug << L"create message result";
        BMessageRequest_AsyncResult* messageResult = new BMessageRequest_AsyncResult(
                    requestsToCancel, tpool, asyncResult, msg->header.messageId);

		requestsToCancel->add(messageResult->id, messageRequest);
		l_debug << L"send message buf";
		std::wstring contentType = msg->header.magic == BMAGIC_BINARY_STREAM ? L"application/byps" : L"application/json";
		messageRequest->send(msg->buf, contentType, messageResult);
	}
}

BINLINE std::wstring HWireClient::escapeUrl(const std::wstring& url) {
	std::wstringstream wss;
	wss << std::hex << std::setfill(L'0');
	for (unsigned i = 0; i < url.size(); i++) {
		wss << L"%" << setw(2) << (int)(url[i]);
	}
	return wss.str();
}

class MyContentStream : public BContentStream {
    std::wstring url;
    PWireClient_RequestsToCancel requestsToCancel;
	PContentStream innerStream;
    int64_t messageId;
    int64_t streamId;
    byps_weak_ptr<HHttpClient> httpClient;
    int32_t timeoutSeconds;
    static BLogger log;

public:
	const intptr_t id;

    MyContentStream(const std::wstring& url,
                    PWireClient_RequestsToCancel requestsToCancel,
                    int64_t messageId, int64_t streamId,
                    PHttpClient httpClient,
                    int32_t timeoutSeconds)
        : url(url)
        , requestsToCancel(requestsToCancel)
        , messageId(messageId)
        , streamId(streamId)
        , httpClient(httpClient)
        , timeoutSeconds(timeoutSeconds)
		, id(reinterpret_cast<intptr_t>(this))
	{
        l_debug << L"ctor(messageId=" << messageId << L", streamId=" << streamId << L")";
	}

    void ensureOpen() const {

		if (innerStream) return;
        l_debug << L"ensureOpen(";

        PHttpClient httpClient = this->httpClient.lock();
        if (httpClient) {
            MyContentStream* pThis = const_cast<MyContentStream*>(this);

            std::wstringstream ssurl;
            ssurl << url << L"?messageid=" << messageId << L"&streamid=" << streamId;
            l_debug << L"get url=" << ssurl.str();

            PHttpGetStream streamRequest = httpClient->getStream(ssurl.str());
            streamRequest->setTimeouts(timeoutSeconds, timeoutSeconds);

            requestsToCancel->add(id, streamRequest);

            l_debug << L"send stream request";
            pThis->innerStream = streamRequest->send();
        }
        else {
            l_debug << L"HTTP client already released";
            throw BException(EX_CANCELLED, L"HTTP client already released.");
        }
        l_debug << L")ensureOpen";
	}

	virtual ~MyContentStream() {
        l_debug << L"dtor(";
        requestsToCancel->remove(id);
        l_debug << L")dtor";
	}

	virtual const std::wstring& getContentType() const {
        ensureOpen();
        const std::wstring& ret = innerStream->getContentType();
        l_debug << L"getContentType()="<<ret;
        return ret;
	}

	virtual int64_t getContentLength() const {
        ensureOpen();
        int64_t ret = innerStream->getContentLength();
        l_debug << L"getContentLength()=" << ret;
        return ret;
	}

	virtual int32_t read(char* buf, int32_t offs, int32_t len) {
        ensureOpen();
        l_debug << L"read(buf=" << (void*)buf << L", offs=" << offs << L", len=" << len;
        int32_t ret = innerStream->read(buf, offs, len);
        l_debug << L")read=" << ret;
        return ret;
	}
	
};

BINLINE PContentStream HWireClient::getStream(int64_t messageId, int64_t streamId) {
    l_debug << L"getStream(messageId=" << messageId << L", streamId=" << streamId;
    MyContentStream* stream = new MyContentStream(url, requestsToCancel, messageId, streamId, httpClient, timeoutSecondsClient);
    PContentStream ret = PContentStream(stream);
    l_debug << L")getStream=" << (void*)stream;
    return ret;
}

BINLINE void HWireClient::done() {
    l_debug << L"done(";

	// already done?
	bool expectedDone = false;
	if (isDone.compare_exchange_strong(expectedDone, true)) {

        l_debug << L"cancel requests";

		internalCancelAllRequests(MESSAGEID_DISCONNECT);

		if (isMyThreadPool && tpool) {
            l_debug << L"tpool->done";
			tpool->done();
		}

		tpool.reset();

        l_debug << L"httpClient->done";
        httpClient->done();
	}

    l_debug << L")done";
}

BINLINE void HWireClient::cancelAllRequests() {
    l_debug << L"cancelAllRequests(";
	internalCancelAllRequests(MESSAGEID_CANCEL_ALL_REQUESTS);
    l_debug << L")cancelAllRequests";
}

BINLINE void HWireClient::sendCancelMessage(int64_t cancelMessageId) {
    l_debug << L"sendCancelMessage(" << cancelMessageId;
	std::wstringstream ss;
	ss << url << L"?cancel=1&messageid=" << cancelMessageId;
	
	PHttpGetStream cancelRequest = httpClient->getStream(ss.str());

	// Use short timeout value.
	// The server is unavailable if BClient::done() is called in a BLostConnectionHandler.
	cancelRequest->setTimeouts(5, 5);

	PContentStream strm = cancelRequest->send();
	strm.reset();

    l_debug << L")sendCancelMessage";
}

BINLINE void HWireClient::internalCancelAllRequests(int64_t cancelMessageId) {
    l_debug << L"internalCancelAllRequests(cancelMessageId=" << cancelMessageId;

	if (cancelMessageId) {
		sendCancelMessage(cancelMessageId);
	}

	requestsToCancel->cancelAllRequests();

	// Wait a moment until all requests have been finished.
	// I could manage this with a lot of condition variables,
	// but it's not worth the effort. 
	// If the reqeuests are not finished when the function returns,
	// we leek some memory.
	std::chrono::milliseconds ms( 100 );
    std::this_thread::sleep_for( ms );

    l_debug << L")internalCancelAllRequests";
}

// /bypsservletauth/auth
BINLINE std::wstring HWireClient::getServletPathForNegotiationAndAuthentication() {
	std::wstring ret;
	size_t p = url.find_last_of(L'/');
	if (p != std::wstring::npos) {
		ret = url.substr(p);
	}
	return ret;
}

// /bypsservletauth/auth
BINLINE std::wstring HWireClient::getServletPathForReverseRequest() {
	std::wstring ret;
	size_t p = url.find_last_of(L'/');
	if (p != std::wstring::npos) {
		ret = url.substr(p);
	}
	return ret;
}

BINLINE std::wstring HWireClient::makeUrl(const std::wstring& servletPath, const std::vector<std::wstring>& params) {
	std::wstringstream wss;
	size_t p = url.find_last_of(L"/");
    if (p == std::wstring::npos) p = url.size();
	wss << url.substr(0, p);
	wss << servletPath;
    for (size_t i = 0; i < params.size(); i+=2) {
		wss << (i == 0 ? L"?" : L"&");
		wss << params[i] << L"=" << params[i+1];
    }
	return wss.str();
}

BINLINE HWireClient_ExecResult::HWireClient_ExecResult(PAsyncResult asyncResult, BVariant var) 
	: asyncResult(asyncResult)
	, var(var) {
    l_debug << L"ctor()";
}

BINLINE void HWireClient_ExecResult::run() {
    l_debug << L"run(";
	asyncResult->setAsyncResult(var);
    l_debug << L")run";
}

BINLINE void HWireClient_TestAdapter::killClientConnections() {
    l_debug << L"killClientConnections(";
	wire->internalCancelAllRequests(0);
    l_debug << L")killClientConnections";
}


BLogger HWireClient::log("HWireClient");
BLogger HWireClient_AsyncResultAfterAllRequests::log("HWireClient_AsyncResultAfterAllRequests");
BLogger HWireClient_RequestsToCancel::log("HWireClient_RequestsToCancel");
BLogger BMessageRequest_AsyncResult::log("BMessageRequest_AsyncResult");
BLogger MyContentStream::log("MyContentStream");
BLogger HWireClient_TestAdapter::log("HWireClient_TestAdapter");
BLogger HWireClient_ExecResult::log("HWireClient_ExecResult");
BLogger BPutRequest_AsyncResult::log("BPutRequest_AsyncResult");
BLogger HWireClient_SendMessageAfterStreams::log("HWireClient_SendMessageAfterStreams");
}}

#endif

/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef QTHTTPCLIENT_HPP
#define QTHTTPCLIENT_HPP


#include "QTHttpClient.h"
#include "QTHttpClientI.h"
#include <QStack>

namespace byps { namespace http { namespace qthttp {

using namespace byps;
using namespace byps::http;

#define MAX_STREAM_PART_SIZE (1000 * 1000)

class QTHttpGetStream_ContentStream : public BContentStream {
    byps_condition_variable waitRead;
    byps_condition_variable waitWrite;
    byps_condition_variable waitHeaders;
    byps_mutex mutex;
    QByteArray bytes;
    bool finished;
    int32_t readPos;
    int32_t readLimit;
    std::wstring contentType;
    int64_t contentLength;
    bool headersAvail;
    std::chrono::milliseconds timeout;
    BException ex;
    static BLogger log;
public:
    QTHttpGetStream_ContentStream(int32_t timeoutSeconds)
        : finished(false)
        , readPos(0)
        , readLimit(0)
        , contentLength(0)
        , headersAvail(false)
        , timeout(timeoutSeconds * 1000)
    {
        l_debug << L"ctor(timeoutSeconds=" << timeoutSeconds << L")";
    }

    virtual ~QTHttpGetStream_ContentStream() {
        l_debug << L"dtor()";
    }

    bool putBytes(QByteArray nbytes) {
        l_debug << L"putBytes(#bytes=" << nbytes.size();
        byps_unique_lock lock(this->mutex);
        while (readPos != readLimit) {
            l_debug << L"wait for write";
            if (waitWrite.wait_for(lock, timeout) == std::cv_status::timeout) {
                l_debug << L")putBytes=false timeout";
                return false;
            }
        }

        l_debug << L"write and notify";
        bytes = nbytes;
        readPos = 0;
        readLimit = nbytes.size();
        waitRead.notify_one();
        l_debug << L")putBytes=true";
        return true;
    }

    void writeClose() {
        l_debug << L"writeClose(";
        byps_unique_lock lock(this->mutex);
        this->finished = true;
        waitRead.notify_one();
        l_debug << L")writeClose";
    }

    void writeError(BException ex) {
        l_debug << L"writeError(";
        byps_unique_lock lock(this->mutex);
        this->ex = ex;
        waitRead.notify_one();
        l_debug << L")writeError";
    }

    void applyHeaders(const std::wstring& contentType, int64_t contentLength) {
        l_debug << L"applyHeaders(contentType=" << contentType << L", contentLength=" << contentLength;
        byps_unique_lock lock(this->mutex);
        this->contentType = contentType;
        this->contentLength = contentLength;
        this->headersAvail = true;
        waitHeaders.notify_one();
        l_debug << L")applyHeaders";
    }

    void maybeWaitUntilHeadersAvail() const {
        l_debug << L"maybeWaitUntilHeadersAvail(";
        QTHttpGetStream_ContentStream* pThis = const_cast<QTHttpGetStream_ContentStream*>(this);
        byps_unique_lock lock(pThis->mutex);
        while(!ex && !headersAvail) {
            if (pThis->waitHeaders.wait_for(lock, timeout) == std::cv_status::timeout) {
                l_debug << L"timeout";
                pThis->ex = BException(EX_TIMEOUT, L"Timeout while waiting for response headers.");
            }
        }
        if (ex) {
            l_debug << L"throw exception=" << ex.toString();
            throw ex;
        }
        l_debug << L")maybeWaitUntilHeadersAvail=" << headersAvail;
    }

    virtual const std::wstring& getContentType() const {
        l_debug << L"getContentType(";
        maybeWaitUntilHeadersAvail();
        l_debug << L")getContentType=" << contentType;
        return contentType;
    }

    virtual int64_t getContentLength() const {
        l_debug << L"getContentLength(";
        maybeWaitUntilHeadersAvail();
        l_debug << L")getContentLength=" << contentLength;
        return contentLength;
    }

    virtual int32_t read(char* buf, int32_t offs, int32_t len) {
        l_debug << L"read(";
        byps_unique_lock lock(this->mutex);

        while (!ex && !finished && readPos == readLimit) {
            if (waitRead.wait_for(lock, timeout) == std::cv_status::timeout) {
                l_debug << L"timeout";
                ex = BException(EX_TIMEOUT, L"Timeout while waiting for response data.");
            }
        }

        if (ex) throw ex;

        if (finished && readPos == readLimit) {
            l_debug << L")read=-1";
            return -1;
        }

        int32_t max = std::min(len, readLimit-readPos);
        memcpy(buf + offs, bytes.data() + readPos, (size_t)max);

        readPos += max;
        if (readPos == readLimit) {
            waitWrite.notify_one();
        }

        l_debug << L")read=" << max;
        return max;
    }

};

class QTHttpClient : public HHttpClient, public byps_enable_shared_from_this<QTHttpClient> {
    void* app;
    static BLogger log;
    QTHttpClientBridge clientBridge;
    PHttpCredentials credentials;

public:
    QTHttpWorkerThread* worker;

    QTHttpClient(void* app)
        : app(app)
        , worker(new QTHttpWorkerThread())
    {
        l_debug << L"ctor(";
        worker->start();

        QObject::connect(&clientBridge, SIGNAL(createGetRequest(QNetworkRequest,int32_t,QTHttpRequestBridge**)),
                         worker->workerBridge, SLOT(createGetRequest(QNetworkRequest,int32_t,QTHttpRequestBridge**)),
                         Qt::BlockingQueuedConnection);

        QObject::connect(&clientBridge, SIGNAL(createPostRequest(QNetworkRequest,int32_t,QByteArray*,QTHttpRequestBridge**)),
                         worker->workerBridge, SLOT(createPostRequest(QNetworkRequest,int32_t,QByteArray*,QTHttpRequestBridge**)),
                         Qt::BlockingQueuedConnection);

        QObject::connect(&clientBridge, SIGNAL(createPutRequest(QNetworkRequest,int32_t,QByteArray*,QTHttpRequestBridge**)),
                         worker->workerBridge, SLOT(createPutRequest(QNetworkRequest,int32_t,QByteArray*,QTHttpRequestBridge**)),
                         Qt::BlockingQueuedConnection);

        QObject::connect(&clientBridge, SIGNAL(createPutStreamRequest(QNetworkRequest,int32_t,QIODevice*,QTHttpRequestBridge**)),
                         worker->workerBridge, SLOT(createPutStreamRequest(QNetworkRequest,int32_t,QIODevice*,QTHttpRequestBridge**)),
                         Qt::BlockingQueuedConnection);

        l_debug << L")ctor";
    }

    virtual ~QTHttpClient() {
        l_debug << L"dtor()";
    }

    virtual void init(const std::wstring& , PHttpCredentials creds) {
        credentials = creds;
    }

    virtual void done() {
        l_debug << L"done(";
        emit worker->quit();
        worker->wait();
        delete worker;
        l_debug << L")done";
    }

    virtual PHttpGetStream getStream(const std::wstring& url);

    virtual PHttpGet get(const std::wstring& url);

    virtual PHttpPost post(const std::wstring& url);

    virtual PHttpPutStream putStream(const std::wstring& url);

    void createGetRequest(PQTHttpRequest req, QNetworkRequest networkRequest, int32_t timeout, QTHttpRequestBridge** ppbridge) {
        l_debug << L"createGetRequest(";
        if (QThread::currentThread() == worker) {
            // This function is called from the worker thread, if an error occurs in a message
            // and the message is to be cancelled. Cancelling a message is performed with a
            // special GET request in HWireClient::sendCancelMessage.
            // see HWireClient_AsyncResultAfterAllRequests::setAsyncResult
            worker->workerBridge->createGetRequest(networkRequest, timeout, ppbridge);
        }
        else {
          emit clientBridge.createGetRequest(networkRequest, timeout, ppbridge);
        }
        l_debug << L"bridge=" << (void*)*ppbridge;
        (*ppbridge)->pThis = req;
        l_debug << L")createGetRequest";
    }

    void createPostRequest(PQTHttpRequest req, QNetworkRequest networkRequest, int32_t timeout, QByteArray* bytesToPost, QTHttpRequestBridge** ppbridge) {
        l_debug << L"createPostRequest(";
        if (QThread::currentThread() == worker) {
            // This function is called from the worker thread, if the serverR is
            // started in BClient::authenticate
            worker->workerBridge->createPostRequest(networkRequest, timeout, bytesToPost, ppbridge);
        }
        else {
            emit clientBridge.createPostRequest(networkRequest, timeout, bytesToPost, ppbridge);
        }
        l_debug << L"bridge=" << (void*)*ppbridge;
        (*ppbridge)->pThis = req;
        l_debug << L")createPostRequest";
    }

    void createPutRequest(PQTHttpRequest req, QNetworkRequest networkRequest, int32_t timeout, QByteArray* bytesToPut, QTHttpRequestBridge** ppbridge) {
        l_debug << L"createPutRequest(";
        if (QThread::currentThread() == worker) {
            // This function is called from the worker thread, if subsequent
            // stream parts have to be sent.
            worker->workerBridge->createPutRequest(networkRequest, timeout, bytesToPut, ppbridge);
        }
        else {
            emit clientBridge.createPutRequest(networkRequest, timeout, bytesToPut, ppbridge);
        }
        l_debug << L"bridge=" << (void*)*ppbridge;
        (*ppbridge)->pThis = req;
        l_debug << L")createPutRequest";
    }

    void createPutStreamRequest(PQTHttpRequest req, QNetworkRequest networkRequest, int32_t timeout, QIODevice* streamIO, QTHttpRequestBridge** ppbridge) {
        l_debug << L"createPutStreamRequest(";
        if (QThread::currentThread() == worker) {
            // This function is called from the worker thread, if subsequent
            // stream parts have to be sent.
            worker->workerBridge->createPutStreamRequest(networkRequest, timeout, streamIO, ppbridge);
        }
        else {
            emit clientBridge.createPutStreamRequest(networkRequest, timeout, streamIO, ppbridge);
        }
        l_debug << L"bridge=" << (void*)*ppbridge;
        (*ppbridge)->pThis = req;
        l_debug << L")createPutStreamRequest";
    }

};

class QTHttpRequest : public virtual HHttpRequest, public byps_enable_shared_from_this<QTHttpRequest> {
protected:
    byps_weak_ptr<QTHttpClient> httpClient;
    std::wstring surl;
    QTHttpRequestBridge* bridge;
    int32_t timeoutSeconds;
    bool requestAborted;
    bool requestFinished;

    PBytes respBytes;
    size_t respPos;

    PAsyncResult asyncBytesReceived;

    BVariant result;
    static BLogger log;

public:
    QTHttpRequest(PQTHttpClient httpClient, const std::wstring& url)
        : httpClient(httpClient)
        , surl(url)
        , bridge(0)
        , timeoutSeconds(0)
        , requestAborted(false)
        , requestFinished(false)
        , respPos(0)
        , asyncBytesReceived(NULL)
    {
        l_debug << L"ctor()";
    }

    virtual ~QTHttpRequest() {
        l_debug << L"dtor(";
        // bridge is deleted with bridge->reply
        l_debug << L")dtor";
    }

    virtual void setTimeouts(int32_t, int32_t sendrecvTimeoutSeconds) {
        timeoutSeconds = sendrecvTimeoutSeconds;
        l_debug << L"setTimeouts() timeoutSeconds=" << timeoutSeconds;
    }

    int32_t getTimeoutSeconds() {
        return timeoutSeconds;
    }

    virtual void done() {
        l_debug << L"done(";
        PQTHttpRequest keepthis = shared_from_this();
        if (!requestFinished) {
            requestFinished = true;
            if (bridge) {
                bridge->done();
            }
            internalApplyResult();
        }
        keepthis.reset();
        l_debug << L")done";
    }

    void abort() {
        l_debug << L"abort(";
        if (bridge && !requestAborted) {
            requestAborted = true;

            bool alreadyFinished = bridge->reply->isFinished();
            if (!alreadyFinished) {
                l_debug << L"abort";
                bridge->reply->abort();
                // reply->abort() will fire httpFinished() which
                // calls done and deletes this
            }
        }
        l_debug << L")abort";
    }

    PQTHttpClient getHttpClient() {
        PQTHttpClient httpClient = this->httpClient.lock();
        if (!httpClient) {
            result = BVariant(BException(EX_CANCELLED, L"HttpClient object already deleted."));
            internalApplyResult();
        }
        return httpClient;
    }

    virtual void internalApplyResult() {
        l_debug << L"internalApplyResult(";
        if (asyncBytesReceived) {
            l_debug << L"result=" << result.toString();
            asyncBytesReceived->setAsyncResult(result);
            asyncBytesReceived = NULL;
        }
        l_debug << L")internalApplyResult";
    }

    virtual void httpFinished() {
        l_debug << L"httpFinished(";

        if (bridge) {
            QVariant varContentLength = bridge->reply->header(QNetworkRequest::ContentLengthHeader);
            qulonglong contentLength = varContentLength.toULongLong();
            l_debug << L"contentLength=" << contentLength;
            QVariant varContentType = bridge->reply->header(QNetworkRequest::ContentTypeHeader);
            QString contentType = varContentType.toString();
            l_debug << L"contentType=" << contentType.toStdWString();
        }

        if (respBytes) {
            l_debug << L"#bytes=" << respPos;
            respBytes->length = respPos;
            if (!result.isException()) {
                result = BVariant(respBytes);
            }
        }
        done();
        l_debug << L")httpFinished";
    }

    virtual void httpReadyRead() {
        l_debug << L"httpReadReady(";

        QByteArray bytes = bridge->reply->readAll();
        size_t bsize = bytes.size();
        l_debug << L"received #bytes=" << bsize;

        if (!respBytes) {
            respBytes = BBytes::create(bsize);
        }
        else if (respPos + bsize > respBytes->length) {
            size_t grow = std::min(respBytes->length, (size_t)1000000);
            size_t ncapacity = std::max(respBytes->length + grow, respPos + bsize);
            l_debug << L"grow buffer to new capacity=" << ncapacity;
            respBytes = BBytes::create(respBytes, ncapacity);
        }

        l_debug << L"copy bytes";
        memcpy(respBytes->data + respPos, bytes.data(), bsize);

        respPos += bsize;
        l_debug << L"received so far: #bytes=" << respPos;

    }

    virtual void httpTimeout() {
        l_debug << L"httpTimeout(";
        httpError(BException(EX_TIMEOUT, L"HTTP request timeout"));
        l_debug << L")httpTimeout";
    }

    virtual void httpError(const BException& ex) {
        l_debug << L"httpError(" << ex;
        if (!requestFinished && !requestAborted) {
            result = BVariant(ex);
            abort();
        }
        l_debug << L")httpError";
    }

    virtual void close() {
        l_debug << L"close(";
        if (!requestFinished) {
            httpError(BException(EX_CANCELLED, L"HTTP request cancelled"));
        }
        l_debug << L")close";
    }


};

class QTHttpGetStream : public HHttpGetStream, public virtual QTHttpRequest {

    byps_weak_ptr<QTHttpGetStream_ContentStream> stream_weak_ptr;
    bool headersApplied;
    static BLogger log;

public:
    QTHttpGetStream(PQTHttpClient httpClient, const std::wstring& url)
        : QTHttpRequest(httpClient, url)
        , headersApplied(false)
    {
        l_debug << L"ctor()";
    }

    virtual ~QTHttpGetStream() {
        l_debug << L"dtor()";
    }

    virtual PContentStream send() {
        l_debug << L"send(";
        byps_ptr<QTHttpGetStream_ContentStream> ret(new QTHttpGetStream_ContentStream(timeoutSeconds));
        this->stream_weak_ptr = ret;

        PQTHttpClient httpClient = getHttpClient();
        if (httpClient) {
            l_debug << L"networkManager->get...";
            QNetworkRequest networkRequest(QUrl(QString::fromStdWString(surl)));
            httpClient->createGetRequest(shared_from_this(), networkRequest, getTimeoutSeconds(), &bridge);
            l_debug << L"networkManager->get OK";
        }

        l_debug << L")send";
        return ret;
    }

    byps_ptr<QTHttpGetStream_ContentStream> getStreamOrAbort() {
        l_debug << L"getStreamOrAbort(";
        byps_ptr<QTHttpGetStream_ContentStream> stream = stream_weak_ptr.lock();
        if (!stream && !bridge->reply->isFinished()) {
             abort();
        }
        l_debug << L")getStreamOrAbort=" << stream.get();
        return stream;
    }

    virtual void internalApplyResult() {
        l_debug << L"internalApplyResult(";
        byps_ptr<QTHttpGetStream_ContentStream> stream = getStreamOrAbort();
        if (stream) {
            if (result.isException()) {
                l_debug << L"stream->writeError " << result.getException().toString();
                stream->writeError(result.getException());
            }
            else {
                l_debug << L"stream->writeClose";
                stream->writeClose();
            }
         }
         l_debug << L")internalApplyResult";
    }

    virtual void httpFinished() {
        l_debug << L"httpFinished(";
        applyHeadersIfNot();
        if (!result.isException()) {
            result = BVariant(true);
        }
        done();
        l_debug << L")httpFinished";
       }

    virtual void httpReadyRead() {
        l_debug << L"httpReadyRead(";
        applyHeadersIfNot();
        byps_ptr<QTHttpGetStream_ContentStream> stream = getStreamOrAbort();
        if (stream) {
            stream->putBytes(bridge->reply->readAll());
        }
        l_debug << L")httpReadyRead";
    }

    void applyHeadersIfNot() {
        l_debug << L"applyHeadersIfNot(";
        l_debug << L"headersApplied=" << headersApplied;
        if (!headersApplied) {
            headersApplied = true;

            byps_ptr<QTHttpGetStream_ContentStream> stream = getStreamOrAbort();
            if (stream) {

                QByteArray headerValue = bridge->reply->rawHeader("Content-Type");
                std::wstring contentType = BToStdWString(headerValue.data());

                headerValue = bridge->reply->rawHeader("Content-Length");
                int64_t contentLength = headerValue.size() ? QString(headerValue).toLongLong() : -1;

                stream->applyHeaders(contentType, contentLength);
            }
        }
        l_debug << L")applyHeadersIfNot";
    }
};

class QTHttpGet : public HHttpGet, public virtual QTHttpRequest {
    friend class QTHttpPostWorker;
    static BLogger log;
public:

    QTHttpGet(PQTHttpClient httpClient, const std::wstring& url)
        : QTHttpRequest(httpClient, url)
    {
        l_debug << L"ctor()";
    }

    virtual ~QTHttpGet() {
        l_debug << L"dtor()";
    }

    virtual void send(PAsyncResult asyncBytesReceived) {
        l_debug << L"send(";
         this->asyncBytesReceived = asyncBytesReceived;

        PQTHttpClient httpClient = getHttpClient();
        if (httpClient) {
            l_debug << L"networkManager->post...";
            QNetworkRequest networkRequest(QUrl(QString::fromStdWString(surl)));
            httpClient->createGetRequest(shared_from_this(), networkRequest, getTimeoutSeconds(), &bridge);
            l_debug << L"networkManager->post OK";
        }

        l_debug << L")send";
    }

};


class QTHttpPost : public HHttpPost, public virtual QTHttpRequest {
    QByteArray* bytesToPost;
    friend class QTHttpPostWorker;
    static BLogger log;
public:

    QTHttpPost(PQTHttpClient httpClient, const std::wstring& url)
        : QTHttpRequest(httpClient, url)
        , bytesToPost(NULL)
    {
        l_debug << L"ctor()";
    }

    virtual ~QTHttpPost() {
        l_debug << L"dtor()";
        if (bytesToPost) delete bytesToPost;
    }

    virtual void send(PBytes bytes, const std::wstring& contentType, PAsyncResult asyncBytesReceived) {
        l_debug << L"send(#bytes=" << bytes->length << L", contentType=" << contentType;
        this->bytesToPost = new QByteArray((const char*)bytes->data, bytes->length);
        this->asyncBytesReceived = asyncBytesReceived;

        QNetworkRequest networkRequest(QUrl(QString::fromStdWString(surl)));
        networkRequest.setHeader(QNetworkRequest::ContentTypeHeader, QVariant(QString::fromStdWString(contentType)));
        networkRequest.setHeader(QNetworkRequest::ContentLengthHeader, QVariant((qulonglong)bytes->length));

        PQTHttpClient httpClient = getHttpClient();
        if (httpClient) {
            l_debug << L"networkManager->post...";
            httpClient->createPostRequest(shared_from_this(), networkRequest, getTimeoutSeconds(), bytesToPost, &bridge);
            l_debug << L"networkManager->post OK";
        }

        l_debug << L")send";
    }

};

QTPutStreamIODevice::QTPutStreamIODevice(PContentStream strm, QObject* parent)
    : QIODevice(parent)
    , strm(strm) {
}

QTPutStreamIODevice::~QTPutStreamIODevice() {
    strm.reset();
}

bool QTPutStreamIODevice::open(OpenMode mode) {
    bool succ = ((mode & ~ReadOnly) != 0);
    if (succ) {
        setOpenMode(mode);
    }
    return succ;
}

void QTPutStreamIODevice::close() {
    strm.reset();
    setOpenMode(NotOpen);
}

bool QTPutStreamIODevice::isSequential() const {
    return false;
}

qint64 QTPutStreamIODevice::size() const {
    return strm->getContentLength();
}

qint64 QTPutStreamIODevice::bytesAvailable() const {
    return size();
}

qint64 QTPutStreamIODevice::readData(char* data, qint64 maxSize) {
    int32_t len = (int32_t)(maxSize & 0x7FFFFFFFF);
    return strm->read(data, 0, len);
}

qint64 QTPutStreamIODevice::writeData(const char* , qint64 ) {
    return -1;
}


class QTHttpPutStream : public HHttpPutStream, public virtual QTHttpRequest {
    PContentStream streamToPut;
    PAsyncResult asyncBoolFinished;
    int64_t partId;
    int64_t nbOfParts;
    int64_t totalLength;
    bool isLastPart;

    QTPutStreamIODevice* streamIO;

    QByteArray bytesToPut;
    void* data; // just for debugging QByteArray, i want to see, whether resize() changes the internal buffer

    PQTHttpRequest keepThisUntilLastPart;

    std::wstring baseUrl;
    friend class QTHttpPutStreamWorker;
    static BLogger log;
public:
    QTHttpPutStream(PQTHttpClient httpClient, const std::wstring& url)
        : QTHttpRequest(httpClient, url)
        , streamToPut(NULL)
        , asyncBoolFinished(NULL)
        , partId(0)
        , nbOfParts(0)
        , totalLength(0)
        , isLastPart(false)
        , streamIO(NULL)
        , data(NULL)
    {
        l_debug << L"ctor()";
    }

    virtual ~QTHttpPutStream() {
        l_debug << L"dtor()";
    }

    virtual void send(PContentStream strm, PAsyncResult asyncBoolFinished) {
        internalSendAsByteArray(strm, asyncBoolFinished);
    }

    void internalSendAsIODevice(PContentStream strm, PAsyncResult asyncBoolFinished) {
        int64_t contentLength = strm->getContentLength();
        l_debug << L"send(contentLength=" << contentLength << L", contentType=" << strm->getContentType();

        PQTHttpClient httpClient = getHttpClient();
        if (httpClient) {

            this->asyncBoolFinished = asyncBoolFinished;
            this->streamToPut = strm;
            this->totalLength = contentLength;
            this->baseUrl = surl;
            this->streamIO = new QTPutStreamIODevice(strm);

            l_debug << L"header contentType=" << streamToPut->getContentType();
            l_debug << L"header contentLength=" << contentLength;
            QNetworkRequest networkRequest(QUrl(QString::fromStdWString(surl)));
            networkRequest.setHeader(QNetworkRequest::ContentTypeHeader, QVariant(QString::fromStdWString(streamToPut->getContentType())));
            networkRequest.setHeader(QNetworkRequest::ContentLengthHeader, QVariant((qulonglong)contentLength));
            networkRequest.setAttribute(QNetworkRequest::DoNotBufferUploadDataAttribute, QVariant(true));

            l_debug << L"networkManager->put...";
            httpClient->createPutStreamRequest(shared_from_this(), networkRequest, getTimeoutSeconds(), streamIO, &bridge);
            l_debug << L"networkManager->put OK";
        }
        else {
            BException ex(EX_CANCELLED, L"HTTP client already deleted.");
            httpError(ex);
        }
    }

    void internalSendAsByteArray(PContentStream strm, PAsyncResult asyncBoolFinished) {
        int64_t contentLength = strm->getContentLength();
        l_debug << L"send(contentLength=" << contentLength << L", contentType=" << strm->getContentType();

        this->asyncBoolFinished = asyncBoolFinished;
        this->streamToPut = strm;
        this->totalLength = contentLength;
        this->baseUrl = surl;

        if (totalLength >= 0) {
            nbOfParts = totalLength / MAX_STREAM_PART_SIZE;
            if (totalLength % MAX_STREAM_PART_SIZE) {
                nbOfParts++;
            }
        }
        else {
            nbOfParts = INT64_MAX;
        }

        keepThisUntilLastPart = shared_from_this();

        sendNextPart(0);
    }

    void sendNextPart(int64_t nextPartId) {
        l_debug << L"sendNextPart(nextPartId=" << nextPartId;

        this->partId = nextPartId;

         PQTHttpClient httpClient = getHttpClient();
        if (httpClient) {

            int32_t contentLength = 0;

            bytesToPut.clear();

            // Read stream part into buffer
            if (totalLength >= 0) {
                size_t capacity = std::min((size_t)totalLength, (size_t)MAX_STREAM_PART_SIZE);
                bytesToPut.resize(capacity);

                data = bytesToPut.data();
                l_debug << L"read from stream..." << (void*)data;
                contentLength = streamToPut->read((char*)data, 0, capacity);
                if (contentLength < 0) contentLength = 0; // true, if stream is empty
                l_debug << L"read from stream OK, #bytes=" << contentLength;
                isLastPart = partId >= nbOfParts-1; // nbOfParts might be 0
                l_debug << L"isLastPart=" << isLastPart;
            }
            else {
                size_t capacity = MAX_STREAM_PART_SIZE;
                bytesToPut.resize(capacity);

                data = bytesToPut.data();
                l_debug << L"read from stream..." << (void*)data;
                contentLength = streamToPut->read((char*)data, 0, capacity);
                l_debug << L"read from stream OK, #bytes=" << contentLength;
                if (contentLength < 0) contentLength = 0; // true, if stream is empty or stream size is a multiple of MAX_STREAM_PART_SIZE
                isLastPart = contentLength < MAX_STREAM_PART_SIZE;
                l_debug << L"isLastPart=" << isLastPart;
            }

            bytesToPut.resize(contentLength);
            data = bytesToPut.data();
            l_debug << L"buffer resized to contentLength, " << (void*)data;

            // Append partid, totallength to URL
            QString partUrl(QString::fromStdWString(baseUrl));
            partUrl.append("&partid=").append(QString::number(partId));
            partUrl.append("&total=").append(QString::number(totalLength));
            partUrl.append("&last=").append(QString::number(isLastPart));
            l_debug << L"partUrl=" << partUrl.toStdWString();

            l_debug << L"header contentType=" << streamToPut->getContentType();
            l_debug << L"header contentLength=" << contentLength;
            QNetworkRequest networkRequest(partUrl);
            networkRequest.setHeader(QNetworkRequest::ContentTypeHeader, QVariant(QString::fromStdWString(streamToPut->getContentType())));
            networkRequest.setHeader(QNetworkRequest::ContentLengthHeader, QVariant((qulonglong)contentLength));
            networkRequest.setAttribute(QNetworkRequest::DoNotBufferUploadDataAttribute, QVariant(true));

            l_debug << L"networkManager->put...";
            httpClient->createPutRequest(shared_from_this(), networkRequest, getTimeoutSeconds(), &bytesToPut, &bridge);
            l_debug << L"networkManager->put OK";

        }
        else {
            // httpClient is already released. This should not happend during the HTTP request.
            result = BVariant(BException(EX_CANCELLED, L"HTTP client has already been released."));
            internalApplyResult();
        }

        l_debug << L")sendNextPart";
    }

    virtual void internalApplyResult() {
        if (asyncBoolFinished) {
            l_debug << L"result=" << result.toString();
            asyncBoolFinished->setAsyncResult(result);
            asyncBoolFinished = NULL;
        }
    }

    virtual void httpFinished() {
        l_debug << L"httpFinished(";
        if (streamIO) {
            l_debug << L"stream was sent";
        }
        else {
            l_debug << L"isLastPart=" << isLastPart;
            if (isLastPart) {

                keepThisUntilLastPart.reset();

                if (!result.isException()) {
                    result = BVariant(true);
                }
                done();
            }
            else {

                sendNextPart(partId+1);
            }
        }
        l_debug << L")httpFinished";
    }

    virtual void httpError(const BException& ex) {

        keepThisUntilLastPart.reset();

        QTHttpRequest::httpError(ex);
    }

    virtual void httpReadyRead() {
        l_debug << L"httpReadyRead(";
        bridge->reply->readAll();
        l_debug << L")httpReadyRead";
    }

};

BINLINE QTHttpRequestBridge::QTHttpRequestBridge(QNetworkReply* reply, int32_t timeoutSeconds)
    : QObject(reply)
    , reply(reply)
{
    l_debug << L"ctor(";

    l_debug << L"connect signals";
    QObject::connect(reply, SIGNAL(finished()),
                     this, SLOT(httpFinished()));
    QObject::connect(reply, SIGNAL(readyRead()),
                     this, SLOT(httpReadyRead()));
    QObject::connect(reply, SIGNAL(error(QNetworkReply::NetworkError)),
                     this, SLOT(httpError(QNetworkReply::NetworkError)));

    if (timeoutSeconds) {

        QObject::connect(&timer, SIGNAL(timeout()),
                         this, SLOT(httpTimeout()));

        l_debug << L"start timer, timeoutSeconds=" << timeoutSeconds;
        timer.setSingleShot(true);
        timer.start(timeoutSeconds * 1000);
    }



    l_debug << L")ctor";
}

BINLINE QTHttpRequestBridge::~QTHttpRequestBridge() {
    l_debug << L"dtor(";
    //reply->deleteLater();
    l_debug << L")dtor";
}

BINLINE void QTHttpRequestBridge::httpFinished() {
    l_debug << L"httpFinished(";
    timer.stop();
    if (pThis) {
       pThis->httpFinished();
       pThis.reset();
    }
    reply->deleteLater();
    l_debug << L")httpFinished";
}

BINLINE void QTHttpRequestBridge::httpReadyRead() {
    l_debug << L"httpReadyRead(";
    if (pThis) {
        int32_t timeoutSeconds = pThis->getTimeoutSeconds();
        if (timeoutSeconds) {
            l_debug << L"restart timer, timeoutSeconds=" << timeoutSeconds;
            timer.stop();
            timer.start(timeoutSeconds * 1000);
        }
        pThis->httpReadyRead();
    }
    l_debug << L")httpReadyRead";
}

BINLINE void QTHttpRequestBridge::httpTimeout() {
    l_debug << L"httpTimeout(";
    timer.stop();
    if (pThis) {
        pThis->httpTimeout();
    }
    l_debug << L")httpTimeout";
}

BINLINE void QTHttpRequestBridge::httpError(QNetworkReply::NetworkError err) {
    l_debug << L"httpError(" << err;
    timer.stop();
    QString str = reply->errorString();
    std::wstring msg = str.toStdWString();
    if (pThis) {
        pThis->httpError(BException(EX_IOERROR, msg));
    }
    l_debug << L")httpError";
}

BINLINE void QTHttpRequestBridge::done() {
    l_debug << L"done()";
    pThis.reset();
}

BINLINE PHttpGetStream QTHttpClient::getStream(const std::wstring& url) {
    l_debug << L"getStream(" << url;
    QTHttpGetStream* req = new QTHttpGetStream(shared_from_this(), url);
    l_debug << L")getStream";
    return PHttpGetStream(req);
}

BINLINE PHttpGet QTHttpClient::get(const std::wstring& url) {
    l_debug << L"get(" << url;
    QTHttpGet* req = new QTHttpGet(shared_from_this(), url);
    l_debug << L")get";
    return PHttpGet(req);
}

BINLINE PHttpPost QTHttpClient::post(const std::wstring& url) {
    l_debug << L"post(" << url;
    QTHttpPost* req = new QTHttpPost(shared_from_this(), url);
    l_debug << L")post";
    return PHttpPost(req);
}

BINLINE PHttpPutStream QTHttpClient::putStream(const std::wstring& url) {
    l_debug << L"putStream(" << url;
    QTHttpPutStream* req = new QTHttpPutStream(shared_from_this(), url);
    l_debug << L")putStream";
    return PHttpPutStream(req);
}

BINLINE QTHttpWorkerThread::QTHttpWorkerThread()
    : workerBridge(new QTHttpWorkerBridge())
{
    l_debug << L"ctor()";
    workerBridge->moveToThread(this);
    workerBridge->networkManager->moveToThread(this);
}

BINLINE QTHttpWorkerThread::~QTHttpWorkerThread()
{
    l_debug << L"dtor()";
    delete workerBridge;
}

BINLINE void QTHttpWorkerThread::run() {
    l_debug << L"run(";
    exec();
    l_debug << L")run";
}

BINLINE QTHttpWorkerBridge::QTHttpWorkerBridge()
    : networkManager(new QNetworkAccessManager())
{
}

BINLINE void QTHttpWorkerBridge::createGetRequest(QNetworkRequest networkRequest, int32_t timeout, QTHttpRequestBridge ** ppbridge)
{
    l_debug << L"createGetRequest(";
    QNetworkReply* reply = networkManager->get(networkRequest);
    *ppbridge = new QTHttpRequestBridge(reply, timeout);
    l_debug << L")createGetRequest";
}

BINLINE void QTHttpWorkerBridge::createPostRequest(QNetworkRequest networkRequest, int32_t timeout, QByteArray* bytesToPost, QTHttpRequestBridge ** ppbridge)
{
    l_debug << L"createPostRequest(";
    QNetworkReply* reply = networkManager->post(networkRequest, *bytesToPost);
    *ppbridge = new QTHttpRequestBridge(reply, timeout);
    l_debug << L")createPostRequest";
}

BINLINE void QTHttpWorkerBridge::createPutRequest(QNetworkRequest networkRequest, int32_t timeout, QByteArray* bytesToPut, QTHttpRequestBridge ** ppbridge)
{
    l_debug << L"createPutRequest(";
    QNetworkReply* reply = networkManager->put(networkRequest, *bytesToPut);
    *ppbridge = new QTHttpRequestBridge(reply, timeout);
    l_debug << L")createPutRequest";
}

BINLINE void QTHttpWorkerBridge::createPutStreamRequest(QNetworkRequest networkRequest, int32_t timeout, QIODevice* streamIO, QTHttpRequestBridge ** ppbridge)
{
    l_debug << L"createPutRequest(";
    QNetworkReply* reply = networkManager->put(networkRequest, streamIO);
    *ppbridge = new QTHttpRequestBridge(reply, timeout);
    l_debug << L")createPutRequest";
}


BLogger QTHttpGetStream_ContentStream::log("QTHttpGetStream_ContentStream");
BLogger QTHttpClient::log("QTHttpClient");
BLogger QTHttpRequest::log("QTHttpRequest");
BLogger QTHttpGetStream::log("QTHttpGetStream");
BLogger QTHttpPost::log("QTHttpPost");
BLogger QTHttpGet::log("QTHttpGet");
BLogger QTHttpPutStream::log("QTHttpPutStream");
BLogger QTHttpWorkerThread::log("QTHttpWorkerThread");
BLogger QTHttpRequestBridge::log("QTHttpRequestBridge");
BLogger QTHttpWorkerBridge::log("QTHttpWorkerBridge");

}}}


namespace byps { namespace http {

BINLINE PHttpClient HttpClient_create(void* app) {
    return PHttpClient(new byps::http::qthttp::QTHttpClient(app));
}

}}

#endif // QTHTTPCLIENT_HPP
/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HEXCEPTION_HPP_
#define HEXCEPTION_HPP_

#include "Bypshttp.h"
#include "HException.h"

namespace byps { namespace http { namespace winhttp {

using namespace byps;

BINLINE LPCWSTR HException::getWinHttpErrorMessage(DWORD err) {
  switch (err) {
    case ERROR_WINHTTP_AUTO_PROXY_SERVICE_ERROR:
      return L"Returned by WinHttpGetProxyForUrl when a proxy for the specified URL cannot be located.";
    case ERROR_WINHTTP_AUTODETECTION_FAILED:
      return L"Returned by WinHttpDetectAutoProxyConfigUrl if WinHTTP was unable to discover the URL of the Proxy Auto-Configuration (PAC) file.";
    case ERROR_WINHTTP_BAD_AUTO_PROXY_SCRIPT:
      return L"An error occurred executing the script code in the Proxy Auto-Configuration (PAC) file.";
    case ERROR_WINHTTP_CANNOT_CALL_AFTER_OPEN:
      return L"Returned by the HttpRequest object if a specified option cannot be requested after the Open method has been called.";
    case ERROR_WINHTTP_CANNOT_CALL_AFTER_SEND: 
      return L"Returned by the HttpRequest object if a requested operation cannot be performed after calling the Send method.";
    case ERROR_WINHTTP_CANNOT_CALL_BEFORE_OPEN:
      return L"Returned by the HttpRequest object if a requested operation cannot be performed before calling the Open method.";
    case ERROR_WINHTTP_CANNOT_CALL_BEFORE_SEND:
      return L"Returned by the HttpRequest object if a requested operation cannot be performed before calling the Send method.";
    case ERROR_WINHTTP_CANNOT_CONNECT:
      return L"Returned if connection to the server failed.";
    case ERROR_WINHTTP_CLIENT_AUTH_CERT_NEEDED:
      return L"The server requires SSL client Authentication.";
//    case ERROR_WINHTTP_CLIENT_CERT_NO_ACCESS_PRIVATE_KEY:
//      return L"The application does not have the required privileges to access the private key associated with the client certificate.";
//    case ERROR_WINHTTP_CLIENT_CERT_NO_PRIVATE_KEY:
//      return L"The context for the SSL client certificate does not have a private key associated with it. The client certificate may have been imported to the computer without the private key.";
    case ERROR_WINHTTP_CHUNKED_ENCODING_HEADER_SIZE_OVERFLOW:
      return L"Returned by WinHttpReceiveResponse when an overflow condition is encountered in the course of parsing chunked encoding.";
//    case ERROR_WINHTTP_CLIENT_AUTH_CERT_NEEDED:
//      return L"Returned by WinHttpReceiveResponse when the server requests client authentication.";
    case ERROR_WINHTTP_CONNECTION_ERROR:
      return L"The connection with the server has been reset or terminated, or an incompatible SSL protocol was encountered. For example, WinHTTP version 5.1 does not support SSL2 unless the client specifically enables it.";
//    case ERROR_WINHTTP_HEADER_ALREADY_EXISTS:
//      return L"Obsolete; no longer used.";
    case ERROR_WINHTTP_HEADER_COUNT_EXCEEDED:
      return L"Returned by WinHttpReceiveResponse when a larger number of headers were present in a response than WinHTTP could receive.";
    case ERROR_WINHTTP_HEADER_NOT_FOUND:
      return L"The requested header cannot be located.";
    case ERROR_WINHTTP_HEADER_SIZE_OVERFLOW:
      return L"Returned by WinHttpReceiveResponse when the size of headers received exceeds the limit for the request handle.";
    case ERROR_WINHTTP_INCORRECT_HANDLE_STATE:
      return L"The requested operation cannot be carried out because the handle supplied is not in the correct state.";
    case ERROR_WINHTTP_INCORRECT_HANDLE_TYPE:
      return L"The type of handle supplied is incorrect for this operation.";
    case ERROR_WINHTTP_INTERNAL_ERROR:
      return L"An internal error has occurred.";
    case ERROR_WINHTTP_INVALID_OPTION:
      return L"A request to WinHttpQueryOption or WinHttpSetOption specified an invalid option value.";
//    case ERROR_WINHTTP_INVALID_QUERY_REQUEST:
//      return L"Obsolete; no longer used.";
    case ERROR_WINHTTP_INVALID_SERVER_RESPONSE:
      return L"The server response cannot be parsed.";
    case ERROR_WINHTTP_INVALID_URL:
      return L"The URL is not valid.";
    case ERROR_WINHTTP_LOGIN_FAILURE:
      return L"The login attempt failed.";
    case ERROR_WINHTTP_NAME_NOT_RESOLVED:
      return L"The server name cannot be resolved.";
//    case ERROR_WINHTTP_NOT_INITIALIZED:
//      return L"Obsolete; no longer used.";
    case ERROR_WINHTTP_OPERATION_CANCELLED:
      return L"The operation was canceled, usually because the handle on which the request was operating was closed before the operation completed.";
    case ERROR_WINHTTP_OPTION_NOT_SETTABLE:
      return L"The requested option cannot be set, only queried.";
//    case ERROR_WINHTTP_OUT_OF_HANDLES:
//      return L"Obsolete; no longer used.";
    case ERROR_WINHTTP_REDIRECT_FAILED:
      return L"The redirection failed because either the scheme changed or all attempts made to redirect failed (default is five attempts).";
    case ERROR_WINHTTP_RESEND_REQUEST:
      return L"The WinHTTP function failed. The desired function can be retried on the same request handle.";
    case ERROR_WINHTTP_RESPONSE_DRAIN_OVERFLOW:
      return L"Returned when an incoming response exceeds an internal WinHTTP size limit.";
    case ERROR_WINHTTP_SECURE_CERT_CN_INVALID:
      return L"Returned when a certificate CN name does not match the passed value (equivalent to a CERT_E_CN_NO_MATCH error).";
    case ERROR_WINHTTP_SECURE_CERT_DATE_INVALID:
      return L"Indicates that a required certificate is not within its validity period when verifying against the current system clock or the timestamp in the signed file, or that the validity periods of the certification chain do not nest correctly (equivalent to a CERT_E_EXPIRED or a CERT_E_VALIDITYPERIODNESTING error).";
    case ERROR_WINHTTP_SECURE_CERT_REV_FAILED:
      return L"Indicates that revocation cannot be checked because the revocation server was offline (equivalent to CRYPT_E_REVOCATION_OFFLINE).";
    case ERROR_WINHTTP_SECURE_CERT_REVOKED:
      return L"Indicates that a certificate has been revoked (equivalent to CRYPT_E_REVOKED).";
    case ERROR_WINHTTP_SECURE_CERT_WRONG_USAGE:
      return L"Indicates that a certificate is not valid for the requested usage (equivalent to CERT_E_WRONG_USAGE).";
    case ERROR_WINHTTP_SECURE_CHANNEL_ERROR:
      return L"Indicates that an error occurred having to do with a secure channel.";
    case ERROR_WINHTTP_SECURE_FAILURE:
      return L"One or more errors were found in the Secure Sockets Layer (SSL) certificate sent by the server.";
    case ERROR_WINHTTP_SECURE_INVALID_CA:
      return L"Indicates that a certificate chain was processed, but terminated in a root certificate that is not trusted by the trust provider (equivalent to CERT_E_UNTRUSTEDROOT).";
    case ERROR_WINHTTP_SECURE_INVALID_CERT:
      return L"Indicates that a certificate is invalid (equivalent to errors such as CERT_E_ROLE, CERT_E_PATHLENCONST, CERT_E_CRITICAL, CERT_E_PURPOSE, CERT_E_ISSUERCHAINING, CERT_E_MALFORMED and CERT_E_CHAINING).";
    case ERROR_WINHTTP_SHUTDOWN:
      return L"The WinHTTP function support is being shut down or unloaded.";
    case ERROR_WINHTTP_TIMEOUT:
      return L"The request has timed out.";
    case ERROR_WINHTTP_UNABLE_TO_DOWNLOAD_SCRIPT:
      return L"The PAC file cannot be downloaded. For example, the server referenced by the PAC URL may not have been reachable, or the server returned a 404 NOT FOUND response.";
    case ERROR_WINHTTP_UNRECOGNIZED_SCHEME: 
      return L"The URL specified a scheme other than \"http:\" or \"https:\".";
  }
  return L"";
}

BINLINE HException::HException(LPCWSTR fnctName, DWORD err) : BException() {

	int32_t code;
	std::wstring msg;
	std::wstring details;

	switch(err) {
	case ERROR_WINHTTP_TIMEOUT : code = EX_TIMEOUT; break;
	case ERROR_WINHTTP_OPERATION_CANCELLED : code = EX_CANCELLED; break;
	default : code = EX_CONNECTION_TO_SERVER_FAILED;
	}

	{
		std::wstringstream ss;
		ss << L"HTTP communication error";
		LPCWSTR winmsg = getWinHttpErrorMessage(err);
		if (winmsg && *winmsg) ss << L": " << winmsg;
		msg = ss.str();
	}

	{
		std::wstringstream ss;
		ss << fnctName << L" failed, windows error code=" << err;
		details = ss.str();
	}

	init(code, msg, details, "");
}

BINLINE HException::HException(DWORD httpStatus) : BException() {

	int32_t code = httpStatus;
	std::wstring msg;

	std::wstringstream ss;
	ss << L"HTTP " << httpStatus;
	msg = ss.str();

	init(code, msg, L"", "");
}

}}}

#endif/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef WINHTTPCLIENT_HPP_
#define WINHTTPCLIENT_HPP_

#include "WinHttpClient.h"
#include <Windows.h>
#include <Winhttp.h>
#include "HException.hpp"
#include <strsafe.h>

#undef min

#pragma comment( lib, "winhttp.lib" )

namespace byps { namespace http { namespace winhttp {

using namespace byps;
using namespace byps::http;

class WinHttpRequest;
typedef byps_ptr<WinHttpRequest> PWinHttpRequest;

class WinHttpGet;
typedef byps_ptr<WinHttpGet> PWinHttpGet;

class WinHttpGetStream;
typedef byps_ptr<WinHttpGetStream> PWinHttpGetStream;

class WinHttpPost;
typedef byps_ptr<WinHttpPost> PWinHttpPost;

class WinHttpPutStream;
typedef byps_ptr<WinHttpPutStream> PWinHttpPutStream;

	static byps_atomic<int> s_handleCount;

class WinHttpRequest : public virtual HHttpRequest, public byps_enable_shared_from_this<WinHttpRequest> {
//#ifdef _DEBUG
//	char watchForMemLeak[1000*1000];
//#endif
protected:
	HINTERNET hRequest;
	byps_atomic<bool> handleClosed;

	std::wstring contentType;
	int64_t contentLength;
	DWORD statusCode;
	PAsyncResult asyncResult;
	std::wstring url; 
		
	PBytes sendBytes;
	size_t sendIdx;

	PBytes respBytes;
	size_t respIdx;


	byps_mutex mutex;
	byps_condition_variable waitForHeadersAvailable;

	PWinHttpRequest holdReferenceForWinHTTP;

	static BLogger log;

	//static LONG openRequests;

public:

	WinHttpRequest(HINTERNET hRequest, const std::wstring& url) 
		: hRequest(hRequest)
		, handleClosed(false)
		, contentLength(0)
		, statusCode(0)
		, asyncResult(NULL)
		, url(url)
		, sendIdx(0)
		, respIdx(0)
	{
		//InterlockedIncrement(&openRequests);
	}

	virtual ~WinHttpRequest() {
	}

	// close might delete this
	virtual void close() {
		bool expectedClosed = false;
		if (handleClosed.compare_exchange_strong(expectedClosed, true)) {

			// WinHttpCloseHandle will call onHandleClosing where this might be deleted
			PWinHttpRequest holdMe = shared_from_this();
			
			WinHttpCloseHandle(hRequest);

			s_handleCount--;
			l_debug << L"close " << typeid(*this).name() << L", handleCount=" << s_handleCount;
			//assert(InterlockedDecrement(&openRequests) >= 0);

			// Keep value of hRequest for onHandleClosing
			//hRequest = NULL;

		}
	}

	virtual void finishOnError(const BException& ex) throw() {
		if (asyncResult) {
			asyncResult->setAsyncResult(BVariant(ex));
			asyncResult = NULL;
		}
		close();
	}

	virtual void finishOnOK() throw() {
		if (asyncResult) {
			if (respBytes) { // shoud not be null
				respBytes->length = respIdx;
				asyncResult->setAsyncResult(BVariant(respBytes));
			}
			else {
				asyncResult->setAsyncResult(BVariant(BException(EX_IOERROR, L"No bytes received")));
			}
			asyncResult = NULL;
		}
		close();
	}

	virtual void setTimeouts(int32_t connectTimeoutSeconds, int32_t sendrecvTimeoutSeconds) {
		WinHttpSetTimeouts(hRequest, 
			connectTimeoutSeconds * 1000, 
			connectTimeoutSeconds * 1000, 
			sendrecvTimeoutSeconds * 1000, 
			sendrecvTimeoutSeconds * 1000);
	}

	void getRequestHeaders(std::wstring& headers, DWORD& totalLength) {

		std::wstringstream wssHeaders;

		if (contentLength >= 0x100000000LL) {
			// Starting in Windows Vista and Windows Server 2008, 
			// WinHttp supports uploading files up to the size of a LARGE_INTEGER ...
			// http://msdn.microsoft.com/en-us/library/aa384110(v=vs.85).aspx
			OSVERSIONINFOEXW verInfo={0};
			verInfo.dwOSVersionInfoSize = sizeof(verInfo);
			::GetVersionExW((OSVERSIONINFOW*)&verInfo);

			if (verInfo.dwMajorVersion >= 6) {
				wssHeaders << L"Content-Length: " << contentLength << L"\r\n";
				totalLength = WINHTTP_IGNORE_REQUEST_TOTAL_LENGTH;
			}
			else {
				// Cannot send requests > 2GB on OS older than Vista
				throw HException(L"WinHttpSendRequest", ERROR_INVALID_PARAMETER);
			}
		}
		else if (contentLength > 0) {
			totalLength = (DWORD)contentLength;
		}
		else if (contentLength < 0) {
			// Starting in Windows Vista and Windows Server 2008, WinHttp enables applications to 
			// perform chunked transfer encoding on data sent to the server. 
			OSVERSIONINFOEXW verInfo={0};
			verInfo.dwOSVersionInfoSize = sizeof(verInfo);
			::GetVersionExW((OSVERSIONINFOW*)&verInfo);

			if (verInfo.dwMajorVersion >= 6) {

				// Example: http://senthilvels.blogspot.de/2011/08/uploading-chunk-data-to-server-using.html

				wssHeaders << L"Transfer-Encoding: chunked\r\n";
				totalLength = WINHTTP_IGNORE_REQUEST_TOTAL_LENGTH;

			}
			else {
				// Cannot send chunked data
				throw HException(L"WinHttpSendRequest", ERROR_INVALID_PARAMETER);
			}
		}
		else {
			totalLength = 0;
		}

		if (contentType.size()) {
			wssHeaders << L"Content-Type: " << contentType;
			wssHeaders << L"\r\n";
		}

		headers = wssHeaders.str();
	}

	void sendRequest() {

		std::wstring headers;
		DWORD totalLength = 0;
		getRequestHeaders(headers, totalLength);

		holdReferenceForWinHTTP = shared_from_this();

		BOOL succ = WinHttpSendRequest(hRequest, 
						headers.size() ? headers.c_str() : WINHTTP_NO_ADDITIONAL_HEADERS, 
						(DWORD)headers.size(), 
						NULL, 0,
						(DWORD)totalLength, 
						(DWORD_PTR) this);

		if( !succ ) {
			if (asyncResult) {
				DWORD err = GetLastError();
				finishOnError(HException(L"WinHttpSendRequest", err));
			}
		}
	}

	virtual void onHandleClosing(HINTERNET handle) throw() {
		if (hRequest == handle) {
			holdReferenceForWinHTTP.reset();
		}
	}

	virtual void onSendComplete() throw() {
		writeDataOrReceiveResponse();
	}
	
	virtual void onHeadersAvailable() throw() {
		LPWSTR lpszResponseHeaders = NULL;
		DWORD dwResponseHeadersSize = 0;

		BOOL succ = WinHttpQueryHeaders(hRequest, 
								 WINHTTP_QUERY_RAW_HEADERS_CRLF,
								 WINHTTP_HEADER_NAME_BY_INDEX, NULL, 
								 &dwResponseHeadersSize, 
								 WINHTTP_NO_HEADER_INDEX );

		if (!succ )  {

			DWORD err = GetLastError();
			if (err == ERROR_INSUFFICIENT_BUFFER){
        
				err = 0;
				lpszResponseHeaders = new WCHAR[dwResponseHeadersSize];

				succ = WinHttpQueryHeaders(hRequest, 
									WINHTTP_QUERY_RAW_HEADERS_CRLF,
									WINHTTP_HEADER_NAME_BY_INDEX, 
									lpszResponseHeaders, 
									&dwResponseHeadersSize, 
									WINHTTP_NO_HEADER_INDEX );
			}

		}

		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpQueryHeaders", err));
		}
		else {

			parseHeaders(lpszResponseHeaders);

			if (statusCode != HTTP_STATUS_OK) {
				finishOnError(HException(statusCode));
			}
			else {
				readData();
			}
		}

		if (lpszResponseHeaders) {
			delete[] lpszResponseHeaders;
		}
	}

	virtual void onDataAvailable(DWORD ) throw() {
	}

	virtual void onRequestError(WINHTTP_ASYNC_RESULT* asyncInfo) throw() {
		LPCWSTR fnctName = L"";

		switch (asyncInfo->dwResult) {
		case API_RECEIVE_RESPONSE:		fnctName = L"WinHttpReceiveResponse"; break;
		case API_QUERY_DATA_AVAILABLE:	fnctName = L"WinHttpQueryDataAvailable"; break;
		case API_READ_DATA:				fnctName = L"WinHttpReadData"; break;
		case API_WRITE_DATA:			fnctName = L"WinHttpWriteData"; break;
		case API_SEND_REQUEST:			fnctName = L"WinHttpSendRequest"; break;
		};

		HException ex(fnctName, asyncInfo->dwError);
		finishOnError(ex);

	}

	void parseHeaders(LPWSTR lpszResponseHeaders) throw() {
		byps_unique_lock lock(mutex);

		if (lpszResponseHeaders) {

			//HTTP/1.1 200 OK
			//Server: Apache/1.3.29 (Unix) PHP/4.3.4
			//Content-Length: 1234
			//Content-Language: de 
			//Connection: close
			//Content-Type: text/html
	
			LPWSTR ctxt = NULL;
			LPWSTR t = wcstok_s(lpszResponseHeaders, L"\r\n", &ctxt);

			while (t != NULL) {

				if (statusCode == 0) {
					LPWSTR p = wcschr(t, L' ');
					if (p != NULL) {
						statusCode = _wtoi(p);
					}
					else {
						statusCode = HTTP_STATUS_SERVER_ERROR;
					}
				}
				else {
					LPWSTR p = wcschr(t, L':');
					if (p != NULL) {
						*p = 0; p++;
						if (_wcsicmp(L"Content-Length", t) == 0) {
							contentLength = _wtoi64(p);
						}
						else if (_wcsicmp(L"Content-Type", t) == 0) {
							while (*p == ' ') p++;
							contentType = p; 
						}
					}
				}

				t = wcstok_s(NULL, L"\r\n", &ctxt);
			}
		}
		else {
			statusCode = HTTP_STATUS_SERVER_ERROR;
		}

		waitForHeadersAvailable.notify_all();
	}

	virtual void send(PBytes bytes, const std::wstring& contentType, PAsyncResult asyncBytesReceived) {
		this->asyncResult = asyncBytesReceived;
		this->sendBytes = bytes;
		this->contentLength = bytes->length;
		this->contentType = contentType;
		sendRequest();
	}

	virtual void writeDataOrReceiveResponse() throw() {
		if (!hRequest) return; 

		if (!sendBytes || sendIdx >= sendBytes->length) {
			BOOL succ = WinHttpReceiveResponse(hRequest, NULL);
			if (!succ) {
				DWORD err = GetLastError();
				finishOnError(HException(L"WinHttpReceiveResponse", err));
			}
		}
		else {
			if (sendBytes->length < sendIdx) {
				DWORD err = ERROR_INVALID_PARAMETER;
				finishOnError(HException(L"Invalid state in writeDataOrReceiveResponse: bytes->length < sendIdx", err));
				return;
			}

			int8_t* data = sendBytes->data + sendIdx;
			size_t len = sendBytes->length - sendIdx;
			len = std::min((size_t)0x7FFFFFFF, len);

			BOOL succ = WinHttpWriteData(hRequest, data, (DWORD)len, NULL);
			if (!succ) {
				DWORD err = GetLastError();
				finishOnError(HException(L"WinHttpWriteData", err));
			}
		}
	}

	virtual void readData() throw() {
		if (!hRequest) return; 

		if (respBytes) {

			if (respBytes->length < respIdx) {
				finishOnError(BException(EX_INTERNAL, L"Read-buffer overflow"));
				return;
			}

			// Falls kein richtiger Content-Length Header kam, 
			// haben wir nicht gen�gend reserviert.
			if (respBytes->length == respIdx) {
				respBytes = BBytes::create(respBytes, respBytes->length * 2);
			}
		}
		else {
			// A post message must fit into memory. 
			// Since Java does not support byte arrays > 2GB, we also do not allow
			// them for C++.
			if (contentLength > 0x7FFFFFFF) {
				finishOnError(BException(EX_INTERNAL, L"Message tool large."));
				return;
			}

			// Kein Content-Length Header? dann mindestens 16 Bytes bereitstellen.
			if (contentLength < 16) {
				contentLength = 16;
			}

			respBytes = BBytes::create(respBytes, (int32_t)contentLength + 4); 
				// Etwas mehr reservieren, damit length > als respIdx bleibt.
				// Sonst wird onReadComplete nicht mit 0 aufgerufen .
		}

		BOOL succ = WinHttpReadData(hRequest, 
									respBytes->data + respIdx, 
									(DWORD)(respBytes->length - respIdx), 
									NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpReadData", err));
		}
	}


	virtual void onReadComplete(BYTE* , DWORD length) throw() {
		if (length) {
			respIdx += length;
			readData();
		}
		else {
			finishOnOK();
		}
	}

	virtual void onWriteComplete(DWORD length) throw() {
		sendIdx += length;
		writeDataOrReceiveResponse();
	}
};

class GetRequestContentStream : public BContentStream {
	PWinHttpGetStream request;
public:
	GetRequestContentStream(PWinHttpGetStream request) : request(request) {
	};
	virtual ~GetRequestContentStream();
	virtual const std::wstring& getContentType() const;
	virtual int64_t getContentLength() const;
	virtual int32_t read(char* buf, int32_t offs, int32_t len);
};


class WinHttpGetStream : public HHttpGetStream, public virtual WinHttpRequest {

	int32_t bufferPos, bufferLimit;
	char buffer[8 * 1024]; // Buffer size should be 8k or larger: see MSDN documentation of WinHttpReadData
	BException ex;
	bool sendComplete;

	byps_condition_variable waitForReadComplete;
	byps_condition_variable waitForWriteComplete;
	byps_condition_variable waitForSendComplete;

	friend class GetRequestContentStream;

public:
	WinHttpGetStream(HINTERNET hRequest, const std::wstring& url) 
		: WinHttpRequest(hRequest, url)
		, bufferPos(sizeof(buffer))
		, bufferLimit(sizeof(buffer))
		, sendComplete(false) {

		memset(buffer, 0, sizeof(buffer));
	}

	virtual ~WinHttpGetStream() {
	}

	virtual void finishOnError(const BException& ex) throw() {
		this->ex = ex;
		close();
	}

	virtual void finishOnOK() throw() {
		close();
	}

	virtual void close() {
		WinHttpRequest::close();
		waitForSendComplete.notify_one();
	}

	virtual void onSendComplete() throw() {
		{
			byps_unique_lock lock(this->mutex);
			sendComplete = true;
			waitForSendComplete.notify_one();
		}

		writeDataOrReceiveResponse();
	}

	virtual void writeDataOrReceiveResponse() throw() {
		if (!hRequest) return; 
		BOOL succ = WinHttpReceiveResponse(hRequest, NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpReceiveResponse", err));
		}
	}

	virtual void onReadComplete(BYTE* , DWORD length) throw() {
		byps_unique_lock lock(this->mutex);

		if (length) {
			bufferPos = 0;
			bufferLimit = length;
			waitForReadComplete.notify_one();

			this->waitForWriteComplete.wait(lock, [this](){ return bufferPos == bufferLimit; });
			readData();
		}
		else {
			bufferPos = 0;
			bufferLimit = -1;
			waitForReadComplete.notify_one();

			finishOnOK();

		}
	}

	virtual void readData() throw() {
		if (!hRequest) return; 

		BOOL succ = WinHttpReadData(hRequest, 
									buffer, 
									sizeof(buffer), 
									NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpReadData", err));
		}
	}

	virtual PContentStream send() {
		sendRequest();

		{
			byps_unique_lock lock(this->mutex);
			this->waitForSendComplete.wait(lock, [this](){ return sendComplete || handleClosed; });
		}

		byps_ptr<WinHttpRequest> pRequest = shared_from_this();
		PContentStream stream = PContentStream(new GetRequestContentStream(byps_ptr_cast<WinHttpGetStream>(pRequest)));
		return stream;
	}

	virtual void send(PAsyncResult asyncBytesReceived) {
		this->asyncResult = asyncBytesReceived;
		sendRequest();
	}
};

BINLINE GetRequestContentStream::~GetRequestContentStream() {
	request->close();
}

BINLINE const std::wstring& GetRequestContentStream::getContentType() const { 
	byps_unique_lock lock(request->mutex);
	if (request->ex) throw request->ex;
	request->waitForHeadersAvailable.wait(lock, [this](){ return request->statusCode != 0; });
	return request->contentType; 
}

BINLINE int64_t GetRequestContentStream::getContentLength() const {
	byps_unique_lock lock(request->mutex);
	if (request->ex) throw request->ex;
	request->waitForHeadersAvailable.wait(lock, [this](){ return request->statusCode != 0; });
	return request->contentLength; 
}

BINLINE int32_t GetRequestContentStream::read(char* buffer, int32_t offs, int32_t len) {
	byps_unique_lock lock(request->mutex);
	if (request->ex) throw request->ex;

	int32_t ret = -1;

	std::chrono::milliseconds timeout(100 * 1000);

	if (request->waitForReadComplete.wait_for(lock, timeout, [this](){ 
			return request->ex || request->bufferLimit < 0 || request->bufferPos < request->bufferLimit; 
		}) 
			== std::cv_status::timeout) {

		request->ex = BException(EX_TIMEOUT, L"Read timeout");
		throw request->ex;
	}

	if (request->ex) {
		throw request->ex;
	}
	else if (request->bufferLimit < 0) {
		// End of stream
	}
	else {

		if (request->bufferPos > request->bufferLimit) {
			BException ex(EX_INTERNAL, L"Illegal state in WinHttpClient::ContentStream::readData");
			throw request->ex;
		}

		ret = std::min(request->bufferLimit - request->bufferPos, len);
		memcpy(buffer + offs, request->buffer + request->bufferPos, ret);
		
		request->bufferPos += ret;

		if (request->bufferPos == request->bufferLimit) {
			request->waitForWriteComplete.notify_one();
		}
	}

	return ret;
}


class WinHttpPost : public HHttpPost, public virtual  WinHttpRequest {
public:
	WinHttpPost(HINTERNET hRequest, const std::wstring& url) 
		: WinHttpRequest(hRequest, url)
	{
	}

	virtual ~WinHttpPost() {
	}

	virtual void send(PBytes bytes, const std::wstring& contentType, PAsyncResult asyncBytesReceived) {
		this->asyncResult = asyncBytesReceived;
		this->sendBytes = bytes;
		this->contentLength = bytes->length;
		this->contentType = contentType;
		sendRequest();
	}

};

class WinHttpGet : public HHttpGet, public virtual  WinHttpRequest {
public:
	WinHttpGet(HINTERNET hRequest, const std::wstring& url) 
		: WinHttpRequest(hRequest, url)
	{
	}

	virtual ~WinHttpGet() {
	}

	virtual void send(PAsyncResult asyncBytesReceived) {
		this->asyncResult = asyncBytesReceived;
		sendRequest();
	}

};

class WinHttpPutStream : public HHttpPutStream, public virtual WinHttpRequest {
	PContentStream stream;
	enum EChunkState { NotChunked, Chunked, FinishChunks } m_eChunkState;
	
	int32_t bufferPos, bufferLimit;
	char buffer[0xFFF0]; // writeDataOrReceiveResponse assumes that buffer size is smaller or equal to 0xFFFF

public:
	WinHttpPutStream(HINTERNET hRequest, const std::wstring& url) 
		: WinHttpRequest(hRequest, url)
		, bufferPos(0), bufferLimit(0)
		, m_eChunkState(EChunkState::NotChunked) 
	{
		memset(buffer, 0, sizeof(buffer));
	}

	virtual ~WinHttpPutStream() {
		stream.reset();
	}

	virtual void finishOnOK() throw() {
		if (asyncResult) {
			asyncResult->setAsyncResult(BVariant(true));
			asyncResult = NULL;
		}
		close();
	}

	virtual void send(PContentStream stream, PAsyncResult asyncBoolFinished) {
		asyncResult = asyncBoolFinished;
		this->stream = stream;
		contentLength = (int64_t)stream->getContentLength();
		if (contentLength < 0) m_eChunkState = EChunkState::Chunked;
		contentType = stream->getContentType();
		sendRequest();
	}

	virtual void onWriteComplete(DWORD length) throw() {
		bufferPos += (int32_t)length;
		writeDataOrReceiveResponse();
	}

	void beginChunk(int32_t chunkLength) throw() {
		char szHttpChunkHeaderA[32]; 
		StringCchPrintfA(szHttpChunkHeaderA, ARRAYSIZE(szHttpChunkHeaderA), "%X\r\n", chunkLength ); 
		BOOL succ = WinHttpWriteData(hRequest, szHttpChunkHeaderA, (DWORD)strlen(szHttpChunkHeaderA), NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpWriteData", err));
		}	
	}

	void writeChunk() throw() {
		char* data = buffer + bufferPos;
		int32_t length = bufferLimit - bufferPos;
		BOOL succ = WinHttpWriteData(hRequest, data, (DWORD)length, NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpWriteData", err));
		}
	}

	void endChunk() throw() {
		BOOL succ = WinHttpWriteData(hRequest, "\r\n", 2, NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpWriteData", err));
		}	
	}

	virtual void onReadComplete(BYTE* , DWORD length) throw() {
		if (length) {
			readData();
		}
		else {
			finishOnOK();
		}
	}

	virtual void readData() throw() {
		BOOL succ = WinHttpReadData(hRequest, 
									buffer, 
									sizeof(buffer), 
									NULL);
		if (!succ) {
			DWORD err = GetLastError();
			finishOnError(HException(L"WinHttpReadData", err));
		}
	}

	virtual void writeDataOrReceiveResponse() throw() {

		// Buffer completely send?
		if (bufferPos == bufferLimit) {

			// Read next bytes from stream into buffer
			if (m_eChunkState == EChunkState::Chunked) {

				// Chunked encoding: send chunk bytes as:
				// <nbOfBytes in HEX>\r\n
				// ...chunk bytes...
				// \r\n
				bufferPos = 0;
				int32_t chunkLength = stream->read(buffer + 6, 0, sizeof(buffer) - 6 - 2);
				if (chunkLength > 0) {
					if (chunkLength <= 0xF) bufferPos = 3;
					else if (chunkLength <= 0xFF) bufferPos = 2;
					else if (chunkLength <= 0xFFF) bufferPos = 1;
					else bufferPos = 0;
					StringCchPrintfA(buffer + bufferPos, 5 - bufferPos, "%X", chunkLength );
					buffer[4] = '\r';
					buffer[5] = '\n';

					bufferLimit = 6 + chunkLength + 2;
					buffer[bufferLimit-2] = '\r';
					buffer[bufferLimit-1] = '\n';
				}
				else {
					StringCchPrintfA(buffer, 6, "0\r\n\r\n", chunkLength );
					bufferPos = 0;
					bufferLimit = 5;
					m_eChunkState = EChunkState::FinishChunks;
				}
			}
			else if (m_eChunkState == EChunkState::FinishChunks) {
				bufferLimit = -1;
			}
			else {
				bufferPos = 0;
				bufferLimit = stream->read(buffer, 0, sizeof(buffer));
			}
		}

		// End of stream?
		if (bufferLimit <= 0) {
			BOOL succ = WinHttpReceiveResponse(hRequest, NULL);
			if (!succ) {
				DWORD err = GetLastError();
				finishOnError(HException(L"WinHttpReceiveResponse", err));
			}
		}
		// Check for invalid internal state
		else if (bufferLimit < bufferPos) {
			DWORD err = ERROR_INVALID_PARAMETER;
			finishOnError(HException(L"Invalid state in writeDataOrReceiveResponse: bytes->length < sendIdx", err));
			return;
		}
		else {
			// Write buffer data
			writeChunk();
		}
	}
};

class WinHttpClient : public HHttpClient {

	HINTERNET hSession;
	HINTERNET hConnection;
	PHttpCredentials credentials;
	static BLogger log;
	
public:
	WinHttpClient() 
		: hSession(NULL)
		, hConnection(NULL)
	{
	}

	virtual ~WinHttpClient() {
		if (hConnection) {
			WinHttpCloseHandle(hConnection);
			hConnection = NULL;
			s_handleCount--;
			l_debug << L"close conn, handleCount=" << s_handleCount;
		}
		if (hSession) {
			WinHttpCloseHandle(hSession);
			hSession = NULL;
			s_handleCount--;
			l_debug << L"close sess, handleCount=" << s_handleCount;
		}
	}

	virtual void init(const std::wstring& url, PHttpCredentials creds) {

		this->credentials = creds;

		// WinHttpOpen just seem to leak handles.
		// http://stackoverflow.com/questions/12652868/winhttpopen-leaking-memory

		hSession = WinHttpOpen(L"BYPSWINHTTP", 
						WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
						WINHTTP_NO_PROXY_NAME, 
						WINHTTP_NO_PROXY_BYPASS, 
						WINHTTP_FLAG_ASYNC);

		if (!hSession) {
			DWORD err = GetLastError();
			throw HException(L"WinHttpOpen", err);
		}

		s_handleCount++;
		l_debug << L"open sess, handleCount=" << s_handleCount;

		WCHAR szHost[256]={0};
		URL_COMPONENTS UrlComps = {0};
		UrlComps.dwStructSize = sizeof(UrlComps);
		UrlComps.dwSchemeLength    = (DWORD)-1;
		UrlComps.lpszHostName = szHost;
		UrlComps.dwHostNameLength  = ARRAYSIZE(szHost)-1;
		UrlComps.dwUrlPathLength   = (DWORD)-1;
		UrlComps.dwExtraInfoLength = (DWORD)-1;

		BOOL succ = WinHttpCrackUrl(
								url.c_str(), 
								(DWORD)url.size(), 
								0, 
								&UrlComps);
		if (!succ) {
			DWORD err = GetLastError();
			throw HException(L"WinHttpCrackUrl", err);
		}

		hConnection = WinHttpConnect(
								hSession, 
								szHost, 
								UrlComps.nPort, 
								0);
		if (!hConnection) {
			DWORD err = GetLastError();
			throw HException(L"WinHttpConnect", err);
		}

		s_handleCount++;
		l_debug << L"open conn, handleCount=" << s_handleCount;

	}

	virtual void done() {
	}
	
	HINTERNET openRequest(LPCWSTR method, const std::wstring& url) {

		WCHAR szHost[256]={0};
		URL_COMPONENTS UrlComps = {0};
		UrlComps.dwStructSize = sizeof(UrlComps);
		UrlComps.dwSchemeLength    = (DWORD)-1;
		UrlComps.lpszHostName = szHost;
		UrlComps.dwHostNameLength  = ARRAYSIZE(szHost)-1;
		UrlComps.dwUrlPathLength   = (DWORD)-1;
		UrlComps.dwExtraInfoLength = (DWORD)-1;

		BOOL succ = WinHttpCrackUrl(
								url.c_str(), 
								(DWORD)url.size(), 
								0, 
								&UrlComps);
		if (!succ) {
			DWORD err = GetLastError();
			throw HException(L"WinHttpCrackUrl", err);
		}

		DWORD flags = (INTERNET_SCHEME_HTTPS == UrlComps.nScheme) ? WINHTTP_FLAG_SECURE : 0;
		HINTERNET hRequest = WinHttpOpenRequest(hConnection, 
						method, 
						UrlComps.lpszUrlPath, 
						NULL,
						WINHTTP_NO_REFERER,
						WINHTTP_DEFAULT_ACCEPT_TYPES, 
						flags);

		if (!hRequest) {
			DWORD err = ::GetLastError();
			throw HException(L"WinHttpOpenRequest", err);
		}

		s_handleCount++;
		l_debug << L"open " << method <<  L", handleCount=" << s_handleCount;

		if (credentials) {
			if (credentials->nameProxy.size()) {
				WinHttpSetCredentials(hRequest, WINHTTP_AUTH_TARGET_PROXY, WINHTTP_AUTH_SCHEME_BASIC, 
							credentials->nameProxy.c_str(), credentials->pwdProxy.c_str(), NULL);
			}
			if (credentials->name.size()) {
				WinHttpSetCredentials(hRequest, WINHTTP_AUTH_TARGET_SERVER, WINHTTP_AUTH_SCHEME_BASIC, 
							credentials->name.c_str(), credentials->pwd.c_str(), NULL);
			}
		}

		WINHTTP_STATUS_CALLBACK retcb = WinHttpSetStatusCallback(
			hRequest,
			winhttp_status_callback,
			WINHTTP_CALLBACK_FLAG_ALL_COMPLETIONS | WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING, 
			NULL );
		if (retcb == WINHTTP_INVALID_STATUS_CALLBACK) {
		  DWORD err = GetLastError();
		  throw HException(L"WinHttpSetStatusCallback", err);
		}

		return hRequest;
	}

	virtual PHttpGetStream getStream(const std::wstring& url) {
		HINTERNET hRequest = openRequest(L"GET", url);
		PWinHttpGetStream req(new WinHttpGetStream(hRequest, url));
		return req;
	}

	virtual PHttpGet get(const std::wstring& url) {
		HINTERNET hRequest = openRequest(L"GET", url);
		PWinHttpGet req(new WinHttpGet(hRequest, url));
		return req;
	}

	virtual PHttpPost post(const std::wstring& url) {
		HINTERNET hRequest = openRequest(L"POST", url);
		PWinHttpPost req(new WinHttpPost(hRequest, url));
		return req;
	}

	virtual PHttpPutStream putStream(const std::wstring& url) {
		HINTERNET hRequest = openRequest(L"PUT", url);
		PWinHttpPutStream req(new WinHttpPutStream(hRequest, url));
		return req;
	}

	BINLINE static void CALLBACK winhttp_status_callback(
			IN HINTERNET ,
			IN DWORD_PTR dwContext,
			IN DWORD dwInternetStatus,
			IN LPVOID lpvStatusInformation OPTIONAL,
			IN DWORD dwStatusInformationLength) {

		WinHttpRequest* pThis = reinterpret_cast<WinHttpRequest*>(dwContext);

		if (pThis) {
			switch (dwInternetStatus) {
			case WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE:
				pThis->onSendComplete();
				break;
			case WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE:
				pThis->onHeadersAvailable();
				break;
			case WINHTTP_CALLBACK_STATUS_DATA_AVAILABLE:
				pThis->onDataAvailable(*((DWORD*)lpvStatusInformation));
				break;
			case WINHTTP_CALLBACK_STATUS_READ_COMPLETE:
				pThis->onReadComplete((BYTE*)lpvStatusInformation, dwStatusInformationLength);
				break;
			case WINHTTP_CALLBACK_STATUS_WRITE_COMPLETE:
				pThis->onWriteComplete(*((DWORD*)lpvStatusInformation));
				break;
			case WINHTTP_CALLBACK_STATUS_REQUEST_ERROR:
				pThis->onRequestError((WINHTTP_ASYNC_RESULT*)lpvStatusInformation);
				break;
			case WINHTTP_CALLBACK_STATUS_GETPROXYFORURL_COMPLETE:
		
				break;
			case WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING:
				pThis->onHandleClosing(*((HINTERNET*)lpvStatusInformation));
				break;
			}
		}
	}
};

BLogger WinHttpRequest::log("WinHttpRequest");
BLogger WinHttpClient::log("WinHttpClient");

}}}

namespace byps { namespace http { 

BINLINE PHttpClient HttpClient_create(void* ) {
	return PHttpClient(new byps::http::winhttp::WinHttpClient());
}

}}



#endif