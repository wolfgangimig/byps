/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef WINHTTPCLIENTI_H_
#define WINHTTPCLIENTI_H_


#include "WinHttpClient.h"
#include <Windows.h>
#include <Winhttp.h>

namespace byps { namespace http { namespace winhttp {


}}}


#endif



