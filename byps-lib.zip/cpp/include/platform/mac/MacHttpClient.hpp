#include "MacHttpClient.h"

namespace byps { namespace http {
    
    PHttpClient HttpClient_create(void* app) {
        return PHttpClient();
    }
    
}}


