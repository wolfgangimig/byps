//
//  SwiftHttpClientFactory.swift
//  bypstest
//
//  Created by Wolfgang Imig on 01.01.18.
//  Copyright © 2018 Wolfgang Imig. All rights reserved.
//

import Foundation


class SwiftHttpClientFactory {
    
    func create() -> SwiftHttpClient {
        let abc = SwiftHttpClient();
        return abc;
    }
}
