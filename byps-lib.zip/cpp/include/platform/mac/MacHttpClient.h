/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef MAC_HTTPCLIENT_H_
#define MAC_HTTPCLIENT_H_


#include "Byps.h"
#include "Bypshttp.h"



namespace byps { namespace http {
    
    PHttpClient HttpClient_create(void* app);
    
}}


#endif
