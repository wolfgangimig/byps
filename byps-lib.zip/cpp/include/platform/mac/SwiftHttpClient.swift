//
//  SwiftHttpClient.swift
//  bypslib
//
//  Created by Wolfgang Imig on 01.01.18.
//  Copyright © 2018 Wolfgang Imig. All rights reserved.
//

import Foundation

public class SwiftHttpClient {
    func doit(_ v : Int) -> Int {
        return v+1;
    }
}

//func SwiftHttpClient_create() {
//    let url = URL(string: "http://www.stackoverflow.com");
//
//    let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
//        print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue))
//    }
//
//    task.resume()
//}

