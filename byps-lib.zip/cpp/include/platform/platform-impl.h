/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BPLATFORM_IMPL_H_
#define BPLATFORM_IMPL_H_

#ifdef _MSC_VER

// Decorated name length exceeded, name was truncated.
#pragma warning( disable : 4503 ) 

// Unused parameter
#pragma warning( disable : 4100 )

#elif __GNUC__

#pragma GCC diagnostic ignored "-Wunused-parameter"

#endif

#endif
