/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef PLATFORM_HPP
#define PLATFORM_HPP

#ifdef QT_VERSION

#include "qt/QTThreadPool.hpp"

#endif

#include "any/BThreadPool.hpp"

#endif // PLATFORM_HPP
