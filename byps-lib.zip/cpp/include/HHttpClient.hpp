/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef HHTTPCLIENT_HPP_
#define HHTTPCLIENT_HPP_

#include "HHttpClient.h"

namespace byps { namespace http {

using namespace byps;




}}

#endif