/* USE THIS FILE ACCORDING TO THE COPYRIGHT RULES IN LICENSE.TXT WHICH IS PART OF THE SOURCE CODE PACKAGE */
#ifndef BYPS_IMPL_H_
#define BYPS_IMPL_H_

#include "Byps.h"
#include "platform/platform-impl.h"

#endif
